package yt.DeepHost.Youtube_Embed_Player.Layout;

import android.widget.RelativeLayout;

public class activity_player {
    public static design_size size;

    public activity_player() {
    }

    public static class layout extends RelativeLayout {
        /* JADX WARNING: Illegal instructions before constructor call */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public layout(android.content.Context r12) {
            /*
                r11 = this;
                r0 = r11
                r1 = r12
                r5 = r0
                r6 = r1
                r5.<init>(r6)
                yt.DeepHost.Youtube_Embed_Player.Layout.design_size r5 = new yt.DeepHost.Youtube_Embed_Player.Layout.design_size
                r10 = r5
                r5 = r10
                r6 = r10
                r7 = r1
                r6.<init>(r7)
                yt.DeepHost.Youtube_Embed_Player.Layout.activity_player.size = r5
                r5 = r0
                android.widget.RelativeLayout$LayoutParams r6 = new android.widget.RelativeLayout$LayoutParams
                r10 = r6
                r6 = r10
                r7 = r10
                r8 = -1
                r9 = -1
                r7.<init>(r8, r9)
                r5.setLayoutParams(r6)
                yt.DeepHost.Youtube_Embed_Player.library.mian.YouTubeWebView r5 = new yt.DeepHost.Youtube_Embed_Player.library.mian.YouTubeWebView
                r10 = r5
                r5 = r10
                r6 = r10
                r7 = r1
                r6.<init>(r7)
                r2 = r5
                r5 = r2
                java.lang.String r6 = "youTubeWebView"
                r5.setTag(r6)
                r5 = r2
                android.widget.RelativeLayout$LayoutParams r6 = new android.widget.RelativeLayout$LayoutParams
                r10 = r6
                r6 = r10
                r7 = r10
                r8 = -1
                r9 = -1
                r7.<init>(r8, r9)
                r5.setLayoutParams(r6)
                android.widget.ProgressBar r5 = new android.widget.ProgressBar
                r10 = r5
                r5 = r10
                r6 = r10
                r7 = r1
                r6.<init>(r7)
                r3 = r5
                r5 = r3
                java.lang.String r6 = "progressBar"
                r5.setTag(r6)
                android.widget.RelativeLayout$LayoutParams r5 = new android.widget.RelativeLayout$LayoutParams
                r10 = r5
                r5 = r10
                r6 = r10
                r7 = -2
                r8 = -2
                r6.<init>(r7, r8)
                r4 = r5
                r5 = r4
                r6 = 13
                r5.addRule(r6)
                r5 = r3
                r6 = r4
                r5.setLayoutParams(r6)
                r5 = r0
                r6 = r2
                r5.addView(r6)
                r5 = r0
                r6 = r3
                r5.addView(r6)
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: yt.DeepHost.Youtube_Embed_Player.Layout.activity_player.layout.<init>(android.content.Context):void");
        }
    }
}
