package yt.DeepHost.Youtube_Embed_Player.Layout;

import android.widget.LinearLayout;

public class empty {
    public static design_size size;

    public empty() {
    }

    public static class layout extends LinearLayout {
        /* JADX WARNING: Illegal instructions before constructor call */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public layout(android.content.Context r7) {
            /*
                r6 = this;
                r0 = r6
                r1 = r7
                r2 = r0
                r3 = r1
                r2.<init>(r3)
                yt.DeepHost.Youtube_Embed_Player.Layout.design_size r2 = new yt.DeepHost.Youtube_Embed_Player.Layout.design_size
                r5 = r2
                r2 = r5
                r3 = r5
                r4 = r1
                r3.<init>(r4)
                yt.DeepHost.Youtube_Embed_Player.Layout.empty.size = r2
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: yt.DeepHost.Youtube_Embed_Player.Layout.empty.layout.<init>(android.content.Context):void");
        }
    }
}
