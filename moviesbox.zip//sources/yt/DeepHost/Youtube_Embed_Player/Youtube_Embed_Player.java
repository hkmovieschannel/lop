package yt.DeepHost.Youtube_Embed_Player;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Handler;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.ConsoleMessage;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.annotations.UsesPermissions;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.AndroidViewComponent;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.microsoft.appcenter.Constants;
import com.ultramoviesboxpro.atkgurus.R;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import yt.DeepHost.Youtube_Embed_Player.Layout.activity_player;
import yt.DeepHost.Youtube_Embed_Player.library.mian.YouTubeWebView;

@DesignerComponent(category = ComponentCategory.EXTENSION, description = "<p>DeepHost - Youtube Embed Player Extension <br><br> <a href = \"https://www.youtube.com/c/DeepHost\" target = \"_blank\">Youtube Channel Link</a> </a> <br><br></p>", iconName = "https://res.cloudinary.com/dluhwmiwm/image/upload/v1545063005/ic.png", nonVisible = true, version = 3)
@SimpleObject(external = true)
@UsesPermissions(permissionNames = "android.permission.INTERNET,android.permission.ACCESS_NETWORK_STATE")
public class Youtube_Embed_Player extends AndroidNonvisibleComponent implements Component {
    public static final int VERSION = 1;
    public static String Video_ID = "";
    public static ComponentContainer container;
    public static Context context;
    public Activity activity;
    public ArrayList<String> array_list;
    public boolean fullscreen_mode = true;
    public int height;
    public boolean isRepl = false;
    public ProgressBar progressBar;
    View v;
    public int weight;
    public YouTubeWebView youTubeWebView;

    public class CustomClient extends WebViewClient {
        final /* synthetic */ Youtube_Embed_Player this$0;

        public CustomClient(Youtube_Embed_Player this$02) {
            this.this$0 = this$02;
        }

        public void onPageFinished(WebView webView, String str) {
            StringBuilder sb;
            new StringBuilder();
            StringBuilder sb2 = sb;
            StringBuilder append = sb2.append("URL_AFTER_FINISH ");
            StringBuilder append2 = sb2.append(str);
            String sb3 = sb2.toString();
            this.this$0.hide_item(webView);
        }

        public void onPageStarted(WebView webView, String str, Bitmap bitmap) {
            StringBuilder sb;
            String str2 = str;
            super.onPageStarted(webView, str2, bitmap);
            new StringBuilder();
            StringBuilder sb2 = sb;
            StringBuilder append = sb2.append("URL_BEFORE DECODE ");
            StringBuilder append2 = sb2.append(str2);
            String sb3 = sb2.toString();
        }

        @TargetApi(24)
        public boolean shouldOverrideUrlLoading(WebView webView, WebResourceRequest webResourceRequest) {
            StringBuilder sb;
            Intent intent;
            WebView webView2 = webView;
            StringBuilder a2 = Youtube_Embed_Player.id("");
            StringBuilder append = a2.append(webResourceRequest.getUrl());
            String sb2 = a2.toString();
            new StringBuilder();
            StringBuilder sb22 = sb;
            StringBuilder append2 = sb22.append("URL_BEFORE DECODE ");
            StringBuilder append3 = sb22.append(sb2);
            String sb3 = sb22.toString();
            if (URLUtil.isNetworkUrl(sb2)) {
                return true;
            }
            try {
                new Intent("android.intent.action.VIEW", Uri.parse(sb2));
                this.this$0.activity.startActivity(intent);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return true;
        }

        public boolean shouldOverrideUrlLoading(WebView webView, String str) {
            StringBuilder sb;
            Intent intent;
            WebView webView2 = webView;
            String str2 = str;
            new StringBuilder();
            StringBuilder sb2 = sb;
            StringBuilder append = sb2.append("URL_BEFORE DECODE ");
            StringBuilder append2 = sb2.append(str2);
            String sb3 = sb2.toString();
            if (URLUtil.isNetworkUrl(str2)) {
                return true;
            }
            try {
                new Intent("android.intent.action.VIEW", Uri.parse(str2));
                this.this$0.activity.startActivity(intent);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return true;
        }
    }

    public class inline implements Runnable {
        final /* synthetic */ Youtube_Embed_Player this$0;
        public final WebView webview1;

        public inline(Youtube_Embed_Player this$02, Youtube_Embed_Player youtube_Embed_Player, WebView webView) {
            Youtube_Embed_Player youtube_Embed_Player2 = youtube_Embed_Player;
            this.this$0 = this$02;
            this.webview1 = webView;
        }

        public void run() {
            View.OnLongClickListener onLongClickListener;
            this.webview1.loadUrl("javascript:(function() { var elements = document.getElementsByClassName('ytp-button ytp-settings-button')[0].style.display='inline'; })()");
            if (this.this$0.fullscreen_mode) {
                this.webview1.loadUrl("javascript:(function() { var elements = document.getElementsByClassName('ytp-fullscreen-button ytp-button')[0].style.display='inline'; })()");
            }
            this.webview1.setLongClickable(false);
            new View.OnLongClickListener(this) {
                final /* synthetic */ inline this$1;

                {
                    this.this$1 = this$1;
                }

                public boolean onLongClick(View view) {
                    View view2 = view;
                    return true;
                }
            };
            this.webview1.setOnLongClickListener(onLongClickListener);
        }
    }

    public class myWebClint_1 extends WebChromeClient {
        public View f2489a;
        public WebChromeClient.CustomViewCallback f2490b;
        public int f2491c;
        public int f2492d;
        final /* synthetic */ Youtube_Embed_Player this$0;

        public myWebClint_1(Youtube_Embed_Player this$02) {
            this.this$0 = this$02;
        }

        public Bitmap getDefaultVideoPoster() {
            if (this.f2489a == null) {
                return null;
            }
            return BitmapFactory.decodeResource(Youtube_Embed_Player.context.getResources(), R.drawable.abc_tab_indicator_material);
        }

        public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
            ConsoleMessage consoleMessage2 = consoleMessage;
            StringBuilder a2 = Youtube_Embed_Player.id("");
            StringBuilder append = a2.append(consoleMessage2.message());
            StringBuilder append2 = a2.append(" at ");
            StringBuilder append3 = a2.append(consoleMessage2.sourceId());
            StringBuilder append4 = a2.append(Constants.COMMON_SCHEMA_PREFIX_SEPARATOR);
            StringBuilder append5 = a2.append(consoleMessage2.lineNumber());
            String sb = a2.toString();
            Class<Youtube_Embed_Player> cls = Youtube_Embed_Player.class;
            return true;
        }

        public void onHideCustomView() {
            ((FrameLayout) this.this$0.activity.getWindow().getDecorView()).removeView(this.f2489a);
            this.f2489a = null;
            this.this$0.onExitFullScreen();
            this.this$0.activity.getWindow().getDecorView().setSystemUiVisibility(this.f2492d);
            this.this$0.activity.getWindow().getDecorView().setSystemUiVisibility(0);
            this.this$0.activity.setRequestedOrientation(1);
            this.this$0.activity.getWindow().clearFlags(1024);
            this.f2490b.onCustomViewHidden();
            this.f2490b = null;
            Youtube_Embed_Player youTubeWebView = this.this$0;
            youTubeWebView.hide_item(youTubeWebView.youTubeWebView);
        }

        public void onProgressChanged(WebView webView, int i2) {
            ProgressBar progressBar;
            int i3;
            WebView webView2 = webView;
            if (i2 == 100) {
                progressBar = this.this$0.progressBar;
                i3 = 8;
            } else {
                progressBar = this.this$0.progressBar;
                i3 = 0;
            }
            progressBar.setVisibility(i3);
        }

        public void onReceivedTitle(WebView webView, String str) {
        }

        @SuppressLint({"WrongConstant"})
        public void onShowCustomView(View view, WebChromeClient.CustomViewCallback customViewCallback) {
            ViewGroup.LayoutParams layoutParams;
            View view2 = view;
            WebChromeClient.CustomViewCallback customViewCallback2 = customViewCallback;
            if (this.f2489a != null) {
                onHideCustomView();
                return;
            }
            this.this$0.onFullScreen();
            this.this$0.activity.getWindow().getDecorView().setSystemUiVisibility(5894);
            this.this$0.activity.getWindow().addFlags(1024);
            this.this$0.activity.setRequestedOrientation(6);
            this.f2489a = view2;
            this.f2492d = this.this$0.activity.getWindow().getDecorView().getSystemUiVisibility();
            this.f2491c = this.this$0.activity.getRequestedOrientation();
            this.f2490b = customViewCallback2;
            new FrameLayout.LayoutParams(-1, -1);
            ((FrameLayout) this.this$0.activity.getWindow().getDecorView()).addView(this.f2489a, layoutParams);
            this.this$0.activity.getWindow().getDecorView().setSystemUiVisibility(3846);
            Youtube_Embed_Player youTubeWebView = this.this$0;
            youTubeWebView.hide_item(youTubeWebView.youTubeWebView);
        }
    }

    public class myWebClint_2 extends WebChromeClient {
        public View f2489a;
        public WebChromeClient.CustomViewCallback f2490b;
        public int f2491c;
        public int f2492d;
        final /* synthetic */ Youtube_Embed_Player this$0;

        public myWebClint_2(Youtube_Embed_Player this$02) {
            this.this$0 = this$02;
        }

        public Bitmap getDefaultVideoPoster() {
            if (this.f2489a == null) {
                return null;
            }
            return BitmapFactory.decodeResource(Youtube_Embed_Player.context.getResources(), R.drawable.abc_tab_indicator_material);
        }

        public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
            ConsoleMessage consoleMessage2 = consoleMessage;
            StringBuilder a2 = Youtube_Embed_Player.id("");
            StringBuilder append = a2.append(consoleMessage2.message());
            StringBuilder append2 = a2.append(" at ");
            StringBuilder append3 = a2.append(consoleMessage2.sourceId());
            StringBuilder append4 = a2.append(Constants.COMMON_SCHEMA_PREFIX_SEPARATOR);
            StringBuilder append5 = a2.append(consoleMessage2.lineNumber());
            String sb = a2.toString();
            Class<Youtube_Embed_Player> cls = Youtube_Embed_Player.class;
            return true;
        }

        public void onHideCustomView() {
            ((FrameLayout) this.this$0.activity.getWindow().getDecorView()).removeView(this.f2489a);
            this.f2489a = null;
            this.this$0.onExitFullScreen();
            this.this$0.activity.getWindow().getDecorView().setSystemUiVisibility(this.f2492d);
            this.this$0.activity.getWindow().getDecorView().setSystemUiVisibility(0);
            this.this$0.activity.setRequestedOrientation(1);
            this.this$0.activity.getWindow().clearFlags(1024);
            this.f2490b.onCustomViewHidden();
            this.f2490b = null;
            Youtube_Embed_Player youTubeWebView = this.this$0;
            youTubeWebView.hide_item(youTubeWebView.youTubeWebView);
        }

        public void onProgressChanged(WebView webView, int i2) {
            ProgressBar progressBar;
            int i3;
            WebView webView2 = webView;
            if (i2 == 100) {
                progressBar = this.this$0.progressBar;
                i3 = 8;
            } else {
                progressBar = this.this$0.progressBar;
                i3 = 0;
            }
            progressBar.setVisibility(i3);
        }

        public void onReceivedTitle(WebView webView, String str) {
        }
    }

    public void removechild(WebView webView, String str) {
        StringBuilder sb;
        View.OnLongClickListener onLongClickListener;
        WebView webView2 = webView;
        new StringBuilder();
        StringBuilder sb2 = sb;
        StringBuilder append = sb2.append("javascript:(function() {  var elements = document.getElementsByClassName('");
        StringBuilder append2 = sb2.append(str);
        StringBuilder append3 = sb2.append("'); while(elements.length > 0)elements[0].parentNode.removeChild(elements[0]);  })()");
        webView2.loadUrl(sb2.toString());
        webView2.setLongClickable(false);
        new View.OnLongClickListener(this) {
            final /* synthetic */ Youtube_Embed_Player this$0;

            {
                this.this$0 = this$0;
            }

            public boolean onLongClick(View view) {
                View view2 = view;
                return true;
            }
        };
        webView2.setOnLongClickListener(onLongClickListener);
    }

    public void stop_playing() {
        YouTubeWebView myWebView = this.youTubeWebView;
        if (myWebView != null) {
            myWebView.stopLoading();
        }
        try {
            if (this.youTubeWebView != null) {
                this.youTubeWebView.destroy();
            }
        } catch (Exception e) {
            Exception exc = e;
        }
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public Youtube_Embed_Player(com.google.appinventor.components.runtime.ComponentContainer r7) {
        /*
            r6 = this;
            r0 = r6
            r1 = r7
            r2 = r0
            r3 = r1
            com.google.appinventor.components.runtime.Form r3 = r3.$form()
            r2.<init>(r3)
            r2 = r0
            r3 = 0
            r2.isRepl = r3
            r2 = r0
            r3 = 1
            r2.fullscreen_mode = r3
            r2 = r0
            java.util.ArrayList r3 = new java.util.ArrayList
            r5 = r3
            r3 = r5
            r4 = r5
            r4.<init>()
            r2.array_list = r3
            r2 = r0
            r2 = r1
            container = r2
            r2 = r0
            r2 = r1
            android.app.Activity r2 = r2.$context()
            context = r2
            r2 = r0
            r3 = r1
            android.app.Activity r3 = r3.$context()
            r2.activity = r3
            r2 = r1
            com.google.appinventor.components.runtime.Form r2 = r2.$form()
            boolean r2 = r2 instanceof com.google.appinventor.components.runtime.ReplForm
            if (r2 == 0) goto L_0x003f
            r2 = r0
            r3 = 1
            r2.isRepl = r3
        L_0x003f:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: yt.DeepHost.Youtube_Embed_Player.Youtube_Embed_Player.<init>(com.google.appinventor.components.runtime.ComponentContainer):void");
    }

    @SimpleProperty
    public void FullScreen_Mode(boolean id) {
        boolean z = id;
        this.fullscreen_mode = z;
    }

    @SimpleProperty
    public void Video_ID(String video_id) {
        Video_ID = video_id;
    }

    @SimpleFunction
    public void Youtube_Embed_Player(AndroidViewComponent androidViewComponent) {
        View view;
        AndroidViewComponent component = androidViewComponent;
        if (isNetworkConnected()) {
            new activity_player.layout(context);
            this.v = view;
            this.progressBar = (ProgressBar) this.v.findViewWithTag("progressBar");
            this.progressBar.setVisibility(8);
            ViewGroup arrangement = (ViewGroup) component.getView();
            arrangement.removeAllViews();
            arrangement.addView(this.v);
            Player(this);
        }
    }

    public void Player(Youtube_Embed_Player youtube_Embed_Player) {
        HashMap hashMap;
        WebViewClient webViewClient;
        WebChromeClient webChromeClient;
        StringBuilder sb;
        ArrayList<String> arrayList;
        StringBuilder sb2;
        View.OnLongClickListener onLongClickListener;
        WebChromeClient webChromeClient2;
        Youtube_Embed_Player youtube_Embed_Player2 = youtube_Embed_Player;
        try {
            this.youTubeWebView = (YouTubeWebView) this.v.findViewWithTag("youTubeWebView");
        } catch (Exception e) {
            Exception exc = e;
        }
        YouTubeWebView myWebView = this.youTubeWebView;
        if (myWebView != null) {
            myWebView.getSettings().setLoadWithOverviewMode(true);
            myWebView.getSettings().setUseWideViewPort(true);
            myWebView.getSettings().setJavaScriptEnabled(true);
            myWebView.getSettings().setAllowContentAccess(false);
            myWebView.getSettings().setDisplayZoomControls(false);
            new HashMap();
            Object put = hashMap.put("EXM_CLIENT", "android,1.0");
            new CustomClient(this);
            myWebView.setWebViewClient(webViewClient);
            if (this.fullscreen_mode) {
                new myWebClint_1(this);
                myWebView.setWebChromeClient(webChromeClient2);
            } else {
                new myWebClint_2(this);
                myWebView.setWebChromeClient(webChromeClient);
            }
            String str = Video_ID;
            new StringBuilder();
            StringBuilder sb3 = sb;
            StringBuilder append = sb3.append("http://android.player.ptechonline.com?v=");
            StringBuilder append2 = sb3.append(str);
            StringBuilder append3 = sb3.append("&initial_width=");
            StringBuilder append4 = sb3.append(this.weight);
            StringBuilder append5 = sb3.append("&initial_height=");
            double d2 = (double) this.height;
            boolean isNaN = Double.isNaN(d2);
            boolean isNaN2 = Double.isNaN(d2);
            boolean isNaN3 = Double.isNaN(d2);
            StringBuilder append6 = sb3.append((int) (d2 / 1.5d));
            StringBuilder append7 = sb3.append("&screen_width=");
            StringBuilder append8 = sb3.append(this.weight);
            StringBuilder append9 = sb3.append("&screen_height=");
            StringBuilder append10 = sb3.append(this.height);
            StringBuilder append11 = sb3.append("&autoplay=1");
            String sb4 = sb3.toString();
            myWebView.getSettings().setUserAgentString("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/536.5 (KHTML, like Gecko) Chrome/19.0.1084.9 Safari/536.5");
            new ArrayList<>();
            this.array_list = arrayList;
            boolean add = this.array_list.add("ytp-chrome-top-buttons");
            boolean add2 = this.array_list.add("ytp-title");
            boolean add3 = this.array_list.add("ytp-youtube-button ytp-button yt-uix-sessionlink");
            boolean add4 = this.array_list.add("ytp-button ytp-endscreen-next");
            boolean add5 = this.array_list.add("ytp-button ytp-endscreen-previous");
            boolean add6 = this.array_list.add("ytp-show-cards-title");
            boolean add7 = this.array_list.add("ytp-endscreen-content");
            boolean add8 = this.array_list.add("ytp-chrome-top");
            boolean add9 = this.array_list.add("ytp-share-button");
            boolean add10 = this.array_list.add("ytp-watch-later-button");
            boolean add11 = this.array_list.add("ytp-pause-overlay");
            if (!this.fullscreen_mode) {
                boolean add12 = this.array_list.add("ytp-fullscreen-button ytp-button");
            }
            new StringBuilder();
            StringBuilder sb22 = sb2;
            StringBuilder append12 = sb22.append("https://www.youtube.com/embed/");
            StringBuilder append13 = sb22.append(str);
            myWebView.loadUrl(sb22.toString());
            myWebView.setLongClickable(false);
            new View.OnLongClickListener(this) {
                final /* synthetic */ Youtube_Embed_Player this$0;

                {
                    this.this$0 = this$0;
                }

                public boolean onLongClick(View view) {
                    View view2 = view;
                    return true;
                }
            };
            myWebView.setOnLongClickListener(onLongClickListener);
        }
    }

    public boolean isNetworkConnected() {
        return ((ConnectivityManager) container.$context().getSystemService("connectivity")).getActiveNetworkInfo() != null;
    }

    public void YouTube_Player(Youtube_Embed_Player youtube_Embed_Player) {
        HashMap hashMap;
        WebViewClient webViewClient;
        WebChromeClient webChromeClient;
        StringBuilder sb;
        ArrayList<String> arrayList;
        StringBuilder sb2;
        View.OnLongClickListener onLongClickListener;
        WebChromeClient webChromeClient2;
        Youtube_Embed_Player youTubeWebView2 = youtube_Embed_Player;
        try {
            youTubeWebView2.youTubeWebView = (YouTubeWebView) youTubeWebView2.v.findViewWithTag("youTubeWebView");
        } catch (Exception e) {
            Exception exc = e;
        }
        YouTubeWebView myWebView = youTubeWebView2.youTubeWebView;
        if (myWebView != null) {
            myWebView.getSettings().setLoadWithOverviewMode(true);
            myWebView.getSettings().setUseWideViewPort(true);
            myWebView.getSettings().setJavaScriptEnabled(true);
            myWebView.getSettings().setAllowContentAccess(false);
            myWebView.getSettings().setDisplayZoomControls(false);
            new HashMap();
            Object put = hashMap.put("EXM_CLIENT", "android,1.0");
            new CustomClient(this);
            myWebView.setWebViewClient(webViewClient);
            if (this.fullscreen_mode) {
                new myWebClint_1(this);
                myWebView.setWebChromeClient(webChromeClient2);
            } else {
                new myWebClint_2(this);
                myWebView.setWebChromeClient(webChromeClient);
            }
            String str = Video_ID;
            new StringBuilder();
            StringBuilder sb3 = sb;
            StringBuilder append = sb3.append("http://android.player.ptechonline.com?v=");
            StringBuilder append2 = sb3.append(str);
            StringBuilder append3 = sb3.append("&initial_width=");
            StringBuilder append4 = sb3.append(youTubeWebView2.weight);
            StringBuilder append5 = sb3.append("&initial_height=");
            double d2 = (double) youTubeWebView2.height;
            boolean isNaN = Double.isNaN(d2);
            boolean isNaN2 = Double.isNaN(d2);
            boolean isNaN3 = Double.isNaN(d2);
            StringBuilder append6 = sb3.append((int) (d2 / 1.5d));
            StringBuilder append7 = sb3.append("&screen_width=");
            StringBuilder append8 = sb3.append(youTubeWebView2.weight);
            StringBuilder append9 = sb3.append("&screen_height=");
            StringBuilder append10 = sb3.append(youTubeWebView2.height);
            StringBuilder append11 = sb3.append("&autoplay=1");
            String sb4 = sb3.toString();
            myWebView.getSettings().setUserAgentString("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/536.5 (KHTML, like Gecko) Chrome/19.0.1084.9 Safari/536.5");
            new ArrayList<>();
            youTubeWebView2.array_list = arrayList;
            boolean add = youTubeWebView2.array_list.add("ytp-chrome-top-buttons");
            boolean add2 = youTubeWebView2.array_list.add("ytp-title");
            boolean add3 = youTubeWebView2.array_list.add("ytp-youtube-button ytp-button yt-uix-sessionlink");
            boolean add4 = youTubeWebView2.array_list.add("ytp-button ytp-endscreen-next");
            boolean add5 = youTubeWebView2.array_list.add("ytp-button ytp-endscreen-previous");
            boolean add6 = youTubeWebView2.array_list.add("ytp-show-cards-title");
            boolean add7 = youTubeWebView2.array_list.add("ytp-endscreen-content");
            boolean add8 = youTubeWebView2.array_list.add("ytp-chrome-top");
            boolean add9 = youTubeWebView2.array_list.add("ytp-share-button");
            boolean add10 = youTubeWebView2.array_list.add("ytp-watch-later-button");
            boolean add11 = youTubeWebView2.array_list.add("ytp-pause-overlay");
            if (!this.fullscreen_mode) {
                boolean add12 = this.array_list.add("ytp-fullscreen-button ytp-button");
            }
            new StringBuilder();
            StringBuilder sb22 = sb2;
            StringBuilder append12 = sb22.append("https://www.youtube.com/embed/");
            StringBuilder append13 = sb22.append(str);
            myWebView.loadUrl(sb22.toString());
            myWebView.setLongClickable(false);
            new View.OnLongClickListener(this) {
                final /* synthetic */ Youtube_Embed_Player this$0;

                {
                    this.this$0 = this$0;
                }

                public boolean onLongClick(View view) {
                    View view2 = view;
                    return true;
                }
            };
            myWebView.setOnLongClickListener(onLongClickListener);
        }
    }

    public final void hide_item(WebView webView) {
        Handler handler;
        Runnable runnable;
        WebView webView2 = webView;
        if (webView2 != null) {
            try {
                Iterator it = this.array_list.iterator();
                while (it.hasNext()) {
                    String str = it.next();
                    hide_element(webView2, str);
                    removechild(webView2, str);
                }
                new Handler();
                new inline(this, this, webView2);
                boolean postDelayed = handler.postDelayed(runnable, 100);
            } catch (Exception e) {
                Exception exc = e;
            }
        }
    }

    public void hide_element(WebView webView, String str) {
        StringBuilder sb;
        View.OnLongClickListener onLongClickListener;
        View.OnLongClickListener onLongClickListener2;
        WebView webView2 = webView;
        new StringBuilder();
        StringBuilder sb2 = sb;
        StringBuilder append = sb2.append("javascript:(function() { var elements = document.getElementsByClassName('");
        StringBuilder append2 = sb2.append(str);
        StringBuilder append3 = sb2.append("')[0].style.display='none'; })()");
        webView2.loadUrl(sb2.toString());
        webView2.setLongClickable(false);
        new View.OnLongClickListener(this) {
            final /* synthetic */ Youtube_Embed_Player this$0;

            {
                this.this$0 = this$0;
            }

            public boolean onLongClick(View view) {
                View view2 = view;
                return true;
            }
        };
        webView2.setOnLongClickListener(onLongClickListener);
        webView2.setLongClickable(false);
        new View.OnLongClickListener(this) {
            final /* synthetic */ Youtube_Embed_Player this$0;

            {
                this.this$0 = this$0;
            }

            public boolean onLongClick(View view) {
                View view2 = view;
                return true;
            }
        };
        webView2.setOnLongClickListener(onLongClickListener2);
    }

    public static StringBuilder id(String str) {
        StringBuilder sb;
        new StringBuilder();
        StringBuilder sb2 = sb;
        StringBuilder append = sb2.append(str);
        return sb2;
    }

    @SimpleFunction
    public void onPause() {
        YouTubeWebView myWebView = this.youTubeWebView;
        if (myWebView != null) {
            myWebView.onPause();
        }
    }

    @SimpleFunction
    public void onResume() {
        YouTubeWebView myWebView = this.youTubeWebView;
        if (myWebView != null) {
            myWebView.onResume();
        }
    }

    @SimpleFunction
    public void Stop_Playing() {
        stop_playing();
    }

    @SimpleEvent
    public void onFullScreen() {
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "onFullScreen", new Object[0]);
    }

    @SimpleEvent
    public void onExitFullScreen() {
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "onExitFullScreen", new Object[0]);
    }
}
