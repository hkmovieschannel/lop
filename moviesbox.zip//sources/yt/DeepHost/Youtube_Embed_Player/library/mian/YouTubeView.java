package yt.DeepHost.Youtube_Embed_Player.library.mian;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import yt.DeepHost.Youtube_Embed_Player.Layout.activity_view;

public class YouTubeView extends AppCompatActivity {
    public YouTubeView() {
    }

    public void onBackPressed() {
        YouTubeView.super.onBackPressed();
        finish();
    }

    public void onCreate(Bundle bundle) {
        View v;
        YouTubeView.super.onCreate(bundle);
        new activity_view.layout(getApplicationContext());
        setContentView(v);
    }
}
