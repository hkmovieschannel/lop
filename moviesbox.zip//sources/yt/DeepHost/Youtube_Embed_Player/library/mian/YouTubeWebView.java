package yt.DeepHost.Youtube_Embed_Player.library.mian;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.webkit.WebView;
import gnu.expr.Declaration;

public class YouTubeWebView extends WebView {
    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public YouTubeWebView(android.content.Context r5) {
        /*
            r4 = this;
            r0 = r4
            r1 = r5
            r2 = r0
            r3 = r1
            r2.<init>(r3)
            r2 = r0
            r3 = r1
            r2.a(r3)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: yt.DeepHost.Youtube_Embed_Player.library.mian.YouTubeWebView.<init>(android.content.Context):void");
    }

    @SuppressLint({"SetJavaScriptEnabled"})
    public final void a(Context context) {
        View.OnLongClickListener onLongClickListener;
        LayoutInflater from = LayoutInflater.from(context);
        getSettings().setJavaScriptEnabled(true);
        getSettings().setUseWideViewPort(true);
        getSettings().setLoadWithOverviewMode(true);
        setLongClickable(false);
        new View.OnLongClickListener(this) {
            final /* synthetic */ YouTubeWebView this$0;

            {
                this.this$0 = this$0;
            }

            public boolean onLongClick(View view) {
                View view2 = view;
                return true;
            }
        };
        setOnLongClickListener(onLongClickListener);
    }

    @SuppressLint({"WrongConstant"})
    public void onMeasure(int i, int i2) {
        int i22 = i;
        int i3 = i2;
        if (getLayoutParams().height == -2) {
            i3 = View.MeasureSpec.makeMeasureSpec((View.MeasureSpec.getSize(i22) * 9) / 16, Declaration.MODULE_REFERENCE);
        }
        super.onMeasure(i22, i3);
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public YouTubeWebView(android.content.Context r7, android.util.AttributeSet r8) {
        /*
            r6 = this;
            r0 = r6
            r1 = r7
            r2 = r8
            r3 = r0
            r4 = r1
            r5 = r2
            r3.<init>(r4, r5)
            r3 = r0
            r4 = r1
            r3.a(r4)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: yt.DeepHost.Youtube_Embed_Player.library.mian.YouTubeWebView.<init>(android.content.Context, android.util.AttributeSet):void");
    }
}
