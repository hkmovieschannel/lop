package yt.DeepHost.Search_View;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.annotations.UsesPermissions;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.AndroidViewComponent;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.util.YailList;
import java.util.ArrayList;
import java.util.Arrays;
import yt.DeepHost.Search_View.Layout.activity_main;
import yt.DeepHost.Search_View.Layout.isReple;
import yt.DeepHost.Search_View.searchview.SearchView;

@SimpleObject(external = true)
@DesignerComponent(category = ComponentCategory.EXTENSION, description = "<p>DeepHost Search View Extension <br><br> <a href = \"https://www.youtube.com/c/DeepHost\" target = \"_blank\">Youtube Channel Link</a><br><br> <a href = \"https://res.cloudinary.com/dluhwmiwm/raw/upload/v1567338937/DeepHost/Extension/Search%20View%20Extension/icon.zip\" target = \"_blank\"><b>Download - Assets Icons.zip<b></a> <br><br> <b>Note : <b> You Need to export this zip file and upload all icons in your project assets.<br><br></p>", iconName = "https://res.cloudinary.com/dluhwmiwm/image/upload/v1545063005/ic.png", nonVisible = true, version = 1)
@UsesPermissions(permissionNames = "android.permission.INTERNET,android.permission.ACCESS_NETWORK_STATE")
public class Search_View extends AndroidNonvisibleComponent implements Component {
    public static final int VERSION = 1;
    public static boolean auto_submit = false;
    public static ComponentContainer container;
    public static Context context;
    public Activity activity;
    String[] list;
    /* access modifiers changed from: private */
    public int position = 0;
    private SearchView searchView;
    private ArrayList<String> search_list;
    public ViewGroup viewGroup;

    static /* synthetic */ int access$102(Search_View x0, int x1) {
        int i = x1;
        int i2 = i;
        x0.position = i2;
        return i;
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public Search_View(com.google.appinventor.components.runtime.ComponentContainer r5) {
        /*
            r4 = this;
            r0 = r4
            r1 = r5
            r2 = r0
            r3 = r1
            com.google.appinventor.components.runtime.Form r3 = r3.$form()
            r2.<init>(r3)
            r2 = r0
            r3 = 0
            r2.position = r3
            r2 = r0
            r2 = r1
            container = r2
            r2 = r0
            r2 = r1
            android.app.Activity r2 = r2.$context()
            context = r2
            r2 = r0
            r3 = r1
            android.app.Activity r3 = r3.$context()
            r2.activity = r3
            r2 = r1
            com.google.appinventor.components.runtime.Form r2 = r2.$form()
            boolean r2 = r2 instanceof com.google.appinventor.components.runtime.ReplForm
            if (r2 == 0) goto L_0x002f
            r2 = 1
            yt.DeepHost.Search_View.Layout.isReple.isRepl = r2
        L_0x002f:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: yt.DeepHost.Search_View.Search_View.<init>(com.google.appinventor.components.runtime.ComponentContainer):void");
    }

    @DesignerProperty(defaultValue = "False", editorType = "boolean")
    @SimpleProperty
    public void AppInventor(boolean id) {
        isReple.appInventor = id;
    }

    @SimpleFunction
    public void Create_Search(AndroidViewComponent component, YailList List) {
        View view;
        ArrayList<String> arrayList;
        SearchView.OnQueryTextListener onQueryTextListener;
        SearchView.SearchViewListener searchViewListener;
        new activity_main.layout(context);
        View view2 = view;
        this.list = List.toStringArray();
        new ArrayList<>();
        this.search_list = arrayList;
        this.search_list.clear();
        boolean addAll = this.search_list.addAll(Arrays.asList(this.list));
        this.viewGroup = (ViewGroup) component.getView();
        this.viewGroup.removeAllViews();
        this.viewGroup.addView(view2);
        this.searchView = (SearchView) view2.findViewWithTag("search_view");
        new SearchView.OnQueryTextListener(this) {
            final /* synthetic */ Search_View this$0;

            {
                this.this$0 = this$0;
            }

            public boolean onQueryTextSubmit(String str) {
                String query = str;
                if (this.this$0.get_position(query) != -1) {
                    int access$102 = Search_View.access$102(this.this$0, this.this$0.get_position(query) + 1);
                    this.this$0.onQueryTextSubmit(this.this$0.position, query);
                } else {
                    this.this$0.No_Results_Found(query);
                }
                return false;
            }

            public boolean onQueryTextChange(String newText) {
                this.this$0.onQueryTextChange(newText);
                return false;
            }
        };
        this.searchView.setOnQueryTextListener(onQueryTextListener);
        new SearchView.SearchViewListener(this) {
            final /* synthetic */ Search_View this$0;

            {
                this.this$0 = this$0;
            }

            public void onSearchViewShown() {
                this.this$0.onSearchViewShown();
            }

            public void onSearchViewClosed() {
                this.this$0.onSearchViewClosed();
            }
        };
        this.searchView.setOnSearchViewListener(searchViewListener);
        this.searchView.setVoiceSearch(false);
        this.searchView.setSuggestions(this.list);
    }

    /* access modifiers changed from: private */
    public int get_position(String value) {
        return this.search_list.indexOf(value);
    }

    @SimpleFunction
    public void Open_Search() {
        if (this.searchView != null) {
            this.searchView.showSearch(true);
            this.searchView.setVisibility(0);
        }
    }

    @SimpleFunction
    public void Close_Search() {
        if (this.searchView != null && this.searchView.isSearchOpen()) {
            this.searchView.closeSearch();
        }
    }

    @SimpleProperty
    public void Auto_Submit(boolean id) {
        auto_submit = id;
    }

    @SimpleEvent
    public void onSearchViewShown() {
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "onSearchViewShown", new Object[0]);
    }

    @SimpleEvent
    public void No_Results_Found(String query) {
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "No_Results_Found", query);
    }

    @SimpleEvent
    public void onSearchViewClosed() {
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "onSearchViewClosed", new Object[0]);
    }

    @SimpleEvent
    public void onQueryTextChange(String Query) {
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "onQueryTextChange", Query);
    }

    @SimpleEvent
    public void onQueryTextSubmit(int Position, String Query) {
        Object[] objArr = new Object[2];
        objArr[0] = Integer.valueOf(Position);
        Object[] objArr2 = objArr;
        objArr2[1] = Query;
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "onQueryTextSubmit", objArr2);
    }
}
