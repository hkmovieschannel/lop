package yt.DeepHost.Search_View.Layout;

import android.widget.FrameLayout;

public class search_view {
    public search_view() {
    }

    public static class layout extends FrameLayout {
        /* JADX WARNING: Illegal instructions before constructor call */
        @android.annotation.SuppressLint({"WrongConstant"})
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public layout(android.content.Context r23) {
            /*
                r22 = this;
                r0 = r22
                r1 = r23
                r14 = r0
                r15 = r1
                r14.<init>(r15)
                r14 = r0
                r15 = -1
                r14.setBackgroundColor(r15)
                r14 = r0
                android.widget.FrameLayout$LayoutParams r15 = new android.widget.FrameLayout$LayoutParams
                r21 = r15
                r15 = r21
                r16 = r21
                r17 = -1
                r18 = -1
                r16.<init>(r17, r18)
                r14.setLayoutParams(r15)
                r14 = r0
                r15 = 4
                r14.setVisibility(r15)
                r14 = r0
                java.lang.String r15 = "search_layout"
                r14.setTag(r15)
                yt.DeepHost.Search_View.Layout.design_size r14 = new yt.DeepHost.Search_View.Layout.design_size
                r21 = r14
                r14 = r21
                r15 = r21
                r16 = r1
                r15.<init>(r16)
                r2 = r14
                android.view.View r14 = new android.view.View
                r21 = r14
                r14 = r21
                r15 = r21
                r16 = r1
                r15.<init>(r16)
                r3 = r14
                r14 = r3
                java.lang.String r15 = "transparent_view"
                r14.setTag(r15)
                r14 = r3
                android.widget.FrameLayout$LayoutParams r15 = new android.widget.FrameLayout$LayoutParams
                r21 = r15
                r15 = r21
                r16 = r21
                r17 = -1
                r18 = -1
                r16.<init>(r17, r18)
                r14.setLayoutParams(r15)
                r14 = r3
                java.lang.String r15 = "#50000000"
                int r15 = android.graphics.Color.parseColor(r15)
                r14.setBackgroundColor(r15)
                r14 = r3
                r15 = 8
                r14.setVisibility(r15)
                android.widget.LinearLayout r14 = new android.widget.LinearLayout
                r21 = r14
                r14 = r21
                r15 = r21
                r16 = r1
                r15.<init>(r16)
                r4 = r14
                r14 = r4
                android.widget.FrameLayout$LayoutParams r15 = new android.widget.FrameLayout$LayoutParams
                r21 = r15
                r15 = r21
                r16 = r21
                r17 = -1
                r18 = -1
                r16.<init>(r17, r18)
                r14.setLayoutParams(r15)
                r14 = r4
                r15 = 1
                r14.setOrientation(r15)
                android.widget.RelativeLayout r14 = new android.widget.RelativeLayout
                r21 = r14
                r14 = r21
                r15 = r21
                r16 = r1
                r15.<init>(r16)
                r5 = r14
                r14 = r5
                java.lang.String r15 = "search_top_bar"
                r14.setTag(r15)
                r14 = r5
                android.widget.RelativeLayout$LayoutParams r15 = new android.widget.RelativeLayout$LayoutParams
                r21 = r15
                r15 = r21
                r16 = r21
                r17 = -1
                r18 = r2
                r19 = 60
                int r18 = r18.getPixels(r19)
                r16.<init>(r17, r18)
                r14.setLayoutParams(r15)
                r14 = r5
                r15 = -1
                r14.setBackgroundColor(r15)
                r14 = r5
                r15 = 17
                r14.setGravity(r15)
                android.widget.EditText r14 = new android.widget.EditText
                r21 = r14
                r14 = r21
                r15 = r21
                r16 = r1
                r15.<init>(r16)
                r6 = r14
                r14 = r6
                java.lang.String r15 = "searchTextView"
                r14.setTag(r15)
                r14 = r6
                android.widget.RelativeLayout$LayoutParams r15 = new android.widget.RelativeLayout$LayoutParams
                r21 = r15
                r15 = r21
                r16 = r21
                r17 = -1
                r18 = -1
                r16.<init>(r17, r18)
                r14.setLayoutParams(r15)
                r14 = r6
                r15 = 0
                r14.setBackground(r15)
                r14 = r6
                java.lang.String r15 = "Search..."
                r14.setHint(r15)
                r14 = r6
                r15 = 3
                r14.setImeOptions(r15)
                r14 = r6
                r15 = 524288(0x80000, float:7.34684E-40)
                r14.setInputType(r15)
                r14 = r6
                r15 = r2
                r16 = 65
                int r15 = r15.getPixels(r16)
                r16 = 0
                r17 = r2
                r18 = 65
                int r17 = r17.getPixels(r18)
                r18 = 0
                r14.setPadding(r15, r16, r17, r18)
                r14 = r6
                r15 = 1
                r14.setSingleLine(r15)
                r14 = r6
                java.lang.String r15 = "#212121"
                int r15 = android.graphics.Color.parseColor(r15)
                r14.setTextColor(r15)
                r14 = r6
                java.lang.String r15 = "#727272"
                int r15 = android.graphics.Color.parseColor(r15)
                r14.setHintTextColor(r15)
                r14 = r6
                r15 = 1098907648(0x41800000, float:16.0)
                r14.setTextSize(r15)
                android.widget.ImageView r14 = new android.widget.ImageView
                r21 = r14
                r14 = r21
                r15 = r21
                r16 = r1
                r15.<init>(r16)
                r7 = r14
                r14 = r7
                java.lang.String r15 = "action_up_btn"
                r14.setTag(r15)
                android.widget.RelativeLayout$LayoutParams r14 = new android.widget.RelativeLayout$LayoutParams
                r21 = r14
                r14 = r21
                r15 = r21
                android.widget.FrameLayout$LayoutParams r16 = new android.widget.FrameLayout$LayoutParams
                r21 = r16
                r16 = r21
                r17 = r21
                r18 = r2
                r19 = 45
                int r18 = r18.getPixels(r19)
                r19 = r2
                r20 = 45
                int r19 = r19.getPixels(r20)
                r17.<init>(r18, r19)
                r15.<init>(r16)
                r8 = r14
                r14 = r8
                r15 = 15
                r14.addRule(r15)
                r14 = r7
                r15 = r8
                r14.setLayoutParams(r15)
                r14 = r7
                r15 = r2
                r16 = 5
                int r15 = r15.getPixels(r16)
                r16 = 0
                r17 = r2
                r18 = 5
                int r17 = r17.getPixels(r18)
                r18 = 0
                r14.setPadding(r15, r16, r17, r18)
                r14 = r7
                r15 = -1
                r14.setBackgroundColor(r15)
                r14 = r7
                r15 = r1
                java.lang.String r16 = "ic_action_navigation_arrow_back.png"
                android.graphics.Bitmap r15 = yt.DeepHost.Search_View.Layout.isReple.mode(r15, r16)
                r14.setImageBitmap(r15)
                android.widget.ImageView r14 = new android.widget.ImageView
                r21 = r14
                r14 = r21
                r15 = r21
                r16 = r1
                r15.<init>(r16)
                r9 = r14
                r14 = r9
                java.lang.String r15 = "action_empty_btn"
                r14.setTag(r15)
                android.widget.RelativeLayout$LayoutParams r14 = new android.widget.RelativeLayout$LayoutParams
                r21 = r14
                r14 = r21
                r15 = r21
                android.widget.FrameLayout$LayoutParams r16 = new android.widget.FrameLayout$LayoutParams
                r21 = r16
                r16 = r21
                r17 = r21
                r18 = r2
                r19 = 45
                int r18 = r18.getPixels(r19)
                r19 = r2
                r20 = 45
                int r19 = r19.getPixels(r20)
                r17.<init>(r18, r19)
                r15.<init>(r16)
                r10 = r14
                r14 = r10
                r15 = 21
                r14.addRule(r15)
                r14 = r10
                r15 = 11
                r14.addRule(r15)
                r14 = r9
                r15 = r10
                r14.setLayoutParams(r15)
                r14 = r9
                r15 = r2
                r16 = 5
                int r15 = r15.getPixels(r16)
                r16 = 0
                r17 = r2
                r18 = 5
                int r17 = r17.getPixels(r18)
                r18 = 0
                r14.setPadding(r15, r16, r17, r18)
                r14 = r9
                r15 = -1
                r14.setBackgroundColor(r15)
                r14 = r9
                r15 = r1
                java.lang.String r16 = "ic_action_navigation_close.png"
                android.graphics.Bitmap r15 = yt.DeepHost.Search_View.Layout.isReple.mode(r15, r16)
                r14.setImageBitmap(r15)
                r14 = r9
                r15 = 8
                r14.setVisibility(r15)
                android.view.View r14 = new android.view.View
                r21 = r14
                r14 = r21
                r15 = r21
                r16 = r1
                r15.<init>(r16)
                r11 = r14
                android.widget.RelativeLayout$LayoutParams r14 = new android.widget.RelativeLayout$LayoutParams
                r21 = r14
                r14 = r21
                r15 = r21
                r16 = -1
                r17 = r2
                r18 = 1
                int r17 = r17.getPixels(r18)
                r15.<init>(r16, r17)
                r12 = r14
                r14 = r12
                r15 = 12
                r14.addRule(r15)
                r14 = r11
                r15 = r12
                r14.setLayoutParams(r15)
                r14 = r11
                r15 = -1
                r14.setBackgroundColor(r15)
                r14 = r11
                java.lang.String r15 = "#10000000"
                int r15 = android.graphics.Color.parseColor(r15)
                android.content.res.ColorStateList r15 = android.content.res.ColorStateList.valueOf(r15)
                r14.setBackgroundTintList(r15)
                android.widget.ListView r14 = new android.widget.ListView
                r21 = r14
                r14 = r21
                r15 = r21
                r16 = r1
                r15.<init>(r16)
                r13 = r14
                r14 = r13
                java.lang.String r15 = "suggestion_list"
                r14.setTag(r15)
                r14 = r13
                android.widget.LinearLayout$LayoutParams r15 = new android.widget.LinearLayout$LayoutParams
                r21 = r15
                r15 = r21
                r16 = r21
                r17 = -1
                r18 = -2
                r16.<init>(r17, r18)
                r14.setLayoutParams(r15)
                r14 = r6
                r15 = -1
                r14.setBackgroundColor(r15)
                r14 = r13
                r15 = 0
                r14.setDivider(r15)
                r14 = r0
                r15 = r3
                r14.addView(r15)
                r14 = r4
                r15 = r5
                r14.addView(r15)
                r14 = r5
                r15 = r6
                r14.addView(r15)
                r14 = r5
                r15 = r7
                r14.addView(r15)
                r14 = r5
                r15 = r9
                r14.addView(r15)
                r14 = r5
                r15 = r11
                r14.addView(r15)
                r14 = r4
                r15 = r13
                r14.addView(r15)
                r14 = r0
                r15 = r4
                r14.addView(r15)
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: yt.DeepHost.Search_View.Layout.search_view.layout.<init>(android.content.Context):void");
        }
    }
}
