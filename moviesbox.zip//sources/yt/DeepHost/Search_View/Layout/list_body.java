package yt.DeepHost.Search_View.Layout;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

public class list_body {
    public list_body() {
    }

    public static class layout extends LinearLayout {
        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        @SuppressLint({"WrongConstant"})
        public layout(Context context, View view) {
            super(context);
            ViewGroup.LayoutParams layoutParams;
            View adview = view;
            new LinearLayout.LayoutParams(-2, -2);
            setLayoutParams(layoutParams);
            setOrientation(1);
            if (adview != null) {
                addView(adview);
            }
        }
    }
}
