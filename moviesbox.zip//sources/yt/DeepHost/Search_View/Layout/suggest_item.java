package yt.DeepHost.Search_View.Layout;

import android.widget.LinearLayout;

public class suggest_item {
    public suggest_item() {
    }

    public static class layout extends LinearLayout {
        /* JADX WARNING: Illegal instructions before constructor call */
        @android.annotation.SuppressLint({"WrongConstant"})
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public layout(android.content.Context r13) {
            /*
                r12 = this;
                r0 = r12
                r1 = r13
                r5 = r0
                r6 = r1
                r5.<init>(r6)
                r5 = r0
                r6 = -1
                r5.setBackgroundColor(r6)
                r5 = r0
                r6 = 0
                r5.setOrientation(r6)
                r5 = r0
                r6 = 19
                r5.setGravity(r6)
                yt.DeepHost.Search_View.Layout.design_size r5 = new yt.DeepHost.Search_View.Layout.design_size
                r11 = r5
                r5 = r11
                r6 = r11
                r7 = r1
                r6.<init>(r7)
                r2 = r5
                r5 = r0
                android.widget.LinearLayout$LayoutParams r6 = new android.widget.LinearLayout$LayoutParams
                r11 = r6
                r6 = r11
                r7 = r11
                r8 = -1
                r9 = r2
                r10 = 60
                int r9 = r9.getPixels(r10)
                r7.<init>(r8, r9)
                r5.setLayoutParams(r6)
                android.widget.TextView r5 = new android.widget.TextView
                r11 = r5
                r5 = r11
                r6 = r11
                r7 = r1
                r6.<init>(r7)
                r3 = r5
                r5 = r3
                r6 = 19
                r5.setGravity(r6)
                r5 = r3
                java.lang.String r6 = "suggestion_text"
                r5.setTag(r6)
                r5 = r3
                android.widget.LinearLayout$LayoutParams r6 = new android.widget.LinearLayout$LayoutParams
                r11 = r6
                r6 = r11
                r7 = r11
                r8 = -2
                r9 = -1
                r7.<init>(r8, r9)
                r5.setLayoutParams(r6)
                r5 = r3
                r6 = 0
                r7 = 0
                r8 = r2
                r9 = 65
                int r8 = r8.getPixels(r9)
                r9 = 0
                r5.setPadding(r6, r7, r8, r9)
                r5 = r3
                java.lang.String r6 = "#727272"
                int r6 = android.graphics.Color.parseColor(r6)
                r5.setTextColor(r6)
                r5 = r3
                r6 = 0
                r5.setFocusable(r6)
                r5 = r3
                r6 = 1098907648(0x41800000, float:16.0)
                r5.setTextSize(r6)
                android.widget.ImageView r5 = new android.widget.ImageView
                r11 = r5
                r5 = r11
                r6 = r11
                r7 = r1
                r6.<init>(r7)
                r4 = r5
                r5 = r4
                java.lang.String r6 = "suggestion_icon"
                r5.setTag(r6)
                r5 = r4
                android.widget.LinearLayout$LayoutParams r6 = new android.widget.LinearLayout$LayoutParams
                r11 = r6
                r6 = r11
                r7 = r11
                r8 = r2
                r9 = 45
                int r8 = r8.getPixels(r9)
                r9 = r2
                r10 = 45
                int r9 = r9.getPixels(r10)
                r7.<init>(r8, r9)
                r5.setLayoutParams(r6)
                r5 = r4
                r6 = 0
                r5.setBackgroundColor(r6)
                r5 = r4
                r6 = r2
                r7 = 12
                int r6 = r6.getPixels(r7)
                r7 = 0
                r8 = r2
                r9 = 12
                int r8 = r8.getPixels(r9)
                r9 = 0
                r5.setPadding(r6, r7, r8, r9)
                r5 = r4
                r6 = 0
                r5.setFocusable(r6)
                r5 = r4
                r6 = r1
                java.lang.String r7 = "ic_search_icon.png"
                android.graphics.Bitmap r6 = yt.DeepHost.Search_View.Layout.isReple.mode(r6, r7)
                r5.setImageBitmap(r6)
                r5 = r0
                r6 = r4
                r5.addView(r6)
                r5 = r0
                r6 = r3
                r5.addView(r6)
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: yt.DeepHost.Search_View.Layout.suggest_item.layout.<init>(android.content.Context):void");
        }
    }
}
