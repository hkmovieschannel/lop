package yt.DeepHost.Search_View.Layout;

import android.content.Context;
import android.util.DisplayMetrics;

public class design_size {
    int alto = (this.ancho + ((this.ancho * 9) / 16));
    int altoImagen = ((this.ancho * 9) / 16);
    int ancho = (this.width - (getPixels(8) * 2));
    float density = this.display.density;
    DisplayMetrics display;
    int height = this.display.heightPixels;
    int width = this.display.widthPixels;

    public design_size(Context context) {
        this.display = context.getResources().getDisplayMetrics();
    }

    public int getPixels(int dp) {
        return (int) (((float) dp) * this.density);
    }
}
