package yt.DeepHost.Search_View.Layout;

import android.widget.LinearLayout;

public class activity_main {
    public activity_main() {
    }

    public static class layout extends LinearLayout {
        /* JADX WARNING: Illegal instructions before constructor call */
        @android.annotation.SuppressLint({"WrongConstant"})
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public layout(android.content.Context r12) {
            /*
                r11 = this;
                r0 = r11
                r1 = r12
                r5 = r0
                r6 = r1
                r5.<init>(r6)
                r5 = r0
                r6 = -1
                r5.setBackgroundColor(r6)
                r5 = r0
                android.widget.LinearLayout$LayoutParams r6 = new android.widget.LinearLayout$LayoutParams
                r10 = r6
                r6 = r10
                r7 = r10
                r8 = -1
                r9 = -1
                r7.<init>(r8, r9)
                r5.setLayoutParams(r6)
                r5 = r0
                r6 = 1
                r5.setOrientation(r6)
                android.widget.FrameLayout r5 = new android.widget.FrameLayout
                r10 = r5
                r5 = r10
                r6 = r10
                r7 = r1
                r6.<init>(r7)
                r2 = r5
                r5 = r2
                android.widget.FrameLayout$LayoutParams r6 = new android.widget.FrameLayout$LayoutParams
                r10 = r6
                r6 = r10
                r7 = r10
                r8 = -1
                r9 = -2
                r7.<init>(r8, r9)
                r5.setLayoutParams(r6)
                yt.DeepHost.Search_View.searchview.SearchView r5 = new yt.DeepHost.Search_View.searchview.SearchView
                r10 = r5
                r5 = r10
                r6 = r10
                r7 = r1
                r6.<init>(r7)
                r3 = r5
                r5 = r3
                android.widget.FrameLayout$LayoutParams r6 = new android.widget.FrameLayout$LayoutParams
                r10 = r6
                r6 = r10
                r7 = r10
                r8 = -1
                r9 = -2
                r7.<init>(r8, r9)
                r5.setLayoutParams(r6)
                r5 = r3
                java.lang.String r6 = "search_view"
                r5.setTag(r6)
                r5 = r2
                r6 = r3
                r5.addView(r6)
                r5 = r0
                r6 = r2
                r5.addView(r6)
                android.widget.LinearLayout r5 = new android.widget.LinearLayout
                r10 = r5
                r5 = r10
                r6 = r10
                r7 = r1
                r6.<init>(r7)
                r4 = r5
                r5 = r4
                android.widget.FrameLayout$LayoutParams r6 = new android.widget.FrameLayout$LayoutParams
                r10 = r6
                r6 = r10
                r7 = r10
                r8 = -1
                r9 = -1
                r7.<init>(r8, r9)
                r5.setLayoutParams(r6)
                r5 = r0
                r6 = r4
                r5.addView(r6)
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: yt.DeepHost.Search_View.Layout.activity_main.layout.<init>(android.content.Context):void");
        }
    }
}
