package yt.DeepHost.Search_View.searchview;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import java.lang.reflect.Field;
import yt.DeepHost.Search_View.Layout.search_view;
import yt.DeepHost.Search_View.Search_View;
import yt.DeepHost.Search_View.searchview.utils.AnimationUtil;

public class SearchView extends FrameLayout implements Filter.FilterListener {
    public static final int REQUEST_VOICE = 9999;
    private boolean allowVoiceSearch;
    private boolean ellipsize;
    private ListAdapter mAdapter;
    private int mAnimationDuration;
    /* access modifiers changed from: private */
    public ImageView mBackBtn;
    private boolean mClearingFocus;
    private Context mContext;
    /* access modifiers changed from: private */
    public ImageView mEmptyBtn;
    private boolean mIsSearchOpen;
    private MenuItem mMenuItem;
    private CharSequence mOldQueryText;
    private final View.OnClickListener mOnClickListener;
    private OnQueryTextListener mOnQueryChangeListener;
    private SavedState mSavedState;
    private View mSearchLayout;
    /* access modifiers changed from: private */
    public EditText mSearchSrcTextView;
    private RelativeLayout mSearchTopBar;
    /* access modifiers changed from: private */
    public SearchViewListener mSearchViewListener;
    private ListView mSuggestionsListView;
    /* access modifiers changed from: private */
    public View mTintView;
    private CharSequence mUserQuery;
    /* access modifiers changed from: private */
    public boolean submit;
    private Drawable suggestionIcon;

    public interface OnQueryTextListener {
        boolean onQueryTextChange(String str);

        boolean onQueryTextSubmit(String str);
    }

    public interface SearchViewListener {
        void onSearchViewClosed();

        void onSearchViewShown();
    }

    static /* synthetic */ CharSequence access$102(SearchView x0, CharSequence x1) {
        CharSequence charSequence = x1;
        CharSequence charSequence2 = charSequence;
        x0.mUserQuery = charSequence2;
        return charSequence;
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public SearchView(Context context) {
        this(context, (AttributeSet) null);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public SearchView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public SearchView(android.content.Context r10, android.util.AttributeSet r11, int r12) {
        /*
            r9 = this;
            r0 = r9
            r1 = r10
            r2 = r11
            r3 = r12
            r4 = r0
            r5 = r1
            r6 = r2
            r4.<init>(r5, r6)
            r4 = r0
            r5 = 0
            r4.mIsSearchOpen = r5
            r4 = r0
            r5 = 0
            r4.submit = r5
            r4 = r0
            r5 = 0
            r4.ellipsize = r5
            r4 = r0
            yt.DeepHost.Search_View.searchview.SearchView$4 r5 = new yt.DeepHost.Search_View.searchview.SearchView$4
            r8 = r5
            r5 = r8
            r6 = r8
            r7 = r0
            r6.<init>(r7)
            r4.mOnClickListener = r5
            r4 = r0
            r5 = r1
            r4.mContext = r5
            r4 = r0
            r4.initiateView()
            r4 = r0
            r5 = r2
            r6 = r3
            r4.initStyle(r5, r6)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: yt.DeepHost.Search_View.searchview.SearchView.<init>(android.content.Context, android.util.AttributeSet, int):void");
    }

    private void initStyle(AttributeSet attrs, int defStyleAttr) {
    }

    private void initiateView() {
        View view;
        new search_view.layout(this.mContext);
        View view2 = view;
        addView(view2);
        this.mSearchLayout = view2;
        this.mSearchTopBar = (RelativeLayout) view2.findViewWithTag("search_top_bar");
        this.mSuggestionsListView = (ListView) view2.findViewWithTag("suggestion_list");
        this.mSearchSrcTextView = (EditText) view2.findViewWithTag("searchTextView");
        this.mBackBtn = (ImageView) view2.findViewWithTag("action_up_btn");
        this.mEmptyBtn = (ImageView) view2.findViewWithTag("action_empty_btn");
        this.mTintView = view2.findViewWithTag("transparent_view");
        this.mSearchSrcTextView.setOnClickListener(this.mOnClickListener);
        this.mBackBtn.setOnClickListener(this.mOnClickListener);
        this.mEmptyBtn.setOnClickListener(this.mOnClickListener);
        this.mTintView.setOnClickListener(this.mOnClickListener);
        this.allowVoiceSearch = false;
        initSearchView();
        this.mSuggestionsListView.setVisibility(8);
        setAnimationDuration(AnimationUtil.ANIMATION_DURATION_MEDIUM);
    }

    private void initSearchView() {
        TextView.OnEditorActionListener onEditorActionListener;
        TextWatcher textWatcher;
        View.OnFocusChangeListener onFocusChangeListener;
        new TextView.OnEditorActionListener(this) {
            final /* synthetic */ SearchView this$0;

            {
                this.this$0 = this$0;
            }

            public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
                TextView textView2 = textView;
                int i2 = i;
                KeyEvent keyEvent2 = keyEvent;
                this.this$0.onSubmitQuery();
                return true;
            }
        };
        this.mSearchSrcTextView.setOnEditorActionListener(onEditorActionListener);
        new TextWatcher(this) {
            final /* synthetic */ SearchView this$0;

            {
                this.this$0 = this$0;
            }

            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                CharSequence s = charSequence;
                int i4 = i;
                int i5 = i2;
                int i6 = i3;
                CharSequence access$102 = SearchView.access$102(this.this$0, s);
                this.this$0.startFilter(s);
                this.this$0.onTextChanged(s);
            }

            public void afterTextChanged(Editable s) {
            }
        };
        this.mSearchSrcTextView.addTextChangedListener(textWatcher);
        new View.OnFocusChangeListener(this) {
            final /* synthetic */ SearchView this$0;

            {
                this.this$0 = this$0;
            }

            public void onFocusChange(View view, boolean hasFocus) {
                View view2 = view;
                if (hasFocus) {
                    this.this$0.showKeyboard(this.this$0.mSearchSrcTextView);
                    this.this$0.showSuggestions();
                }
            }
        };
        this.mSearchSrcTextView.setOnFocusChangeListener(onFocusChangeListener);
    }

    /* access modifiers changed from: private */
    public void startFilter(CharSequence charSequence) {
        CharSequence s = charSequence;
        if (this.mAdapter != null && (this.mAdapter instanceof Filterable)) {
            ((Filterable) this.mAdapter).getFilter().filter(s, this);
        }
    }

    private void onVoiceClicked() {
        Intent intent;
        new Intent("android.speech.action.RECOGNIZE_SPEECH");
        Intent intent2 = intent;
        Intent putExtra = intent2.putExtra("android.speech.extra.LANGUAGE_MODEL", "web_search");
        Intent putExtra2 = intent2.putExtra("android.speech.extra.MAX_RESULTS", 1);
        if (this.mContext instanceof Activity) {
            ((Activity) this.mContext).startActivityForResult(intent2, REQUEST_VOICE);
        }
    }

    /* access modifiers changed from: private */
    public void onTextChanged(CharSequence charSequence) {
        CharSequence newText = charSequence;
        CharSequence text = this.mSearchSrcTextView.getText();
        this.mUserQuery = text;
        if (!TextUtils.isEmpty(text)) {
            this.mEmptyBtn.setVisibility(0);
        } else {
            this.mEmptyBtn.setVisibility(8);
        }
        if (this.mOnQueryChangeListener != null && !TextUtils.equals(newText, this.mOldQueryText)) {
            boolean onQueryTextChange = this.mOnQueryChangeListener.onQueryTextChange(newText.toString());
        }
        this.mOldQueryText = newText.toString();
    }

    /* access modifiers changed from: private */
    public void onSubmitQuery() {
        CharSequence query = this.mSearchSrcTextView.getText();
        if (query != null && TextUtils.getTrimmedLength(query) > 0) {
            if (this.mOnQueryChangeListener == null || !this.mOnQueryChangeListener.onQueryTextSubmit(query.toString())) {
                closeSearch();
                this.mSearchSrcTextView.setText((CharSequence) null);
            }
        }
    }

    private boolean isVoiceAvailable() {
        Intent intent;
        if (isInEditMode()) {
            return true;
        }
        new Intent("android.speech.action.RECOGNIZE_SPEECH");
        return getContext().getPackageManager().queryIntentActivities(intent, 0).size() == 0;
    }

    public void hideKeyboard(View view) {
        View view2 = view;
        boolean hideSoftInputFromWindow = ((InputMethodManager) view2.getContext().getSystemService("input_method")).hideSoftInputFromWindow(view2.getWindowToken(), 0);
    }

    public void showKeyboard(View view) {
        View view2 = view;
        if (Build.VERSION.SDK_INT <= 10 && view2.hasFocus()) {
            view2.clearFocus();
        }
        boolean requestFocus = view2.requestFocus();
        boolean showSoftInput = ((InputMethodManager) view2.getContext().getSystemService("input_method")).showSoftInput(view2, 0);
    }

    public void setBackground(Drawable drawable) {
        Drawable background = drawable;
        if (Build.VERSION.SDK_INT >= 16) {
            this.mSearchTopBar.setBackground(background);
        } else {
            this.mSearchTopBar.setBackgroundDrawable(background);
        }
    }

    public void setBackgroundColor(int color) {
        this.mSearchTopBar.setBackgroundColor(color);
    }

    public void setTextColor(int color) {
        this.mSearchSrcTextView.setTextColor(color);
    }

    public void setHintTextColor(int color) {
        this.mSearchSrcTextView.setHintTextColor(color);
    }

    public void setHint(CharSequence hint) {
        this.mSearchSrcTextView.setHint(hint);
    }

    public void setCloseIcon(Drawable drawable) {
        this.mEmptyBtn.setImageDrawable(drawable);
    }

    public void setBackIcon(Drawable drawable) {
        this.mBackBtn.setImageDrawable(drawable);
    }

    public void setSuggestionIcon(Drawable drawable) {
        Drawable drawable2 = drawable;
        this.suggestionIcon = drawable2;
    }

    public void setInputType(int inputType) {
        this.mSearchSrcTextView.setInputType(inputType);
    }

    public void setSuggestionBackground(Drawable drawable) {
        Drawable background = drawable;
        if (Build.VERSION.SDK_INT >= 16) {
            this.mSuggestionsListView.setBackground(background);
        } else {
            this.mSuggestionsListView.setBackgroundDrawable(background);
        }
    }

    public void setCursorDrawable(int i) {
        int drawable = i;
        try {
            Field f = TextView.class.getDeclaredField("mCursorDrawableRes");
            f.setAccessible(true);
            f.set(this.mSearchSrcTextView, Integer.valueOf(drawable));
        } catch (Exception e) {
            int e2 = Log.e("MaterialSearchView", e.toString());
        }
    }

    public void setVoiceSearch(boolean voiceSearch) {
        boolean z = voiceSearch;
        this.allowVoiceSearch = z;
    }

    public void showSuggestions() {
        if (this.mAdapter != null && this.mAdapter.getCount() > 0 && this.mSuggestionsListView.getVisibility() == 8) {
            this.mSuggestionsListView.setVisibility(0);
        }
    }

    public void setSubmitOnClick(boolean submit2) {
        boolean z = submit2;
        this.submit = z;
    }

    public void setOnItemClickListener(AdapterView.OnItemClickListener listener) {
        this.mSuggestionsListView.setOnItemClickListener(listener);
    }

    public void setAdapter(ListAdapter listAdapter) {
        ListAdapter adapter = listAdapter;
        this.mAdapter = adapter;
        this.mSuggestionsListView.setAdapter(adapter);
        startFilter(this.mSearchSrcTextView.getText());
    }

    public void setSuggestions(String[] strArr) {
        SearchAdapter searchAdapter;
        AdapterView.OnItemClickListener onItemClickListener;
        String[] suggestions = strArr;
        if (suggestions == null || suggestions.length <= 0) {
            this.mTintView.setVisibility(8);
            return;
        }
        this.mTintView.setVisibility(0);
        new SearchAdapter(this.mContext, suggestions, this.suggestionIcon, this.ellipsize);
        SearchAdapter adapter = searchAdapter;
        setAdapter(adapter);
        final SearchAdapter searchAdapter2 = adapter;
        new AdapterView.OnItemClickListener(this) {
            final /* synthetic */ SearchView this$0;

            {
                this.this$0 = this$0;
            }

            public void onItemClick(AdapterView<?> adapterView, View view, int position, long j) {
                AdapterView<?> adapterView2 = adapterView;
                View view2 = view;
                long j2 = j;
                this.this$0.setQuery((String) searchAdapter2.getItem(position), this.this$0.submit);
                if (Search_View.auto_submit) {
                    this.this$0.onSubmitQuery();
                }
            }
        };
        setOnItemClickListener(onItemClickListener);
    }

    public void dismissSuggestions() {
        if (this.mSuggestionsListView.getVisibility() == 0) {
            this.mSuggestionsListView.setVisibility(8);
        }
    }

    public void setQuery(CharSequence charSequence, boolean z) {
        CharSequence query = charSequence;
        boolean submit2 = z;
        this.mSearchSrcTextView.setText(query);
        if (query != null) {
            this.mSearchSrcTextView.setSelection(this.mSearchSrcTextView.length());
            this.mUserQuery = query;
        }
        if (submit2 && !TextUtils.isEmpty(query)) {
            onSubmitQuery();
        }
    }

    public void setMenuItem(MenuItem menuItem) {
        MenuItem.OnMenuItemClickListener onMenuItemClickListener;
        this.mMenuItem = menuItem;
        new MenuItem.OnMenuItemClickListener(this) {
            final /* synthetic */ SearchView this$0;

            {
                this.this$0 = this$0;
            }

            public boolean onMenuItemClick(MenuItem menuItem) {
                MenuItem menuItem2 = menuItem;
                this.this$0.showSearch();
                return true;
            }
        };
        MenuItem onMenuItemClickListener2 = this.mMenuItem.setOnMenuItemClickListener(onMenuItemClickListener);
    }

    public boolean isSearchOpen() {
        return this.mIsSearchOpen;
    }

    public void setAnimationDuration(int duration) {
        int i = duration;
        this.mAnimationDuration = i;
    }

    public void showSearch() {
        showSearch(true);
    }

    public void showSearch(boolean z) {
        boolean animate = z;
        if (!isSearchOpen()) {
            this.mSearchSrcTextView.setText((CharSequence) null);
            boolean requestFocus = this.mSearchSrcTextView.requestFocus();
            if (animate) {
                setVisibleWithAnimation();
            } else {
                this.mSearchLayout.setVisibility(0);
                if (this.mSearchViewListener != null) {
                    this.mSearchViewListener.onSearchViewShown();
                }
            }
            this.mIsSearchOpen = true;
        }
    }

    private void setVisibleWithAnimation() {
        AnimationUtil.AnimationListener animationListener;
        new AnimationUtil.AnimationListener(this) {
            final /* synthetic */ SearchView this$0;

            {
                this.this$0 = this$0;
            }

            public boolean onAnimationStart(View view) {
                View view2 = view;
                return false;
            }

            public boolean onAnimationEnd(View view) {
                View view2 = view;
                if (this.this$0.mSearchViewListener != null) {
                    this.this$0.mSearchViewListener.onSearchViewShown();
                }
                return false;
            }

            public boolean onAnimationCancel(View view) {
                View view2 = view;
                return false;
            }
        };
        AnimationUtil.AnimationListener animationListener2 = animationListener;
        if (Build.VERSION.SDK_INT >= 21) {
            this.mSearchLayout.setVisibility(0);
            AnimationUtil.reveal(this.mSearchTopBar, animationListener2);
            return;
        }
        AnimationUtil.fadeInView(this.mSearchLayout, this.mAnimationDuration, animationListener2);
    }

    public void closeSearch() {
        if (isSearchOpen()) {
            this.mSearchSrcTextView.setText((CharSequence) null);
            dismissSuggestions();
            clearFocus();
            this.mSearchLayout.setVisibility(8);
            if (this.mSearchViewListener != null) {
                this.mSearchViewListener.onSearchViewClosed();
            }
            this.mIsSearchOpen = false;
        }
    }

    public void setOnQueryTextListener(OnQueryTextListener listener) {
        OnQueryTextListener onQueryTextListener = listener;
        this.mOnQueryChangeListener = onQueryTextListener;
    }

    public void setOnSearchViewListener(SearchViewListener listener) {
        SearchViewListener searchViewListener = listener;
        this.mSearchViewListener = searchViewListener;
    }

    public void setEllipsize(boolean ellipsize2) {
        boolean z = ellipsize2;
        this.ellipsize = z;
    }

    public void onFilterComplete(int count) {
        if (count > 0) {
            showSuggestions();
        } else {
            dismissSuggestions();
        }
    }

    public boolean requestFocus(int i, Rect rect) {
        int direction = i;
        Rect previouslyFocusedRect = rect;
        if (this.mClearingFocus) {
            return false;
        }
        if (!isFocusable()) {
            return false;
        }
        return this.mSearchSrcTextView.requestFocus(direction, previouslyFocusedRect);
    }

    public void clearFocus() {
        this.mClearingFocus = true;
        hideKeyboard(this);
        super.clearFocus();
        this.mSearchSrcTextView.clearFocus();
        this.mClearingFocus = false;
    }

    public Parcelable onSaveInstanceState() {
        SavedState savedState;
        new SavedState(super.onSaveInstanceState());
        this.mSavedState = savedState;
        this.mSavedState.query = this.mUserQuery != null ? this.mUserQuery.toString() : null;
        this.mSavedState.isSearchOpen = this.mIsSearchOpen;
        return this.mSavedState;
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        Parcelable state = parcelable;
        if (!(state instanceof SavedState)) {
            super.onRestoreInstanceState(state);
            return;
        }
        this.mSavedState = (SavedState) state;
        if (this.mSavedState.isSearchOpen) {
            showSearch(false);
            setQuery(this.mSavedState.query, false);
        }
        super.onRestoreInstanceState(this.mSavedState.getSuperState());
    }

    static class SavedState extends View.BaseSavedState {
        public static final Parcelable.Creator<SavedState> CREATOR;
        boolean isSearchOpen;
        String query;

        /* JADX INFO: this call moved to the top of the method (can break code semantics) */
        /* synthetic */ SavedState(Parcel x0, AnonymousClass1 r7) {
            this(x0);
            AnonymousClass1 r2 = r7;
        }

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        SavedState(Parcelable superState) {
            super(superState);
        }

        /* JADX WARNING: Illegal instructions before constructor call */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        private SavedState(android.os.Parcel r6) {
            /*
                r5 = this;
                r0 = r5
                r1 = r6
                r2 = r0
                r3 = r1
                r2.<init>(r3)
                r2 = r0
                r3 = r1
                java.lang.String r3 = r3.readString()
                r2.query = r3
                r2 = r0
                r3 = r1
                int r3 = r3.readInt()
                r4 = 1
                if (r3 != r4) goto L_0x001c
                r3 = 1
            L_0x0019:
                r2.isSearchOpen = r3
                return
            L_0x001c:
                r3 = 0
                goto L_0x0019
            */
            throw new UnsupportedOperationException("Method not decompiled: yt.DeepHost.Search_View.searchview.SearchView.SavedState.<init>(android.os.Parcel):void");
        }

        public void writeToParcel(Parcel parcel, int flags) {
            Parcel out = parcel;
            super.writeToParcel(out, flags);
            out.writeString(this.query);
            out.writeInt(this.isSearchOpen ? 1 : 0);
        }

        static {
            Parcelable.Creator<SavedState> creator;
            new Parcelable.Creator<SavedState>() {
                public SavedState createFromParcel(Parcel in) {
                    SavedState savedState;
                    new SavedState(in, (AnonymousClass1) null);
                    return savedState;
                }

                public SavedState[] newArray(int size) {
                    return new SavedState[size];
                }
            };
            CREATOR = creator;
        }
    }
}
