package yt.DeepHost.Search_View.searchview.utils;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.TargetApi;
import android.support.v4.view.ViewCompat;
import android.support.v4.view.ViewPropertyAnimatorCompat;
import android.support.v4.view.ViewPropertyAnimatorListener;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewAnimationUtils;

public class AnimationUtil {
    public static int ANIMATION_DURATION_LONG = 800;
    public static int ANIMATION_DURATION_MEDIUM = 400;
    public static int ANIMATION_DURATION_SHORT = 150;

    public interface AnimationListener {
        boolean onAnimationCancel(View view);

        boolean onAnimationEnd(View view);

        boolean onAnimationStart(View view);
    }

    public AnimationUtil() {
    }

    public static void crossFadeViews(View showView, View hideView) {
        crossFadeViews(showView, hideView, ANIMATION_DURATION_SHORT);
    }

    public static void crossFadeViews(View showView, View hideView, int i) {
        int duration = i;
        fadeInView(showView, duration);
        fadeOutView(hideView, duration);
    }

    public static void fadeInView(View view) {
        fadeInView(view, ANIMATION_DURATION_SHORT);
    }

    public static void fadeInView(View view, int duration) {
        fadeInView(view, duration, (AnimationListener) null);
    }

    public static void fadeInView(View view, int i, AnimationListener animationListener) {
        ViewPropertyAnimatorListener viewPropertyAnimatorListener;
        View view2 = view;
        int duration = i;
        AnimationListener listener = animationListener;
        view2.setVisibility(0);
        view2.setAlpha(0.0f);
        ViewPropertyAnimatorListener vpListener = null;
        if (listener != null) {
            final AnimationListener animationListener2 = listener;
            new ViewPropertyAnimatorListener() {
                public void onAnimationStart(View view) {
                    View view2 = view;
                    if (!animationListener2.onAnimationStart(view2)) {
                        view2.setDrawingCacheEnabled(true);
                    }
                }

                public void onAnimationEnd(View view) {
                    View view2 = view;
                    if (!animationListener2.onAnimationEnd(view2)) {
                        view2.setDrawingCacheEnabled(false);
                    }
                }

                public void onAnimationCancel(View view) {
                }
            };
            vpListener = viewPropertyAnimatorListener;
        }
        ViewPropertyAnimatorCompat listener2 = ViewCompat.animate(view2).alpha(1.0f).setDuration((long) duration).setListener(vpListener);
    }

    @TargetApi(21)
    public static void reveal(View view, AnimationListener listener) {
        Animator.AnimatorListener animatorListener;
        View view2 = view;
        Animator anim = ViewAnimationUtils.createCircularReveal(view2, view2.getWidth() - ((int) TypedValue.applyDimension(1, 24.0f, view2.getResources().getDisplayMetrics())), view2.getHeight() / 2, 0.0f, (float) Math.max(view2.getWidth(), view2.getHeight()));
        view2.setVisibility(0);
        final AnimationListener animationListener = listener;
        final View view3 = view2;
        new AnimatorListenerAdapter() {
            public void onAnimationStart(Animator animator) {
                Animator animator2 = animator;
                boolean onAnimationStart = animationListener.onAnimationStart(view3);
            }

            public void onAnimationEnd(Animator animator) {
                Animator animator2 = animator;
                boolean onAnimationEnd = animationListener.onAnimationEnd(view3);
            }

            public void onAnimationCancel(Animator animator) {
                Animator animator2 = animator;
                boolean onAnimationCancel = animationListener.onAnimationCancel(view3);
            }

            public void onAnimationRepeat(Animator animation) {
            }
        };
        anim.addListener(animatorListener);
        anim.start();
    }

    public static void fadeOutView(View view) {
        fadeOutView(view, ANIMATION_DURATION_SHORT);
    }

    public static void fadeOutView(View view, int duration) {
        fadeOutView(view, duration, (AnimationListener) null);
    }

    public static void fadeOutView(View view, int duration, AnimationListener listener) {
        ViewPropertyAnimatorListener viewPropertyAnimatorListener;
        final AnimationListener animationListener = listener;
        new ViewPropertyAnimatorListener() {
            public void onAnimationStart(View view) {
                View view2 = view;
                if (animationListener == null || !animationListener.onAnimationStart(view2)) {
                    view2.setDrawingCacheEnabled(true);
                }
            }

            public void onAnimationEnd(View view) {
                View view2 = view;
                if (animationListener == null || !animationListener.onAnimationEnd(view2)) {
                    view2.setVisibility(8);
                    view2.setDrawingCacheEnabled(false);
                }
            }

            public void onAnimationCancel(View view) {
            }
        };
        ViewPropertyAnimatorCompat listener2 = ViewCompat.animate(view).alpha(0.0f).setDuration((long) duration).setListener(viewPropertyAnimatorListener);
    }
}
