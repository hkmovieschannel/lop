package yt.DeepHost.Search_View.searchview;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;
import yt.DeepHost.Search_View.Layout.isReple;
import yt.DeepHost.Search_View.Layout.suggest_item;

public class SearchAdapter extends BaseAdapter implements Filterable {
    /* access modifiers changed from: private */
    public Context context;
    private ArrayList<String> data;
    private boolean ellipsize;
    private LayoutInflater inflater;
    private Drawable suggestionIcon;
    /* access modifiers changed from: private */
    public String[] suggestions;

    static /* synthetic */ ArrayList access$102(SearchAdapter x0, ArrayList x1) {
        ArrayList arrayList = x1;
        ArrayList arrayList2 = arrayList;
        x0.data = arrayList2;
        return arrayList;
    }

    public SearchAdapter(Context context2, String[] suggestions2) {
        ArrayList<String> arrayList;
        this.inflater = LayoutInflater.from(context2);
        new ArrayList<>();
        this.data = arrayList;
        this.suggestions = suggestions2;
    }

    public SearchAdapter(Context context2, String[] suggestions2, Drawable suggestionIcon2, boolean ellipsize2) {
        ArrayList<String> arrayList;
        Context context3 = context2;
        this.inflater = LayoutInflater.from(context3);
        new ArrayList<>();
        this.data = arrayList;
        this.suggestions = suggestions2;
        this.suggestionIcon = suggestionIcon2;
        this.ellipsize = ellipsize2;
        this.context = context3;
    }

    public Filter getFilter() {
        Filter filter;
        new Filter(this) {
            final /* synthetic */ SearchAdapter this$0;

            {
                this.this$0 = this$0;
            }

            /* access modifiers changed from: protected */
            public Filter.FilterResults performFiltering(CharSequence charSequence) {
                Filter.FilterResults filterResults;
                List<String> list;
                CharSequence constraint = charSequence;
                new Filter.FilterResults();
                Filter.FilterResults filterResults2 = filterResults;
                if (!TextUtils.isEmpty(constraint)) {
                    new ArrayList<>();
                    List<String> searchData = list;
                    String[] access$000 = this.this$0.suggestions;
                    int length = access$000.length;
                    for (int i = 0; i < length; i++) {
                        String string = access$000[i];
                        if (string.toLowerCase().startsWith(constraint.toString().toLowerCase())) {
                            boolean add = searchData.add(string);
                        }
                    }
                    filterResults2.values = searchData;
                    filterResults2.count = searchData.size();
                }
                return filterResults2;
            }

            /* access modifiers changed from: protected */
            public void publishResults(CharSequence charSequence, Filter.FilterResults filterResults) {
                CharSequence charSequence2 = charSequence;
                Filter.FilterResults results = filterResults;
                if (results.values != null) {
                    ArrayList access$102 = SearchAdapter.access$102(this.this$0, (ArrayList) results.values);
                    this.this$0.notifyDataSetChanged();
                }
            }
        };
        return filter;
    }

    public int getCount() {
        return this.data.size();
    }

    public Object getItem(int position) {
        return this.data.get(position);
    }

    public long getItemId(int position) {
        return (long) position;
    }

    public View getView(int i, View view, ViewGroup viewGroup) {
        SuggestionsViewHolder viewHolder;
        View view2;
        SuggestionsViewHolder suggestionsViewHolder;
        int position = i;
        View convertView = view;
        ViewGroup viewGroup2 = viewGroup;
        if (convertView == null) {
            new suggest_item.layout(this.context);
            convertView = view2;
            new SuggestionsViewHolder(this, convertView);
            viewHolder = suggestionsViewHolder;
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (SuggestionsViewHolder) convertView.getTag();
        }
        viewHolder.textView.setText((String) getItem(position));
        if (this.ellipsize) {
            viewHolder.textView.setSingleLine();
            viewHolder.textView.setEllipsize(TextUtils.TruncateAt.END);
        }
        return convertView;
    }

    private class SuggestionsViewHolder {
        ImageView imageView;
        TextView textView;
        final /* synthetic */ SearchAdapter this$0;

        public SuggestionsViewHolder(SearchAdapter searchAdapter, View view) {
            SearchAdapter searchAdapter2 = searchAdapter;
            View convertView = view;
            this.this$0 = searchAdapter2;
            this.textView = (TextView) convertView.findViewWithTag("suggestion_text");
            this.imageView = (ImageView) convertView.findViewWithTag("suggestion_icon");
            this.imageView.setImageBitmap(isReple.mode(searchAdapter2.context, "ic_search_icon.png"));
        }
    }
}
