package yt.DeepHost.Custom_Design_ListView;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.core.view.GravityCompat;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.annotations.UsesPermissions;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.AndroidViewComponent;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.util.YailList;
import java.util.List;
import yt.DeepHost.Custom_Design_ListView.volley.ViewUtil;
import yt.DeepHost.Custom_Design_ListView.volley.toolbox.NetworkImageView;

@SimpleObject(external = true)
@DesignerComponent(category = ComponentCategory.EXTENSION, description = "<p>DeepHost (AndroidX) -  Custom Design ListView Extension <br><br> <a href = \"https://www.youtube.com/c/DeepHost\" target = \"_blank\">Youtube Channel Link</a> </a></p>", iconName = "aiwebres/icon.png", nonVisible = true, version = 7)
@UsesPermissions(permissionNames = "android.permission.INTERNET,android.permission.ACCESS_NETWORK_STATE,android.permission.WRITE_EXTERNAL_STORAGE,android.permission.READ_EXTERNAL_STORAGE")
public final class Custom_Design_ListView extends AndroidNonvisibleComponent implements Component {
    public static final int VERSION = 1;
    private boolean Horizontal_List = false;
    private final Activity activity;
    /* access modifiers changed from: private */
    public Button button;
    /* access modifiers changed from: private */
    public Typeface button_font;
    /* access modifiers changed from: private */
    public LinearLayout cardview;
    private ComponentContainer container;
    /* access modifiers changed from: private */
    public Context context;
    /* access modifiers changed from: private */
    public ImageView imageView;
    /* access modifiers changed from: private */
    public LinearLayout linearLayout;
    /* access modifiers changed from: private */
    public String loading_icon = "";
    /* access modifiers changed from: private */
    public NetworkImageView networkImageView;
    LinearLayout.LayoutParams networkImageView_params;
    /* access modifiers changed from: private */
    public String offline_icon = "";
    /* access modifiers changed from: private */
    public LinearLayout.LayoutParams params_cardview;
    /* access modifiers changed from: private */
    public LinearLayout.LayoutParams params_layout;
    /* access modifiers changed from: private */
    public RelativeLayout relativeLayout_imageView;
    /* access modifiers changed from: private */
    public RelativeLayout relativeLayout_networkImageView;
    /* access modifiers changed from: private */
    public ScrollView scrollView;
    /* access modifiers changed from: private */
    public TextView textView;
    /* access modifiers changed from: private */
    public Typeface text_font;

    static /* synthetic */ ImageView access$1002(Custom_Design_ListView x0, ImageView x1) {
        ImageView imageView2 = x1;
        ImageView imageView3 = imageView2;
        x0.imageView = imageView3;
        return imageView2;
    }

    static /* synthetic */ LinearLayout access$102(Custom_Design_ListView x0, LinearLayout x1) {
        LinearLayout linearLayout2 = x1;
        LinearLayout linearLayout3 = linearLayout2;
        x0.linearLayout = linearLayout3;
        return linearLayout2;
    }

    static /* synthetic */ RelativeLayout access$1102(Custom_Design_ListView x0, RelativeLayout x1) {
        RelativeLayout relativeLayout = x1;
        RelativeLayout relativeLayout2 = relativeLayout;
        x0.relativeLayout_imageView = relativeLayout2;
        return relativeLayout;
    }

    static /* synthetic */ NetworkImageView access$1202(Custom_Design_ListView x0, NetworkImageView x1) {
        NetworkImageView networkImageView2 = x1;
        NetworkImageView networkImageView3 = networkImageView2;
        x0.networkImageView = networkImageView3;
        return networkImageView2;
    }

    static /* synthetic */ RelativeLayout access$1502(Custom_Design_ListView x0, RelativeLayout x1) {
        RelativeLayout relativeLayout = x1;
        RelativeLayout relativeLayout2 = relativeLayout;
        x0.relativeLayout_networkImageView = relativeLayout2;
        return relativeLayout;
    }

    static /* synthetic */ LinearLayout.LayoutParams access$302(Custom_Design_ListView x0, LinearLayout.LayoutParams x1) {
        LinearLayout.LayoutParams layoutParams = x1;
        LinearLayout.LayoutParams layoutParams2 = layoutParams;
        x0.params_layout = layoutParams2;
        return layoutParams;
    }

    static /* synthetic */ LinearLayout access$402(Custom_Design_ListView x0, LinearLayout x1) {
        LinearLayout linearLayout2 = x1;
        LinearLayout linearLayout3 = linearLayout2;
        x0.cardview = linearLayout3;
        return linearLayout2;
    }

    static /* synthetic */ LinearLayout.LayoutParams access$502(Custom_Design_ListView x0, LinearLayout.LayoutParams x1) {
        LinearLayout.LayoutParams layoutParams = x1;
        LinearLayout.LayoutParams layoutParams2 = layoutParams;
        x0.params_cardview = layoutParams2;
        return layoutParams;
    }

    static /* synthetic */ TextView access$602(Custom_Design_ListView x0, TextView x1) {
        TextView textView2 = x1;
        TextView textView3 = textView2;
        x0.textView = textView3;
        return textView2;
    }

    static /* synthetic */ Typeface access$702(Custom_Design_ListView x0, Typeface x1) {
        Typeface typeface = x1;
        Typeface typeface2 = typeface;
        x0.text_font = typeface2;
        return typeface;
    }

    static /* synthetic */ Button access$802(Custom_Design_ListView x0, Button x1) {
        Button button2 = x1;
        Button button3 = button2;
        x0.button = button3;
        return button2;
    }

    static /* synthetic */ Typeface access$902(Custom_Design_ListView x0, Typeface x1) {
        Typeface typeface = x1;
        Typeface typeface2 = typeface;
        x0.button_font = typeface2;
        return typeface;
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public Custom_Design_ListView(com.google.appinventor.components.runtime.ComponentContainer r5) {
        /*
            r4 = this;
            r0 = r4
            r1 = r5
            r2 = r0
            r3 = r1
            com.google.appinventor.components.runtime.Form r3 = r3.$form()
            r2.<init>(r3)
            r2 = r0
            java.lang.String r3 = ""
            r2.offline_icon = r3
            r2 = r0
            java.lang.String r3 = ""
            r2.loading_icon = r3
            r2 = r0
            r3 = 0
            r2.Horizontal_List = r3
            r2 = r0
            r3 = r1
            r2.container = r3
            r2 = r0
            r3 = r1
            android.app.Activity r3 = r3.$context()
            r2.context = r3
            r2 = r0
            r3 = r1
            android.app.Activity r3 = r3.$context()
            r2.activity = r3
            r2 = r0
            com.google.appinventor.components.runtime.Form r2 = r2.form
            boolean r2 = r2 instanceof com.google.appinventor.components.runtime.ReplForm
            if (r2 == 0) goto L_0x0039
            r2 = 1
            yt.DeepHost.Custom_Design_ListView.isReple.isRepl = r2
        L_0x0039:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: yt.DeepHost.Custom_Design_ListView.Custom_Design_ListView.<init>(com.google.appinventor.components.runtime.ComponentContainer):void");
    }

    @DesignerProperty(defaultValue = "False", editorType = "boolean")
    @SimpleProperty
    public void Horizontal_List(boolean id) {
        boolean z = id;
        this.Horizontal_List = z;
    }

    @DesignerProperty(defaultValue = "", editorType = "asset")
    @SimpleProperty
    public void Loading_Icon(String path) {
        String str = path;
        this.loading_icon = str;
    }

    @DesignerProperty(defaultValue = "", editorType = "asset")
    @SimpleProperty
    public void Offline_Icon(String path) {
        String str = path;
        this.offline_icon = str;
    }

    @DesignerProperty(defaultValue = "False", editorType = "boolean")
    @SimpleProperty
    public void AppInventor(boolean id) {
        isReple.appInventor = id;
    }

    @SimpleFunction
    public void Scroll_UP() {
        Runnable runnable;
        if (this.scrollView != null) {
            new Runnable(this) {
                final /* synthetic */ Custom_Design_ListView this$0;

                {
                    this.this$0 = this$0;
                }

                public void run() {
                    boolean fullScroll = this.this$0.scrollView.fullScroll(33);
                }
            };
            boolean post = this.scrollView.post(runnable);
        }
    }

    @SimpleFunction
    public void Scroll_Down() {
        Runnable runnable;
        if (this.scrollView != null) {
            new Runnable(this) {
                final /* synthetic */ Custom_Design_ListView this$0;

                {
                    this.this$0 = this$0;
                }

                public void run() {
                    boolean fullScroll = this.this$0.scrollView.fullScroll(130);
                }
            };
            boolean post = this.scrollView.post(runnable);
        }
    }

    @SimpleFunction
    public void Create(AndroidViewComponent layout, String str, AndroidViewComponent view) {
        LinearLayout linearLayout2;
        ViewGroup.LayoutParams layoutParams;
        String Color = str;
        ViewGroup layouy_view = (ViewGroup) layout.getView();
        layouy_view.removeAllViews();
        new LinearLayout(this.context);
        LinearLayout linearLayout3 = linearLayout2;
        new LinearLayout.LayoutParams(-1, -1);
        linearLayout3.setLayoutParams(layoutParams);
        linearLayout3.addView(view.getView());
        if (Color.contains("#")) {
            linearLayout3.setBackgroundColor(Color.parseColor(Color));
        } else {
            try {
                linearLayout3.setBackgroundColor(Integer.parseInt(Color));
            } catch (NumberFormatException e) {
                NumberFormatException numberFormatException = e;
                linearLayout3.setBackgroundColor(0);
            }
        }
        layouy_view.addView(linearLayout3);
    }

    @SimpleEvent
    public void OnClick_Layout(int position, int id) {
        Object[] objArr = new Object[2];
        objArr[0] = Integer.valueOf(position);
        Object[] objArr2 = objArr;
        objArr2[1] = Integer.valueOf(id);
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "OnClick_Layout", objArr2);
    }

    @SimpleEvent
    public void OnClick_CardView(int position, int id) {
        Object[] objArr = new Object[2];
        objArr[0] = Integer.valueOf(position);
        Object[] objArr2 = objArr;
        objArr2[1] = Integer.valueOf(id);
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "OnClick_CardView", objArr2);
    }

    @SimpleEvent
    public void OnClick_Text(int position, int id) {
        Object[] objArr = new Object[2];
        objArr[0] = Integer.valueOf(position);
        Object[] objArr2 = objArr;
        objArr2[1] = Integer.valueOf(id);
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "OnClick_Text", objArr2);
    }

    @SimpleEvent
    public void OnClick_Button(int position, int id) {
        Object[] objArr = new Object[2];
        objArr[0] = Integer.valueOf(position);
        Object[] objArr2 = objArr;
        objArr2[1] = Integer.valueOf(id);
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "OnClick_Button", objArr2);
    }

    @SimpleEvent
    public void OnClick_Image_Assets(int position, int id) {
        Object[] objArr = new Object[2];
        objArr[0] = Integer.valueOf(position);
        Object[] objArr2 = objArr;
        objArr2[1] = Integer.valueOf(id);
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "OnClick_Image_Assets", objArr2);
    }

    @SimpleEvent
    public void OnClick_Image_URL(int position, int id) {
        Object[] objArr = new Object[2];
        objArr[0] = Integer.valueOf(position);
        Object[] objArr2 = objArr;
        objArr2[1] = Integer.valueOf(id);
        boolean dispatchEvent = EventDispatcher.dispatchEvent(this, "OnClick_Image_URL", objArr2);
    }

    @SimpleFunction(description = "1. position = Number of list position\n.\n2. ID = Set Do Click ID\n.\n3. Height = WRAP_CONTENT or MATCH_PARENT or getPixels\n.\n4. Width = WRAP_CONTENT or MATCH_PARENT or getPixels\n.\n5. Weigth = Set Weigth default - 0 or 1 \n.\n6. Margin = Create Empty List or Make a List Item - 1.Left , 2.Top , 3.Right , 4.Bottom\n.\n7. Padding = Create Empty List or Make a List Item - 1.Left , 2.Top , 3.Right , 4.Bottom\n.\n8. Orientation = Select any One - VERTICAL or HORIZONTAL\n.\n9. Gravity = Select any One - CENTER, LEFT, RIGHT, TOP, BOTTOM, START, END, LEFT_CENTER, RIGHT_CENTER, TOP_LEFT, TOP_RIGHT, TOP_CENTER, BUTTOM_LEFT, BUTTOM_RIGHT , BUTTOM_CENTER\n.\n10. Color = Set Background Color - Color or TRANSPARENT\n.\n11. Shadow_Effect = Set 0 or 5\n.\n12. List = Create Empty List or Make a List Component")
    public AndroidViewComponent Create_Layout(int position, int id, int Height, int Width, float Weigth, YailList yailList, YailList yailList2, String Orientation, String Gravity, String Color, int Shadow_Effect, List<AndroidViewComponent> List) {
        design_size size;
        AndroidViewComponent component;
        YailList Margin = yailList;
        YailList Padding = yailList2;
        int[] margin = convert(Margin.toStringArray());
        int[] padding = convert(Padding.toStringArray());
        new design_size(this.context);
        final int i = Width;
        final int i2 = Height;
        final float f = Weigth;
        final design_size design_size = size;
        final int i3 = Shadow_Effect;
        final YailList yailList3 = Margin;
        final int[] iArr = margin;
        final YailList yailList4 = Padding;
        final int[] iArr2 = padding;
        final String str = Orientation;
        final String str2 = Gravity;
        final String str3 = Color;
        final List<AndroidViewComponent> list = List;
        final int i4 = position;
        final int i5 = id;
        new AndroidViewComponent(this, this.container) {
            final /* synthetic */ Custom_Design_ListView this$0;

            {
                this.this$0 = this$0;
            }

            @SuppressLint({"RtlHardcoded"})
            public View getView() {
                LinearLayout linearLayout;
                LinearLayout.LayoutParams layoutParams;
                View.OnClickListener onClickListener;
                new LinearLayout(this.this$0.context);
                LinearLayout access$102 = Custom_Design_ListView.access$102(this.this$0, linearLayout);
                new LinearLayout.LayoutParams(i, i2, f);
                LinearLayout.LayoutParams access$302 = Custom_Design_ListView.access$302(this.this$0, layoutParams);
                if (Build.VERSION.SDK_INT >= 21) {
                    this.this$0.linearLayout.setElevation((float) design_size.getPixels(i3));
                }
                if (!yailList3.isEmpty() && yailList3.size() == 4) {
                    this.this$0.params_layout.setMargins(design_size.getPixels(iArr[0]), design_size.getPixels(iArr[1]), design_size.getPixels(iArr[2]), design_size.getPixels(iArr[3]));
                }
                if (!yailList4.isEmpty() && yailList4.size() == 4) {
                    this.this$0.linearLayout.setPadding(design_size.getPixels(iArr2[0]), design_size.getPixels(iArr2[1]), design_size.getPixels(iArr2[2]), design_size.getPixels(iArr2[3]));
                }
                this.this$0.Orientation_Layout(str);
                this.this$0.Gravity_Layout(str2);
                this.this$0.linearLayout.setLayoutParams(this.this$0.params_layout);
                if (str3.contains("#")) {
                    this.this$0.linearLayout.setBackgroundColor(Color.parseColor(str3));
                } else {
                    try {
                        this.this$0.linearLayout.setBackgroundColor(Integer.parseInt(str3));
                    } catch (NumberFormatException e) {
                        NumberFormatException numberFormatException = e;
                        this.this$0.linearLayout.setBackgroundColor(0);
                    }
                }
                if (!list.isEmpty()) {
                    for (int i = 1; i <= list.size(); i++) {
                        this.this$0.linearLayout.addView(((AndroidViewComponent) list.get(i)).getView());
                    }
                }
                new View.OnClickListener(this) {
                    final /* synthetic */ AnonymousClass3 this$1;

                    {
                        this.this$1 = this$1;
                    }

                    public void onClick(View view) {
                        View view2 = view;
                        this.this$1.this$0.OnClick_Layout(i4, i5);
                    }
                };
                this.this$0.linearLayout.setOnClickListener(onClickListener);
                return this.this$0.linearLayout;
            }
        };
        return component;
    }

    @SimpleFunction(description = "1. Height = WRAP_CONTENT or MATCH_PARENT or getPixels\n.\n2. Width = WRAP_CONTENT or MATCH_PARENT or getPixels\n.\n3. Weigth = Set Weigth default - 0 or 1 ")
    public AndroidViewComponent Create_Empty_Space(int Height, int Width, float Weigth) {
        AndroidViewComponent component;
        final int i = Width;
        final int i2 = Height;
        final float f = Weigth;
        new AndroidViewComponent(this, this.container) {
            final /* synthetic */ Custom_Design_ListView this$0;

            {
                this.this$0 = this$0;
            }

            @SuppressLint({"RtlHardcoded"})
            public View getView() {
                LinearLayout linearLayout;
                LinearLayout.LayoutParams layoutParams;
                new LinearLayout(this.this$0.context);
                LinearLayout linearLayout2 = linearLayout;
                new LinearLayout.LayoutParams(i, i2, f);
                LinearLayout.LayoutParams access$302 = Custom_Design_ListView.access$302(this.this$0, layoutParams);
                linearLayout2.setLayoutParams(this.this$0.params_layout);
                linearLayout2.setBackgroundColor(0);
                return linearLayout2;
            }
        };
        return component;
    }

    @SimpleFunction(description = "1. position = Number of list position\n.\n2. ID = Set Do Click ID\n.\n3. Height = WRAP_CONTENT or MATCH_PARENT or getPixels\n.\n4. Width = WRAP_CONTENT or MATCH_PARENT or getPixels\n.\n5. Weigth = Set Weigth default - 0 or 1 \n.\n6. Margin = Create Empty List or Make a List Item - 1.Left , 2.Top , 3.Right , 4.Bottom\n.\n7. Padding = Create Empty List or Make a List Item - 1.Left , 2.Top , 3.Right , 4.Bottom\n.\n8. Orientation = Select any One - VERTICAL or HORIZONTAL\n.\n9. Gravity = Select any One - CENTER, LEFT, RIGHT, TOP, BOTTOM, START, END, LEFT_CENTER, RIGHT_CENTER, TOP_LEFT, TOP_RIGHT, TOP_CENTER, BUTTOM_LEFT, BUTTOM_RIGHT , BUTTOM_CENTER\n.\n10. Background_Color = Set Background Color or TRANSPARENT\n.\n11. Stroke_Color = Set Stroke Color or TRANSPARENT\n.\n12. Radius = Set Radius Number - default 10\n.\n13. Stroke = Set Stroke Number - default 1\n.\n14. Shadow_Effect = Set 0 or 5\n.\n15. List = Create Empty List or Make a List Component")
    public AndroidViewComponent Create_CardView(int position, int id, int Height, int Width, float Weigth, YailList yailList, YailList yailList2, String Orientation, String Gravity, String Background_Color, String Stroke_Color, int Radius, int Stroke, int Shadow_Effect, List<AndroidViewComponent> List) {
        design_size size;
        AndroidViewComponent component;
        YailList Margin = yailList;
        YailList Padding = yailList2;
        int[] margin = convert(Margin.toStringArray());
        int[] padding = convert(Padding.toStringArray());
        new design_size(this.context);
        final int i = Width;
        final int i2 = Height;
        final float f = Weigth;
        final design_size design_size = size;
        final int i3 = Shadow_Effect;
        final YailList yailList3 = Margin;
        final int[] iArr = margin;
        final YailList yailList4 = Padding;
        final int[] iArr2 = padding;
        final String str = Background_Color;
        final String str2 = Stroke_Color;
        final int i4 = Radius;
        final int i5 = Stroke;
        final String str3 = Orientation;
        final String str4 = Gravity;
        final List<AndroidViewComponent> list = List;
        final int i6 = position;
        final int i7 = id;
        new AndroidViewComponent(this, this.container) {
            final /* synthetic */ Custom_Design_ListView this$0;

            {
                this.this$0 = this$0;
            }

            @SuppressLint({"RtlHardcoded"})
            public View getView() {
                LinearLayout linearLayout;
                LinearLayout.LayoutParams layoutParams;
                GradientDrawable gradientDrawable;
                GradientDrawable gradientDrawable2;
                View.OnClickListener onClickListener;
                GradientDrawable gradientDrawable3;
                new LinearLayout(this.this$0.context);
                LinearLayout access$402 = Custom_Design_ListView.access$402(this.this$0, linearLayout);
                new LinearLayout.LayoutParams(i, i2, f);
                LinearLayout.LayoutParams access$502 = Custom_Design_ListView.access$502(this.this$0, layoutParams);
                if (Build.VERSION.SDK_INT >= 21) {
                    this.this$0.cardview.setElevation((float) design_size.getPixels(i3));
                }
                if (!yailList3.isEmpty() && yailList3.size() == 4) {
                    this.this$0.params_cardview.setMargins(design_size.getPixels(iArr[0]), design_size.getPixels(iArr[1]), design_size.getPixels(iArr[2]), design_size.getPixels(iArr[3]));
                }
                if (!yailList4.isEmpty() && yailList4.size() == 4) {
                    this.this$0.cardview.setPadding(design_size.getPixels(iArr2[0]), design_size.getPixels(iArr2[1]), design_size.getPixels(iArr2[2]), design_size.getPixels(iArr2[3]));
                }
                this.this$0.cardview.setLayoutParams(this.this$0.params_cardview);
                if (!str.contains("#") || !str2.contains("#")) {
                    try {
                        GradientDrawable gradientDrawable4 = gradientDrawable2;
                        GradientDrawable.Orientation orientation = GradientDrawable.Orientation.BOTTOM_TOP;
                        int[] iArr = new int[2];
                        iArr[0] = Integer.parseInt(str);
                        int[] iArr2 = iArr;
                        iArr2[1] = Integer.parseInt(str);
                        new GradientDrawable(orientation, iArr2);
                        GradientDrawable layout_bg = gradientDrawable4;
                        layout_bg.setCornerRadius((float) design_size.getPixels(i4));
                        layout_bg.setStroke(design_size.getPixels(i5), Integer.parseInt(str2));
                        this.this$0.cardview.setBackground(layout_bg);
                    } catch (NumberFormatException e) {
                        NumberFormatException numberFormatException = e;
                        new GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, new int[]{-1, -1});
                        GradientDrawable layout_bg2 = gradientDrawable;
                        layout_bg2.setCornerRadius((float) design_size.getPixels(i4));
                        layout_bg2.setStroke(design_size.getPixels(i5), Component.COLOR_LIGHT_GRAY);
                        this.this$0.cardview.setBackground(layout_bg2);
                    }
                } else {
                    GradientDrawable gradientDrawable5 = gradientDrawable3;
                    GradientDrawable.Orientation orientation2 = GradientDrawable.Orientation.BOTTOM_TOP;
                    int[] iArr3 = new int[2];
                    iArr3[0] = Color.parseColor(str);
                    int[] iArr4 = iArr3;
                    iArr4[1] = Color.parseColor(str);
                    new GradientDrawable(orientation2, iArr4);
                    GradientDrawable layout_bg3 = gradientDrawable5;
                    layout_bg3.setCornerRadius((float) design_size.getPixels(i4));
                    layout_bg3.setStroke(design_size.getPixels(i5), Color.parseColor(str2));
                    this.this$0.cardview.setBackground(layout_bg3);
                }
                this.this$0.Orientation_CardView(str3);
                this.this$0.Gravity_CardView(str4);
                if (!list.isEmpty()) {
                    for (int i = 1; i <= list.size(); i++) {
                        this.this$0.cardview.addView(((AndroidViewComponent) list.get(i)).getView());
                    }
                }
                new View.OnClickListener(this) {
                    final /* synthetic */ AnonymousClass5 this$1;

                    {
                        this.this$1 = this$1;
                    }

                    public void onClick(View view) {
                        View view2 = view;
                        this.this$1.this$0.OnClick_CardView(i6, i7);
                    }
                };
                this.this$0.cardview.setOnClickListener(onClickListener);
                return this.this$0.cardview;
            }
        };
        return component;
    }

    @SimpleFunction(description = "1. position = Number of list position\n.\n2. ID = Set Do Click ID\n.\n3. Height = WRAP_CONTENT or MATCH_PARENT or getPixels\n.\n3. Width = WRAP_CONTENT or MATCH_PARENT or getPixels\n.\n4. Weigth = Set Weigth default - 0 or 1 \n.\n5. Margin = Create Empty List or Make a List Item - 1.Left , 2.Top , 3.Right , 4.Bottom\n.\n6. Padding = Create Empty List or Make a List Item - 1.Left , 2.Top , 3.Right , 4.Bottom\n.\n7. Gravity = Select any One - CENTER, LEFT, RIGHT, TOP, BOTTOM, START, END, LEFT_CENTER, RIGHT_CENTER, TOP_LEFT, TOP_RIGHT, TOP_CENTER, BUTTOM_LEFT, BUTTOM_RIGHT , BUTTOM_CENTER\n.\n8. Text = Set Text Content\n.\n9. MaxLines = Set Text Max Lines default 1\n.\n10. Text_Size = Set Text Size - default 18 \n.\n11. Text_Color = Set Tex Color or TRANSPARENT\n.\n12. Style = Select any One - NORMAL , BOLD , ITALIC\n.\n13. Font = Select Any One - DEFAULT or Set Custom font - filename.ttf")
    public AndroidViewComponent Create_Text(int position, int id, int Height, int Width, float Weigth, YailList yailList, YailList yailList2, String Gravity, String Text, int MaxLines, int Text_Size, String Text_Color, String Style, String Font) {
        design_size size;
        AndroidViewComponent component;
        YailList Margin = yailList;
        YailList Padding = yailList2;
        new design_size(this.context);
        int[] margin = convert(Margin.toStringArray());
        final int i = MaxLines;
        final int i2 = Width;
        final int i3 = Height;
        final float f = Weigth;
        final YailList yailList3 = Margin;
        final design_size design_size = size;
        final int[] iArr = margin;
        final YailList yailList4 = Padding;
        final int[] convert = convert(Padding.toStringArray());
        final String str = Text;
        final int i4 = Text_Size;
        final String str2 = Text_Color;
        final String str3 = Font;
        final String str4 = Style;
        final String str5 = Gravity;
        final int i5 = position;
        final int i6 = id;
        new AndroidViewComponent(this, this.container) {
            final /* synthetic */ Custom_Design_ListView this$0;

            {
                this.this$0 = this$0;
            }

            @SuppressLint({"RtlHardcoded"})
            public View getView() {
                TextView textView;
                LinearLayout.LayoutParams layoutParams;
                StringBuilder sb;
                StringBuilder sb2;
                View.OnClickListener onClickListener;
                new TextView(this.this$0.context);
                TextView access$602 = Custom_Design_ListView.access$602(this.this$0, textView);
                this.this$0.textView.setEllipsize(TextUtils.TruncateAt.END);
                this.this$0.textView.setMaxLines(i);
                new LinearLayout.LayoutParams(i2, i3, f);
                LinearLayout.LayoutParams params = layoutParams;
                if (!yailList3.isEmpty() && yailList3.size() == 4) {
                    params.setMargins(design_size.getPixels(iArr[0]), design_size.getPixels(iArr[1]), design_size.getPixels(iArr[2]), design_size.getPixels(iArr[3]));
                }
                if (!yailList4.isEmpty() && yailList4.size() == 4) {
                    this.this$0.textView.setPadding(design_size.getPixels(convert[0]), design_size.getPixels(convert[1]), design_size.getPixels(convert[2]), design_size.getPixels(convert[3]));
                }
                this.this$0.textView.setLayoutParams(params);
                this.this$0.textView.setText(str);
                this.this$0.textView.setTextSize((float) i4);
                if (str2.contains("#")) {
                    this.this$0.textView.setTextColor(Color.parseColor(str2));
                } else {
                    try {
                        this.this$0.textView.setTextColor(Integer.parseInt(str2));
                    } catch (NumberFormatException e) {
                        NumberFormatException numberFormatException = e;
                        this.this$0.textView.setTextColor(-7829368);
                    }
                }
                if (!str3.contains(this.this$0.DEFAULT())) {
                    try {
                        if (!isReple.isRepl) {
                            Typeface access$702 = Custom_Design_ListView.access$702(this.this$0, Typeface.createFromAsset(this.this$0.context.getAssets(), str3));
                            if (str4.contains(this.this$0.NORMAL())) {
                                this.this$0.textView.setTypeface(this.this$0.text_font, 0);
                            } else if (str4.contains(this.this$0.BOLD())) {
                                this.this$0.textView.setTypeface(this.this$0.text_font, 1);
                            } else if (str4.contains(this.this$0.ITALIC())) {
                                this.this$0.textView.setTypeface(this.this$0.text_font, 2);
                            }
                        } else if (isReple.appInventor) {
                            Custom_Design_ListView custom_Design_ListView = this.this$0;
                            new StringBuilder();
                            Typeface access$7022 = Custom_Design_ListView.access$702(custom_Design_ListView, Typeface.createFromFile(sb2.append(isReple.parth_appInventor).append(str3).toString()));
                            if (str4.contains(this.this$0.NORMAL())) {
                                this.this$0.textView.setTypeface(this.this$0.text_font, 0);
                            } else if (str4.contains(this.this$0.BOLD())) {
                                this.this$0.textView.setTypeface(this.this$0.text_font, 1);
                            } else if (str4.contains(this.this$0.ITALIC())) {
                                this.this$0.textView.setTypeface(this.this$0.text_font, 2);
                            }
                        } else {
                            Custom_Design_ListView custom_Design_ListView2 = this.this$0;
                            new StringBuilder();
                            Typeface access$7023 = Custom_Design_ListView.access$702(custom_Design_ListView2, Typeface.createFromFile(sb.append(isReple.parth_makeroid).append(str3).toString()));
                            if (str4.contains(this.this$0.NORMAL())) {
                                this.this$0.textView.setTypeface(this.this$0.text_font, 0);
                            } else if (str4.contains(this.this$0.BOLD())) {
                                this.this$0.textView.setTypeface(this.this$0.text_font, 1);
                            } else if (str4.contains(this.this$0.ITALIC())) {
                                this.this$0.textView.setTypeface(this.this$0.text_font, 2);
                            }
                        }
                    } catch (Exception e2) {
                        Exception exc = e2;
                        Typeface access$7024 = Custom_Design_ListView.access$702(this.this$0, Typeface.DEFAULT);
                        if (str4.contains(this.this$0.NORMAL())) {
                            this.this$0.textView.setTypeface(this.this$0.text_font, 0);
                        } else if (str4.contains(this.this$0.BOLD())) {
                            this.this$0.textView.setTypeface(this.this$0.text_font, 1);
                        } else if (str4.contains(this.this$0.ITALIC())) {
                            this.this$0.textView.setTypeface(this.this$0.text_font, 2);
                        }
                    }
                } else if (str4.contains(this.this$0.NORMAL())) {
                    this.this$0.textView.setTypeface(Typeface.DEFAULT, 0);
                } else if (str4.contains(this.this$0.BOLD())) {
                    this.this$0.textView.setTypeface(Typeface.DEFAULT, 1);
                } else if (str4.contains(this.this$0.ITALIC())) {
                    this.this$0.textView.setTypeface(Typeface.DEFAULT, 2);
                }
                this.this$0.Gravity_Text(str5);
                new View.OnClickListener(this) {
                    final /* synthetic */ AnonymousClass6 this$1;

                    {
                        this.this$1 = this$1;
                    }

                    public void onClick(View view) {
                        View view2 = view;
                        this.this$1.this$0.OnClick_Text(i5, i6);
                    }
                };
                this.this$0.textView.setOnClickListener(onClickListener);
                return this.this$0.textView;
            }
        };
        return component;
    }

    @SimpleFunction(description = "1. position = Number of list position\n.\n2. ID = Set Do Click ID\n.\n2. Height = WRAP_CONTENT or MATCH_PARENT or getPixels\n.\n4. Width = WRAP_CONTENT or MATCH_PARENT or getPixels\n.\n5. Weigth = Set Weigth default - 0 or 1 \n.\n6. Margin = Create Empty List or Make a List Item - 1.Left , 2.Top , 3.Right , 4.Bottom\n.\n7. Padding = Create Empty List or Make a List Item - 1.Left , 2.Top , 3.Right , 4.Bottom\n.\n8. Text = Set Text Content\n.\n9. Text_Size = Set Text Size - default 18 \n.\n10. Background_Color = Set Background Color or TRANSPARENT\n.\n11. Stroke_Color = Set Stroke Color or TRANSPARENT\n.\n12. Radius = Set Radius Number - default 10\n.\n13. Stroke = Set Stroke Number - default 1\n.\n14. Text_Color = Set Tex Color or TRANSPARENT\n.\n15. Style = Select any One - NORMAL , BOLD , ITALIC\n.\n16. Font = Select Any One - DEFAULT or Set Custom font - filename.ttf")
    public AndroidViewComponent Create_Button(int position, int id, int Height, int Width, float Weigth, YailList yailList, YailList yailList2, String Text, int Text_Size, String Background_Color, String Stroke_Color, int Radius, int Stroke, int Text_Color, String Style, String Font) {
        design_size size;
        AndroidViewComponent component;
        YailList Margin = yailList;
        YailList Padding = yailList2;
        new design_size(this.context);
        int[] margin = convert(Margin.toStringArray());
        final int i = Width;
        final int i2 = Height;
        final float f = Weigth;
        final YailList yailList3 = Margin;
        final design_size design_size = size;
        final int[] iArr = margin;
        final YailList yailList4 = Padding;
        final int[] convert = convert(Padding.toStringArray());
        final String str = Text;
        final int i3 = Text_Size;
        final int i4 = id;
        final String str2 = Background_Color;
        final String str3 = Stroke_Color;
        final int i5 = Radius;
        final int i6 = Stroke;
        final int i7 = Text_Color;
        final String str4 = Font;
        final String str5 = Style;
        final int i8 = position;
        new AndroidViewComponent(this, this.container) {
            final /* synthetic */ Custom_Design_ListView this$0;

            {
                this.this$0 = this$0;
            }

            @SuppressLint({"RtlHardcoded"})
            public View getView() {
                Button button;
                LinearLayout.LayoutParams layoutParams;
                GradientDrawable gradientDrawable;
                GradientDrawable gradientDrawable2;
                StringBuilder sb;
                StringBuilder sb2;
                View.OnClickListener onClickListener;
                GradientDrawable gradientDrawable3;
                new Button(this.this$0.context);
                Button access$802 = Custom_Design_ListView.access$802(this.this$0, button);
                new LinearLayout.LayoutParams(i, i2, f);
                LinearLayout.LayoutParams params = layoutParams;
                if (!yailList3.isEmpty() && yailList3.size() == 4) {
                    params.setMargins(design_size.getPixels(iArr[0]), design_size.getPixels(iArr[1]), design_size.getPixels(iArr[2]), design_size.getPixels(iArr[3]));
                }
                if (!yailList4.isEmpty() && yailList4.size() == 4) {
                    this.this$0.button.setPadding(design_size.getPixels(convert[0]), design_size.getPixels(convert[1]), design_size.getPixels(convert[2]), design_size.getPixels(convert[3]));
                }
                this.this$0.button.setLayoutParams(params);
                this.this$0.button.setAllCaps(false);
                this.this$0.button.setText(str);
                this.this$0.button.setTextSize((float) i3);
                this.this$0.button.setTag(String.valueOf(i4));
                if (!str2.contains("#") || !str3.contains("#")) {
                    try {
                        GradientDrawable gradientDrawable4 = gradientDrawable2;
                        GradientDrawable.Orientation orientation = GradientDrawable.Orientation.BOTTOM_TOP;
                        int[] iArr = new int[2];
                        iArr[0] = Integer.parseInt(str2);
                        int[] iArr2 = iArr;
                        iArr2[1] = Integer.parseInt(str2);
                        new GradientDrawable(orientation, iArr2);
                        GradientDrawable layout_bg = gradientDrawable4;
                        layout_bg.setCornerRadius((float) design_size.getPixels(i5));
                        layout_bg.setStroke(design_size.getPixels(i6), Integer.parseInt(str3));
                        this.this$0.button.setBackground(layout_bg);
                    } catch (NumberFormatException e) {
                        NumberFormatException numberFormatException = e;
                        new GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, new int[]{-1, -1});
                        GradientDrawable layout_bg2 = gradientDrawable;
                        layout_bg2.setCornerRadius((float) design_size.getPixels(i5));
                        layout_bg2.setStroke(design_size.getPixels(i6), Component.COLOR_LIGHT_GRAY);
                        this.this$0.button.setBackground(layout_bg2);
                    }
                } else {
                    GradientDrawable gradientDrawable5 = gradientDrawable3;
                    GradientDrawable.Orientation orientation2 = GradientDrawable.Orientation.BOTTOM_TOP;
                    int[] iArr3 = new int[2];
                    iArr3[0] = Color.parseColor(str2);
                    int[] iArr4 = iArr3;
                    iArr4[1] = Color.parseColor(str2);
                    new GradientDrawable(orientation2, iArr4);
                    GradientDrawable layout_bg3 = gradientDrawable5;
                    layout_bg3.setCornerRadius((float) design_size.getPixels(i5));
                    layout_bg3.setStroke(design_size.getPixels(i6), Color.parseColor(str3));
                    this.this$0.button.setBackground(layout_bg3);
                }
                this.this$0.button.setTextColor(i7);
                if (!str4.contains(this.this$0.DEFAULT())) {
                    try {
                        if (!isReple.isRepl) {
                            Typeface access$902 = Custom_Design_ListView.access$902(this.this$0, Typeface.createFromAsset(this.this$0.context.getAssets(), str4));
                            if (str5.contains(this.this$0.NORMAL())) {
                                this.this$0.button.setTypeface(this.this$0.button_font, 0);
                            } else if (str5.contains(this.this$0.BOLD())) {
                                this.this$0.button.setTypeface(this.this$0.button_font, 1);
                            } else if (str5.contains(this.this$0.ITALIC())) {
                                this.this$0.button.setTypeface(this.this$0.button_font, 2);
                            }
                        } else if (isReple.appInventor) {
                            Custom_Design_ListView custom_Design_ListView = this.this$0;
                            new StringBuilder();
                            Typeface access$9022 = Custom_Design_ListView.access$902(custom_Design_ListView, Typeface.createFromFile(sb2.append(isReple.parth_appInventor).append(str4).toString()));
                            if (str5.contains(this.this$0.NORMAL())) {
                                this.this$0.button.setTypeface(this.this$0.button_font, 0);
                            } else if (str5.contains(this.this$0.BOLD())) {
                                this.this$0.button.setTypeface(this.this$0.button_font, 1);
                            } else if (str5.contains(this.this$0.ITALIC())) {
                                this.this$0.button.setTypeface(this.this$0.button_font, 2);
                            }
                        } else {
                            Custom_Design_ListView custom_Design_ListView2 = this.this$0;
                            new StringBuilder();
                            Typeface access$9023 = Custom_Design_ListView.access$902(custom_Design_ListView2, Typeface.createFromFile(sb.append(isReple.parth_makeroid).append(str4).toString()));
                            if (str5.contains(this.this$0.NORMAL())) {
                                this.this$0.button.setTypeface(this.this$0.button_font, 0);
                            } else if (str5.contains(this.this$0.BOLD())) {
                                this.this$0.button.setTypeface(this.this$0.button_font, 1);
                            } else if (str5.contains(this.this$0.ITALIC())) {
                                this.this$0.button.setTypeface(this.this$0.button_font, 2);
                            }
                        }
                    } catch (Exception e2) {
                        Exception exc = e2;
                        Typeface access$9024 = Custom_Design_ListView.access$902(this.this$0, Typeface.DEFAULT);
                        if (str5.contains(this.this$0.NORMAL())) {
                            this.this$0.button.setTypeface(this.this$0.button_font, 0);
                        } else if (str5.contains(this.this$0.BOLD())) {
                            this.this$0.button.setTypeface(this.this$0.button_font, 1);
                        } else if (str5.contains(this.this$0.ITALIC())) {
                            this.this$0.button.setTypeface(this.this$0.button_font, 2);
                        }
                    }
                } else if (str5.contains(this.this$0.NORMAL())) {
                    this.this$0.button.setTypeface(Typeface.DEFAULT, 0);
                } else if (str5.contains(this.this$0.BOLD())) {
                    this.this$0.button.setTypeface(Typeface.DEFAULT, 1);
                } else if (str5.contains(this.this$0.ITALIC())) {
                    this.this$0.button.setTypeface(Typeface.DEFAULT, 2);
                }
                new View.OnClickListener(this) {
                    final /* synthetic */ AnonymousClass7 this$1;

                    {
                        this.this$1 = this$1;
                    }

                    public void onClick(View view) {
                        View view2 = view;
                        this.this$1.this$0.OnClick_Button(i8, i4);
                    }
                };
                this.this$0.button.setOnClickListener(onClickListener);
                return this.this$0.button;
            }
        };
        return component;
    }

    @SimpleFunction(description = "1. position = Number of list position\n.\n2. ID = Set Do Click ID\n.\n3. Responsive = true or false\n.\n4. Height = WRAP_CONTENT or MATCH_PARENT or getPixels\n.\n5. Width = WRAP_CONTENT or MATCH_PARENT or getPixels\n.\n6. Weigth = Set Weigth default - 0 or 1 \n.\n7. Margin = Create Empty List or Make a List Item - 1.Left , 2.Top , 3.Right , 4.Bottom\n.\n8. Padding = Create Empty List or Make a List Item - 1.Left , 2.Top , 3.Right , 4.Bottom\n.\n9. filename = Set Image filename png or jpg\n")
    public AndroidViewComponent Create_Image_Assets(int position, int id, boolean Responsive, int Height, int Width, float Weigth, YailList yailList, YailList yailList2, String filename, List<AndroidViewComponent> List) {
        design_size size;
        AndroidViewComponent component;
        YailList Margin = yailList;
        YailList Padding = yailList2;
        new design_size(this.context);
        int[] margin = convert(Margin.toStringArray());
        final int i = Width;
        final int i2 = Height;
        final float f = Weigth;
        final YailList yailList3 = Margin;
        final design_size design_size = size;
        final int[] iArr = margin;
        final YailList yailList4 = Padding;
        final int[] convert = convert(Padding.toStringArray());
        final String str = filename;
        final boolean z = Responsive;
        final int i3 = position;
        final int i4 = id;
        final List<AndroidViewComponent> list = List;
        new AndroidViewComponent(this, this.container) {
            final /* synthetic */ Custom_Design_ListView this$0;

            {
                this.this$0 = this$0;
            }

            @SuppressLint({"RtlHardcoded"})
            public View getView() {
                ImageView imageView;
                LinearLayout.LayoutParams layoutParams;
                View.OnClickListener onClickListener;
                RelativeLayout relativeLayout;
                ViewGroup.LayoutParams layoutParams2;
                new ImageView(this.this$0.context);
                ImageView access$1002 = Custom_Design_ListView.access$1002(this.this$0, imageView);
                new LinearLayout.LayoutParams(i, i2, f);
                LinearLayout.LayoutParams params = layoutParams;
                if (!yailList3.isEmpty() && yailList3.size() == 4) {
                    params.setMargins(design_size.getPixels(iArr[0]), design_size.getPixels(iArr[1]), design_size.getPixels(iArr[2]), design_size.getPixels(iArr[3]));
                }
                if (!yailList4.isEmpty() && yailList4.size() == 4) {
                    this.this$0.imageView.setPadding(design_size.getPixels(convert[0]), design_size.getPixels(convert[1]), design_size.getPixels(convert[2]), design_size.getPixels(convert[3]));
                }
                this.this$0.imageView.setLayoutParams(params);
                this.this$0.imageView.setImageBitmap(isReple.mode(this.this$0.context, str));
                if (z) {
                    this.this$0.imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
                }
                new View.OnClickListener(this) {
                    final /* synthetic */ AnonymousClass8 this$1;

                    {
                        this.this$1 = this$1;
                    }

                    public void onClick(View view) {
                        View view2 = view;
                        this.this$1.this$0.OnClick_Image_Assets(i3, i4);
                    }
                };
                this.this$0.imageView.setOnClickListener(onClickListener);
                if (!list.isEmpty()) {
                    new RelativeLayout(this.this$0.context);
                    RelativeLayout access$1102 = Custom_Design_ListView.access$1102(this.this$0, relativeLayout);
                    new RelativeLayout.LayoutParams(i, i2);
                    this.this$0.relativeLayout_imageView.setLayoutParams(layoutParams2);
                    this.this$0.relativeLayout_imageView.addView(this.this$0.imageView);
                    for (int i = 1; i <= list.size(); i++) {
                        this.this$0.relativeLayout_imageView.addView(((AndroidViewComponent) list.get(i)).getView());
                    }
                }
                if (!list.isEmpty()) {
                    return this.this$0.relativeLayout_imageView;
                }
                return this.this$0.imageView;
            }
        };
        return component;
    }

    @SimpleFunction(description = "1. position = Number of list position\n.\n2. ID = Set Do Click ID\n.\n2. Responsive = true or false\n.\n3. Height = WRAP_CONTENT or MATCH_PARENT or getPixels\n.\n4. Width = WRAP_CONTENT or MATCH_PARENT or getPixels\n.\n5. Weigth = Set Weigth default - 0 or 1 \n.\n6. Margin = Create Empty List or Make a List Item - 1.Left , 2.Top , 3.Right , 4.Bottom\n.\n7. Padding = Create Empty List or Make a List Item - 1.Left , 2.Top , 3.Right , 4.Bottom\n.\n8. URL = Set Image URL png or jpg\n")
    public AndroidViewComponent Create_Image_URL(int position, int id, boolean Responsive, int Height, int Width, float Weigth, YailList yailList, YailList yailList2, String URL, List<AndroidViewComponent> List) {
        design_size size;
        AndroidViewComponent component;
        YailList Margin = yailList;
        YailList Padding = yailList2;
        new design_size(this.context);
        int[] margin = convert(Margin.toStringArray());
        final int i = Width;
        final int i2 = Height;
        final float f = Weigth;
        final YailList yailList3 = Margin;
        final design_size design_size = size;
        final int[] iArr = margin;
        final YailList yailList4 = Padding;
        final int[] convert = convert(Padding.toStringArray());
        final String str = URL;
        final boolean z = Responsive;
        final int i3 = position;
        final int i4 = id;
        final List<AndroidViewComponent> list = List;
        new AndroidViewComponent(this, this.container) {
            final /* synthetic */ Custom_Design_ListView this$0;

            {
                this.this$0 = this$0;
            }

            @SuppressLint({"RtlHardcoded"})
            public View getView() {
                NetworkImageView networkImageView;
                LinearLayout.LayoutParams layoutParams;
                View.OnClickListener onClickListener;
                RelativeLayout relativeLayout;
                ViewGroup.LayoutParams layoutParams2;
                new NetworkImageView(this.this$0.context);
                NetworkImageView access$1202 = Custom_Design_ListView.access$1202(this.this$0, networkImageView);
                new LinearLayout.LayoutParams(i, i2, f);
                LinearLayout.LayoutParams params = layoutParams;
                if (!yailList3.isEmpty() && yailList3.size() == 4) {
                    params.setMargins(design_size.getPixels(iArr[0]), design_size.getPixels(iArr[1]), design_size.getPixels(iArr[2]), design_size.getPixels(iArr[3]));
                }
                if (!yailList4.isEmpty() && yailList4.size() == 4) {
                    this.this$0.networkImageView.setPadding(design_size.getPixels(convert[0]), design_size.getPixels(convert[1]), design_size.getPixels(convert[2]), design_size.getPixels(convert[3]));
                }
                this.this$0.networkImageView.setLayoutParams(params);
                ViewUtil.setImageURL(this.this$0.context, this.this$0.networkImageView, str, this.this$0.loading_icon, this.this$0.offline_icon);
                if (z) {
                    this.this$0.networkImageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
                }
                new View.OnClickListener(this) {
                    final /* synthetic */ AnonymousClass9 this$1;

                    {
                        this.this$1 = this$1;
                    }

                    public void onClick(View view) {
                        View view2 = view;
                        this.this$1.this$0.OnClick_Image_URL(i3, i4);
                    }
                };
                this.this$0.networkImageView.setOnClickListener(onClickListener);
                if (!list.isEmpty()) {
                    new RelativeLayout(this.this$0.context);
                    RelativeLayout access$1502 = Custom_Design_ListView.access$1502(this.this$0, relativeLayout);
                    new RelativeLayout.LayoutParams(i, i2);
                    this.this$0.relativeLayout_networkImageView.setLayoutParams(layoutParams2);
                    this.this$0.relativeLayout_networkImageView.addView(this.this$0.networkImageView);
                    for (int i = 1; i <= list.size(); i++) {
                        this.this$0.relativeLayout_networkImageView.addView(((AndroidViewComponent) list.get(i)).getView());
                    }
                }
                if (!list.isEmpty()) {
                    return this.this$0.relativeLayout_networkImageView;
                }
                return this.this$0.networkImageView;
            }
        };
        return component;
    }

    @SimpleFunction(description = "1. position = Number of list position\n.\n2. ID = Set Do Click ID\n.\n2. Responsive = true or false\n.\n3. Height = WRAP_CONTENT or MATCH_PARENT or getPixels\n.\n4. Width = WRAP_CONTENT or MATCH_PARENT or getPixels\n.\n5. Weigth = Set Weigth default - 0 or 1 \n.\n6. Margin = Create Empty List or Make a List Item - 1.Left , 2.Top , 3.Right , 4.Bottom\n.\n7. Padding = Create Empty List or Make a List Item - 1.Left , 2.Top , 3.Right , 4.Bottom\n.\n8. URL = Set Image URL png or jpg\n")
    public AndroidViewComponent Create_Image_Files(int position, int id, boolean Responsive, int Height, int Width, float Weigth, YailList yailList, YailList yailList2, String filepath, List<AndroidViewComponent> List) {
        design_size size;
        AndroidViewComponent component;
        YailList Margin = yailList;
        YailList Padding = yailList2;
        new design_size(this.context);
        int[] margin = convert(Margin.toStringArray());
        final int i = Width;
        final int i2 = Height;
        final float f = Weigth;
        final YailList yailList3 = Margin;
        final design_size design_size = size;
        final int[] iArr = margin;
        final YailList yailList4 = Padding;
        final int[] convert = convert(Padding.toStringArray());
        final String str = filepath;
        final boolean z = Responsive;
        final int i3 = position;
        final int i4 = id;
        final List<AndroidViewComponent> list = List;
        new AndroidViewComponent(this, this.container) {
            final /* synthetic */ Custom_Design_ListView this$0;

            {
                this.this$0 = this$0;
            }

            @SuppressLint({"RtlHardcoded"})
            public View getView() {
                NetworkImageView networkImageView;
                LinearLayout.LayoutParams layoutParams;
                View.OnClickListener onClickListener;
                RelativeLayout relativeLayout;
                ViewGroup.LayoutParams layoutParams2;
                new NetworkImageView(this.this$0.context);
                NetworkImageView access$1202 = Custom_Design_ListView.access$1202(this.this$0, networkImageView);
                new LinearLayout.LayoutParams(i, i2, f);
                LinearLayout.LayoutParams params = layoutParams;
                if (!yailList3.isEmpty() && yailList3.size() == 4) {
                    params.setMargins(design_size.getPixels(iArr[0]), design_size.getPixels(iArr[1]), design_size.getPixels(iArr[2]), design_size.getPixels(iArr[3]));
                }
                if (!yailList4.isEmpty() && yailList4.size() == 4) {
                    this.this$0.networkImageView.setPadding(design_size.getPixels(convert[0]), design_size.getPixels(convert[1]), design_size.getPixels(convert[2]), design_size.getPixels(convert[3]));
                }
                this.this$0.networkImageView.setLayoutParams(params);
                if (this.this$0.isPermissionGranted()) {
                    ViewUtil.setImageFile(this.this$0.context, this.this$0.networkImageView, str, this.this$0.loading_icon, this.this$0.offline_icon);
                }
                if (z) {
                    this.this$0.networkImageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
                }
                new View.OnClickListener(this) {
                    final /* synthetic */ AnonymousClass10 this$1;

                    {
                        this.this$1 = this$1;
                    }

                    public void onClick(View view) {
                        View view2 = view;
                        this.this$1.this$0.OnClick_Image_URL(i3, i4);
                    }
                };
                this.this$0.networkImageView.setOnClickListener(onClickListener);
                if (!list.isEmpty()) {
                    new RelativeLayout(this.this$0.context);
                    RelativeLayout access$1502 = Custom_Design_ListView.access$1502(this.this$0, relativeLayout);
                    new RelativeLayout.LayoutParams(i, i2);
                    this.this$0.relativeLayout_networkImageView.setLayoutParams(layoutParams2);
                    this.this$0.relativeLayout_networkImageView.addView(this.this$0.networkImageView);
                    for (int i = 1; i <= list.size(); i++) {
                        this.this$0.relativeLayout_networkImageView.addView(((AndroidViewComponent) list.get(i)).getView());
                    }
                }
                if (!list.isEmpty()) {
                    return this.this$0.relativeLayout_networkImageView;
                }
                return this.this$0.networkImageView;
            }
        };
        return component;
    }

    public void Gravity_Layout(String str) {
        String mGravity = str;
        if (mGravity.contains(CENTER()) && !mGravity.contains("_")) {
            this.linearLayout.setGravity(17);
        } else if (mGravity.contains(LEFT()) && !mGravity.contains("_")) {
            this.linearLayout.setGravity(3);
        } else if (mGravity.contains(RIGHT()) && !mGravity.contains("_")) {
            this.linearLayout.setGravity(5);
        } else if (mGravity.contains(TOP()) && !mGravity.contains("_")) {
            this.linearLayout.setGravity(48);
        } else if (mGravity.contains(BOTTOM()) && !mGravity.contains("_")) {
            this.linearLayout.setGravity(80);
        } else if (mGravity.contains(START()) && !mGravity.contains("_")) {
            this.linearLayout.setGravity(GravityCompat.START);
        } else if (mGravity.contains(END()) && !mGravity.contains("_")) {
            this.linearLayout.setGravity(GravityCompat.END);
        } else if (mGravity.contains(LEFT_CENTER())) {
            this.linearLayout.setGravity(19);
        } else if (mGravity.contains(RIGHT_CENTER())) {
            this.linearLayout.setGravity(21);
        } else if (mGravity.contains(TOP_LEFT())) {
            this.linearLayout.setGravity(51);
        } else if (mGravity.contains(TOP_RIGHT())) {
            this.linearLayout.setGravity(53);
        } else if (mGravity.contains(BUTTOM_LEFT())) {
            this.linearLayout.setGravity(83);
        } else if (mGravity.contains(BUTTOM_RIGHT())) {
            this.linearLayout.setGravity(85);
        } else if (mGravity.contains(TOP_CENTER())) {
            this.linearLayout.setGravity(49);
        } else if (mGravity.contains(BUTTOM_CENTER())) {
            this.linearLayout.setGravity(81);
        }
    }

    public void Gravity_CardView(String str) {
        String mGravity = str;
        if (mGravity.contains(CENTER()) && !mGravity.contains("_")) {
            this.cardview.setGravity(17);
        } else if (mGravity.contains(LEFT()) && !mGravity.contains("_")) {
            this.cardview.setGravity(3);
        } else if (mGravity.contains(RIGHT()) && !mGravity.contains("_")) {
            this.cardview.setGravity(5);
        } else if (mGravity.contains(TOP()) && !mGravity.contains("_")) {
            this.cardview.setGravity(48);
        } else if (mGravity.contains(BOTTOM()) && !mGravity.contains("_")) {
            this.cardview.setGravity(80);
        } else if (mGravity.contains(START()) && !mGravity.contains("_")) {
            this.cardview.setGravity(GravityCompat.START);
        } else if (mGravity.contains(END()) && !mGravity.contains("_")) {
            this.cardview.setGravity(GravityCompat.END);
        } else if (mGravity.contains(LEFT_CENTER())) {
            this.cardview.setGravity(19);
        } else if (mGravity.contains(RIGHT_CENTER())) {
            this.cardview.setGravity(21);
        } else if (mGravity.contains(TOP_LEFT())) {
            this.cardview.setGravity(51);
        } else if (mGravity.contains(TOP_RIGHT())) {
            this.cardview.setGravity(53);
        } else if (mGravity.contains(BUTTOM_LEFT())) {
            this.cardview.setGravity(83);
        } else if (mGravity.contains(BUTTOM_RIGHT())) {
            this.cardview.setGravity(85);
        } else if (mGravity.contains(TOP_CENTER())) {
            this.cardview.setGravity(49);
        } else if (mGravity.contains(BUTTOM_CENTER())) {
            this.cardview.setGravity(81);
        }
    }

    public void Orientation_Layout(String str) {
        String Orientation = str;
        if (Orientation.contains(VERTICAL())) {
            this.linearLayout.setOrientation(1);
        } else if (Orientation.contains(HORIZONTAL())) {
            this.linearLayout.setOrientation(0);
        }
    }

    public void Orientation_CardView(String str) {
        String Orientation = str;
        if (Orientation.contains(VERTICAL())) {
            this.cardview.setOrientation(1);
        } else if (Orientation.contains(HORIZONTAL())) {
            this.cardview.setOrientation(0);
        }
    }

    @SimpleProperty
    public int MATCH_PARENT() {
        return -1;
    }

    @SimpleProperty
    public int WRAP_CONTENT() {
        return -2;
    }

    @SimpleFunction
    public int getPixels(int dp) {
        design_size size;
        new design_size(this.context);
        return size.getPixels(dp);
    }

    @SimpleProperty
    public String VERTICAL() {
        return "VERTICAL";
    }

    @SimpleProperty
    public String HORIZONTAL() {
        return "HORIZONTAL";
    }

    @SimpleProperty
    public String CENTER() {
        return "CENTER";
    }

    @SimpleProperty
    public String LEFT() {
        return "LEFT";
    }

    @SimpleProperty
    public String END() {
        return "END";
    }

    @SimpleProperty
    public String TOP() {
        return "TOP";
    }

    @SimpleProperty
    public String RIGHT() {
        return "RIGHT";
    }

    @SimpleProperty
    public String BOTTOM() {
        return "BOTTOM";
    }

    @SimpleProperty
    public String START() {
        return "START";
    }

    @SimpleProperty
    public String LEFT_CENTER() {
        return "LEFT_CENTER";
    }

    @SimpleProperty
    public String RIGHT_CENTER() {
        return "RIGHT_CENTER";
    }

    @SimpleProperty
    public String TOP_CENTER() {
        return "TOP_CENTER";
    }

    @SimpleProperty
    public String BUTTOM_CENTER() {
        return "BUTTOM_CENTER";
    }

    @SimpleProperty
    public int TRANSPARENT() {
        return 17170445;
    }

    @SimpleProperty
    public String TOP_LEFT() {
        return "TOP_LEFT";
    }

    @SimpleProperty
    public String BUTTOM_LEFT() {
        return "BUTTOM_LEFT";
    }

    @SimpleProperty
    public String TOP_RIGHT() {
        return "TOP_RIGHT";
    }

    @SimpleProperty
    public String BUTTOM_RIGHT() {
        return "BUTTOM_RIGHT";
    }

    @SimpleProperty
    public String DEFAULT() {
        return "DEFAULT";
    }

    @SimpleProperty
    public String NORMAL() {
        return "NORMAL";
    }

    @SimpleProperty
    public String BOLD() {
        return "BOLD";
    }

    @SimpleProperty
    public String ITALIC() {
        return "ITALIC";
    }

    @SimpleProperty(description = "Shape - RECTANGLE")
    public String RECTANGLE() {
        return "RECTANGLE";
    }

    @SimpleProperty(description = "Shape - OVAL ")
    public String OVAL() {
        return "OVAL";
    }

    @SimpleProperty(description = "Shape - OVAL ")
    public String ROUNDED() {
        return "ROUNDED";
    }

    @SuppressLint({"RtlHardcoded"})
    public void Gravity_Text(String str) {
        String mGravity = str;
        if (mGravity.contains(CENTER()) && !mGravity.contains("_")) {
            this.textView.setGravity(17);
        } else if (mGravity.contains(LEFT()) && !mGravity.contains("_")) {
            this.textView.setGravity(3);
        } else if (mGravity.contains(RIGHT()) && !mGravity.contains("_")) {
            this.textView.setGravity(5);
        } else if (mGravity.contains(TOP()) && !mGravity.contains("_")) {
            this.textView.setGravity(48);
        } else if (mGravity.contains(BOTTOM()) && !mGravity.contains("_")) {
            this.textView.setGravity(80);
        } else if (mGravity.contains(START()) && !mGravity.contains("_")) {
            this.textView.setGravity(GravityCompat.START);
        } else if (mGravity.contains(END()) && !mGravity.contains("_")) {
            this.textView.setGravity(GravityCompat.END);
        } else if (mGravity.contains(LEFT_CENTER())) {
            this.textView.setGravity(19);
        } else if (mGravity.contains(RIGHT_CENTER())) {
            this.textView.setGravity(21);
        } else if (mGravity.contains(TOP_LEFT())) {
            this.textView.setGravity(51);
        } else if (mGravity.contains(TOP_RIGHT())) {
            this.textView.setGravity(53);
        } else if (mGravity.contains(BUTTOM_LEFT())) {
            this.textView.setGravity(83);
        } else if (mGravity.contains(BUTTOM_RIGHT())) {
            this.textView.setGravity(85);
        } else if (mGravity.contains(TOP_CENTER())) {
            this.textView.setGravity(49);
        } else if (mGravity.contains(BUTTOM_CENTER())) {
            this.textView.setGravity(81);
        }
    }

    @SimpleFunction
    public void List(AndroidViewComponent androidViewComponent, String str, List<AndroidViewComponent> list) {
        design_size design_size;
        ScrollView scrollView2;
        LinearLayout linearLayout2;
        ViewGroup.LayoutParams layoutParams;
        AndroidViewComponent layout = androidViewComponent;
        String Color = str;
        List<AndroidViewComponent> list2 = list;
        new design_size(this.context);
        design_size size = design_size;
        new ScrollView(this.context);
        this.scrollView = scrollView2;
        new LinearLayout(this.context);
        LinearLayout linearLayout3 = linearLayout2;
        new LinearLayout.LayoutParams(-1, -1);
        linearLayout3.setLayoutParams(layoutParams);
        if (this.Horizontal_List) {
            linearLayout3.setOrientation(0);
        } else {
            linearLayout3.setOrientation(1);
        }
        if (Color.contains("#")) {
            linearLayout3.setBackgroundColor(Color.parseColor(Color));
        } else {
            try {
                linearLayout3.setBackgroundColor(Integer.parseInt(Color));
            } catch (NumberFormatException e) {
                NumberFormatException numberFormatException = e;
                linearLayout3.setBackgroundColor(0);
            }
        }
        linearLayout3.setPadding(0, 0, 0, size.getPixels(10));
        for (int i = 1; i <= list2.size(); i++) {
            linearLayout3.addView(list2.get(i).getView());
        }
        ViewGroup layouy_view = (ViewGroup) layout.getView();
        layouy_view.removeAllViews();
        this.scrollView.addView(linearLayout3);
        layouy_view.addView(this.scrollView);
    }

    private int[] convert(String[] strArr) {
        String[] string = strArr;
        int[] number = new int[string.length];
        for (int i = 0; i < string.length; i++) {
            number[i] = Integer.valueOf(string[i]).intValue();
        }
        return number;
    }

    public boolean isPermissionGranted() {
        if (Build.VERSION.SDK_INT < 23) {
            return true;
        }
        if (this.container.$context().checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE") == 0 && this.container.$context().checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") == 0) {
            return true;
        }
        Form $form = this.container.$form();
        String[] strArr = new String[2];
        strArr[0] = "android.permission.READ_EXTERNAL_STORAGE";
        String[] strArr2 = strArr;
        strArr2[1] = "android.permission.WRITE_EXTERNAL_STORAGE";
        $form.requestPermissions(strArr2, 1);
        return false;
    }
}
