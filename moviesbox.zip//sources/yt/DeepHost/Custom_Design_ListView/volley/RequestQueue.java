package yt.DeepHost.Custom_Design_ListView.volley;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.atomic.AtomicInteger;

public class RequestQueue {
    private static final int DEFAULT_NETWORK_THREAD_POOL_SIZE = 4;
    private final Cache mCache;
    private CacheDispatcher mCacheDispatcher;
    private final PriorityBlockingQueue<Request<?>> mCacheQueue;
    private final Set<Request<?>> mCurrentRequests;
    private final ResponseDelivery mDelivery;
    private final NetworkDispatcher[] mDispatchers;
    private final List<RequestEventListener> mEventListeners;
    private final List<RequestFinishedListener> mFinishedListeners;
    private final Network mNetwork;
    private final PriorityBlockingQueue<Request<?>> mNetworkQueue;
    private final AtomicInteger mSequenceGenerator;

    @Retention(RetentionPolicy.SOURCE)
    public @interface RequestEvent {
        public static final int REQUEST_CACHE_LOOKUP_FINISHED = 2;
        public static final int REQUEST_CACHE_LOOKUP_STARTED = 1;
        public static final int REQUEST_FINISHED = 5;
        public static final int REQUEST_NETWORK_DISPATCH_FINISHED = 4;
        public static final int REQUEST_NETWORK_DISPATCH_STARTED = 3;
        public static final int REQUEST_QUEUED = 0;
    }

    public interface RequestEventListener {
        void onRequestEvent(Request<?> request, int i);
    }

    public interface RequestFilter {
        boolean apply(Request<?> request);
    }

    @Deprecated
    public interface RequestFinishedListener<T> {
        void onRequestFinished(Request<T> request);
    }

    public RequestQueue(Cache cache, Network network, int threadPoolSize, ResponseDelivery delivery) {
        AtomicInteger atomicInteger;
        Set<Request<?>> set;
        PriorityBlockingQueue<Request<?>> priorityBlockingQueue;
        PriorityBlockingQueue<Request<?>> priorityBlockingQueue2;
        List<RequestFinishedListener> list;
        List<RequestEventListener> list2;
        new AtomicInteger();
        this.mSequenceGenerator = atomicInteger;
        new HashSet();
        this.mCurrentRequests = set;
        new PriorityBlockingQueue<>();
        this.mCacheQueue = priorityBlockingQueue;
        new PriorityBlockingQueue<>();
        this.mNetworkQueue = priorityBlockingQueue2;
        new ArrayList();
        this.mFinishedListeners = list;
        new ArrayList();
        this.mEventListeners = list2;
        this.mCache = cache;
        this.mNetwork = network;
        this.mDispatchers = new NetworkDispatcher[threadPoolSize];
        this.mDelivery = delivery;
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public RequestQueue(yt.DeepHost.Custom_Design_ListView.volley.Cache r15, yt.DeepHost.Custom_Design_ListView.volley.Network r16, int r17) {
        /*
            r14 = this;
            r0 = r14
            r1 = r15
            r2 = r16
            r3 = r17
            r4 = r0
            r5 = r1
            r6 = r2
            r7 = r3
            yt.DeepHost.Custom_Design_ListView.volley.ExecutorDelivery r8 = new yt.DeepHost.Custom_Design_ListView.volley.ExecutorDelivery
            r13 = r8
            r8 = r13
            r9 = r13
            android.os.Handler r10 = new android.os.Handler
            r13 = r10
            r10 = r13
            r11 = r13
            android.os.Looper r12 = android.os.Looper.getMainLooper()
            r11.<init>(r12)
            r9.<init>((android.os.Handler) r10)
            r4.<init>(r5, r6, r7, r8)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: yt.DeepHost.Custom_Design_ListView.volley.RequestQueue.<init>(yt.DeepHost.Custom_Design_ListView.volley.Cache, yt.DeepHost.Custom_Design_ListView.volley.Network, int):void");
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public RequestQueue(Cache cache, Network network) {
        this(cache, network, 4);
    }

    public void start() {
        CacheDispatcher cacheDispatcher;
        NetworkDispatcher networkDispatcher;
        stop();
        new CacheDispatcher(this.mCacheQueue, this.mNetworkQueue, this.mCache, this.mDelivery);
        this.mCacheDispatcher = cacheDispatcher;
        this.mCacheDispatcher.start();
        for (int i = 0; i < this.mDispatchers.length; i++) {
            new NetworkDispatcher(this.mNetworkQueue, this.mNetwork, this.mCache, this.mDelivery);
            NetworkDispatcher networkDispatcher2 = networkDispatcher;
            this.mDispatchers[i] = networkDispatcher2;
            networkDispatcher2.start();
        }
    }

    public void stop() {
        if (this.mCacheDispatcher != null) {
            this.mCacheDispatcher.quit();
        }
        NetworkDispatcher[] networkDispatcherArr = this.mDispatchers;
        int length = networkDispatcherArr.length;
        for (int i = 0; i < length; i++) {
            NetworkDispatcher mDispatcher = networkDispatcherArr[i];
            if (mDispatcher != null) {
                mDispatcher.quit();
            }
        }
    }

    public int getSequenceNumber() {
        return this.mSequenceGenerator.incrementAndGet();
    }

    public Cache getCache() {
        return this.mCache;
    }

    /* JADX INFO: finally extract failed */
    public void cancelAll(RequestFilter requestFilter) {
        RequestFilter filter = requestFilter;
        Set<Request<?>> set = this.mCurrentRequests;
        Set<Request<?>> set2 = set;
        synchronized (set) {
            try {
                for (Request<?> request : this.mCurrentRequests) {
                    if (filter.apply(request)) {
                        request.cancel();
                    }
                }
            } catch (Throwable th) {
                Throwable th2 = th;
                Set<Request<?>> set3 = set2;
                throw th2;
            }
        }
    }

    public void cancelAll(Object obj) {
        RequestFilter requestFilter;
        Throwable th;
        Object tag = obj;
        if (tag == null) {
            Throwable th2 = th;
            new IllegalArgumentException("Cannot cancelAll with a null tag");
            throw th2;
        }
        final Object obj2 = tag;
        new RequestFilter(this) {
            final /* synthetic */ RequestQueue this$0;

            {
                this.this$0 = this$0;
            }

            public boolean apply(Request<?> request) {
                return request.getTag() == obj2;
            }
        };
        cancelAll(requestFilter);
    }

    /* JADX INFO: finally extract failed */
    public <T> Request<T> add(Request<T> request) {
        Request<T> request2 = request;
        Request<?> requestQueue = request2.setRequestQueue(this);
        Set<Request<?>> set = this.mCurrentRequests;
        Set<Request<?>> set2 = set;
        synchronized (set) {
            try {
                boolean add = this.mCurrentRequests.add(request2);
                Request<?> sequence = request2.setSequence(getSequenceNumber());
                request2.addMarker("add-to-queue");
                sendRequestEvent(request2, 0);
                if (!request2.shouldCache()) {
                    boolean add2 = this.mNetworkQueue.add(request2);
                    return request2;
                }
                boolean add3 = this.mCacheQueue.add(request2);
                return request2;
            } catch (Throwable th) {
                while (true) {
                    Throwable th2 = th;
                    Set<Request<?>> set3 = set2;
                    throw th2;
                }
            }
        }
    }

    /* JADX INFO: finally extract failed */
    /* access modifiers changed from: package-private */
    public <T> void finish(Request<T> request) {
        Request<T> request2 = request;
        Set<Request<?>> set = this.mCurrentRequests;
        Set<Request<?>> set2 = set;
        synchronized (set) {
            try {
                boolean remove = this.mCurrentRequests.remove(request2);
                List<RequestFinishedListener> list = this.mFinishedListeners;
                List<RequestFinishedListener> list2 = list;
                synchronized (list) {
                    try {
                        for (RequestFinishedListener onRequestFinished : this.mFinishedListeners) {
                            onRequestFinished.onRequestFinished(request2);
                        }
                        sendRequestEvent(request2, 5);
                    } catch (Throwable th) {
                        while (true) {
                            Throwable th2 = th;
                            List<RequestFinishedListener> list3 = list2;
                            throw th2;
                        }
                    }
                }
            } catch (Throwable th3) {
                while (true) {
                    Throwable th4 = th3;
                    Set<Request<?>> set3 = set2;
                    throw th4;
                }
            }
        }
    }

    /* JADX INFO: finally extract failed */
    /* access modifiers changed from: package-private */
    public void sendRequestEvent(Request<?> request, int i) {
        Request<?> request2 = request;
        int event = i;
        List<RequestEventListener> list = this.mEventListeners;
        List<RequestEventListener> list2 = list;
        synchronized (list) {
            try {
                for (RequestEventListener listener : this.mEventListeners) {
                    listener.onRequestEvent(request2, event);
                }
            } catch (Throwable th) {
                Throwable th2 = th;
                List<RequestEventListener> list3 = list2;
                throw th2;
            }
        }
    }

    public void addRequestEventListener(RequestEventListener requestEventListener) {
        RequestEventListener listener = requestEventListener;
        List<RequestEventListener> list = this.mEventListeners;
        List<RequestEventListener> list2 = list;
        synchronized (list) {
            try {
                boolean add = this.mEventListeners.add(listener);
            } catch (Throwable th) {
                Throwable th2 = th;
                List<RequestEventListener> list3 = list2;
                throw th2;
            }
        }
    }

    public void removeRequestEventListener(RequestEventListener requestEventListener) {
        RequestEventListener listener = requestEventListener;
        List<RequestEventListener> list = this.mEventListeners;
        List<RequestEventListener> list2 = list;
        synchronized (list) {
            try {
                boolean remove = this.mEventListeners.remove(listener);
            } catch (Throwable th) {
                Throwable th2 = th;
                List<RequestEventListener> list3 = list2;
                throw th2;
            }
        }
    }

    @Deprecated
    public <T> void addRequestFinishedListener(RequestFinishedListener<T> requestFinishedListener) {
        RequestFinishedListener<T> listener = requestFinishedListener;
        List<RequestFinishedListener> list = this.mFinishedListeners;
        List<RequestFinishedListener> list2 = list;
        synchronized (list) {
            try {
                boolean add = this.mFinishedListeners.add(listener);
            } catch (Throwable th) {
                Throwable th2 = th;
                List<RequestFinishedListener> list3 = list2;
                throw th2;
            }
        }
    }

    @Deprecated
    public <T> void removeRequestFinishedListener(RequestFinishedListener<T> requestFinishedListener) {
        RequestFinishedListener<T> listener = requestFinishedListener;
        List<RequestFinishedListener> list = this.mFinishedListeners;
        List<RequestFinishedListener> list2 = list;
        synchronized (list) {
            try {
                boolean remove = this.mFinishedListeners.remove(listener);
            } catch (Throwable th) {
                Throwable th2 = th;
                List<RequestFinishedListener> list3 = list2;
                throw th2;
            }
        }
    }
}
