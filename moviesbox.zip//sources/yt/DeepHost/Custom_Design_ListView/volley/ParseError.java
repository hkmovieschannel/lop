package yt.DeepHost.Custom_Design_ListView.volley;

public class ParseError extends VolleyError {
    public ParseError() {
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public ParseError(NetworkResponse networkResponse) {
        super(networkResponse);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public ParseError(Throwable cause) {
        super(cause);
    }
}
