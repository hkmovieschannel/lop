package yt.DeepHost.Custom_Design_ListView.volley;

import android.content.Context;
import android.graphics.BitmapFactory;
import java.io.File;
import yt.DeepHost.Custom_Design_ListView.volley.toolbox.ImageLoader;
import yt.DeepHost.Custom_Design_ListView.volley.toolbox.NetworkImageView;

public final class ViewUtil {
    private ViewUtil() {
    }

    public static void setCircleImageURL(Context context, NetworkImageView networkImageView, String str, String loading, String offline) {
        Context context2 = context;
        NetworkImageView view = networkImageView;
        String url = str;
        ImageLoader mImageLoader = CustomVolleyRequestQueue.getInstance(context2).getImageLoader();
        ImageLoader.ImageContainer imageContainer = mImageLoader.get(url, ImageLoader.getImageListener(context2, view, loading, offline));
        view.setImageUrl(url, mImageLoader);
        view.requestLayout();
    }

    public static void setImageFile(Context context, NetworkImageView networkImageView, String str, String str2, String str3) {
        File file;
        Context context2 = context;
        NetworkImageView view = networkImageView;
        String url = str;
        String loading = str2;
        String offline = str3;
        if (url != null) {
            if (url.startsWith("/storage")) {
                new File(url);
                File imgFile = file;
                if (imgFile.exists()) {
                    view.setDefaultImageBitmap(BitmapFactory.decodeFile(imgFile.getAbsolutePath()));
                }
            } else {
                ImageLoader mImageLoader = CustomVolleyRequestQueue.getInstance(context2).getImageLoader();
                ImageLoader.ImageContainer imageContainer = mImageLoader.get(url, ImageLoader.getImageListener(context2, view, loading, offline));
                view.setImageUrl(url, mImageLoader);
            }
        }
        if (url != null) {
            view.setAdjustViewBounds(true);
        }
        view.requestLayout();
    }

    public static void setImageURL(Context context, NetworkImageView networkImageView, String str, String loading, String offline) {
        Context context2 = context;
        NetworkImageView view = networkImageView;
        String url = str;
        ImageLoader mImageLoader = CustomVolleyRequestQueue.getInstance(context2).getImageLoader();
        ImageLoader.ImageContainer imageContainer = mImageLoader.get(url, ImageLoader.getImageListener(context2, view, loading, offline));
        view.setImageUrl(url, mImageLoader);
        if (url != null) {
            view.setAdjustViewBounds(true);
        }
        view.requestLayout();
    }

    public static void setImage_Right(Context context, NetworkImageView networkImageView, String str, String loading, String offline) {
        Context context2 = context;
        NetworkImageView view = networkImageView;
        String url = str;
        ImageLoader mImageLoader = CustomVolleyRequestQueue.getInstance(context2).getImageLoader();
        ImageLoader.ImageContainer imageContainer = mImageLoader.get(url, ImageLoader.getImageListener(context2, view, loading, offline));
        view.setImageUrl(url, mImageLoader);
        if (url != null) {
            view.setAdjustViewBounds(true);
        }
        view.requestLayout();
    }

    public static void setImage_Left(Context context, NetworkImageView networkImageView, String str, String loading, String offline) {
        Context context2 = context;
        NetworkImageView view = networkImageView;
        String url = str;
        ImageLoader mImageLoader = CustomVolleyRequestQueue.getInstance(context2).getImageLoader();
        ImageLoader.ImageContainer imageContainer = mImageLoader.get(url, ImageLoader.getImageListener(context2, view, loading, offline));
        view.setImageUrl(url, mImageLoader);
        if (url != null) {
            view.setAdjustViewBounds(true);
        }
        view.requestLayout();
    }
}
