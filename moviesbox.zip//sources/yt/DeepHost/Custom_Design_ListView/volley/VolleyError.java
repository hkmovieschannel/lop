package yt.DeepHost.Custom_Design_ListView.volley;

public class VolleyError extends Exception {
    public final NetworkResponse networkResponse;
    private long networkTimeMs;

    public VolleyError() {
        this.networkResponse = null;
    }

    public VolleyError(NetworkResponse response) {
        this.networkResponse = response;
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public VolleyError(String exceptionMessage) {
        super(exceptionMessage);
        this.networkResponse = null;
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public VolleyError(String exceptionMessage, Throwable reason) {
        super(exceptionMessage, reason);
        this.networkResponse = null;
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public VolleyError(Throwable cause) {
        super(cause);
        this.networkResponse = null;
    }

    /* access modifiers changed from: package-private */
    public void setNetworkTimeMs(long networkTimeMs2) {
        long j = networkTimeMs2;
        this.networkTimeMs = j;
    }

    public long getNetworkTimeMs() {
        return this.networkTimeMs;
    }
}
