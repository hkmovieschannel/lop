package yt.DeepHost.Custom_Design_ListView.volley;

public class NetworkError extends VolleyError {
    public NetworkError() {
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public NetworkError(Throwable cause) {
        super(cause);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public NetworkError(NetworkResponse networkResponse) {
        super(networkResponse);
    }
}
