package yt.DeepHost.Custom_Design_ListView.volley;

public interface Network {
    NetworkResponse performRequest(Request<?> request) throws VolleyError;
}
