package yt.DeepHost.Custom_Design_ListView.volley;

import yt.DeepHost.Custom_Design_ListView.volley.Cache;

public class Response<T> {
    public final Cache.Entry cacheEntry;
    public final VolleyError error;
    public boolean intermediate;
    public final T result;

    public interface ErrorListener {
        void onErrorResponse(VolleyError volleyError);
    }

    public interface Listener<T> {
        void onResponse(T t);
    }

    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static <T> yt.DeepHost.Custom_Design_ListView.volley.Response<T> success(T r7, yt.DeepHost.Custom_Design_ListView.volley.Cache.Entry r8) {
        /*
            r0 = r7
            r1 = r8
            yt.DeepHost.Custom_Design_ListView.volley.Response r2 = new yt.DeepHost.Custom_Design_ListView.volley.Response
            r6 = r2
            r2 = r6
            r3 = r6
            r4 = r0
            r5 = r1
            r3.<init>(r4, r5)
            r0 = r2
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: yt.DeepHost.Custom_Design_ListView.volley.Response.success(java.lang.Object, yt.DeepHost.Custom_Design_ListView.volley.Cache$Entry):yt.DeepHost.Custom_Design_ListView.volley.Response");
    }

    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static <T> yt.DeepHost.Custom_Design_ListView.volley.Response<T> error(yt.DeepHost.Custom_Design_ListView.volley.VolleyError r5) {
        /*
            r0 = r5
            yt.DeepHost.Custom_Design_ListView.volley.Response r1 = new yt.DeepHost.Custom_Design_ListView.volley.Response
            r4 = r1
            r1 = r4
            r2 = r4
            r3 = r0
            r2.<init>(r3)
            r0 = r1
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: yt.DeepHost.Custom_Design_ListView.volley.Response.error(yt.DeepHost.Custom_Design_ListView.volley.VolleyError):yt.DeepHost.Custom_Design_ListView.volley.Response");
    }

    public boolean isSuccess() {
        return this.error == null;
    }

    private Response(T result2, Cache.Entry cacheEntry2) {
        this.intermediate = false;
        this.result = result2;
        this.cacheEntry = cacheEntry2;
        this.error = null;
    }

    private Response(VolleyError error2) {
        this.intermediate = false;
        this.result = null;
        this.cacheEntry = null;
        this.error = error2;
    }
}
