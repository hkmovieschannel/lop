package yt.DeepHost.Custom_Design_ListView.volley;

import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import androidx.annotation.CallSuper;
import androidx.annotation.GuardedBy;
import androidx.annotation.Nullable;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Collections;
import java.util.Map;
import yt.DeepHost.Custom_Design_ListView.volley.Cache;
import yt.DeepHost.Custom_Design_ListView.volley.Response;
import yt.DeepHost.Custom_Design_ListView.volley.VolleyLog;

public abstract class Request<T> implements Comparable<Request<T>> {
    private static final String DEFAULT_PARAMS_ENCODING = "UTF-8";
    private Cache.Entry mCacheEntry;
    @GuardedBy("mLock")
    private boolean mCanceled;
    private final int mDefaultTrafficStatsTag;
    @GuardedBy("mLock")
    @Nullable
    private Response.ErrorListener mErrorListener;
    /* access modifiers changed from: private */
    public final VolleyLog.MarkerLog mEventLog;
    private final Object mLock;
    private final int mMethod;
    @GuardedBy("mLock")
    private NetworkRequestCompleteListener mRequestCompleteListener;
    private RequestQueue mRequestQueue;
    @GuardedBy("mLock")
    private boolean mResponseDelivered;
    private RetryPolicy mRetryPolicy;
    private Integer mSequence;
    private boolean mShouldCache;
    private boolean mShouldRetryServerErrors;
    private Object mTag;
    private final String mUrl;

    public interface Method {
        public static final int DELETE = 3;
        public static final int DEPRECATED_GET_OR_POST = -1;
        public static final int GET = 0;
        public static final int HEAD = 4;
        public static final int OPTIONS = 5;
        public static final int PATCH = 7;
        public static final int POST = 1;
        public static final int PUT = 2;
        public static final int TRACE = 6;
    }

    interface NetworkRequestCompleteListener {
        void onNoUsableResponseReceived(Request<?> request);

        void onResponseReceived(Request<?> request, Response<?> response);
    }

    public enum Priority {
    }

    /* access modifiers changed from: protected */
    public abstract void deliverResponse(T t);

    /* access modifiers changed from: protected */
    public abstract Response<T> parseNetworkResponse(NetworkResponse networkResponse);

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    @Deprecated
    public Request(String url, Response.ErrorListener listener) {
        this(-1, url, listener);
    }

    public Request(int i, String str, @Nullable Response.ErrorListener errorListener) {
        VolleyLog.MarkerLog markerLog;
        Object obj;
        RetryPolicy retryPolicy;
        VolleyLog.MarkerLog markerLog2;
        int method = i;
        String url = str;
        Response.ErrorListener listener = errorListener;
        if (VolleyLog.MarkerLog.ENABLED) {
            markerLog = markerLog2;
            new VolleyLog.MarkerLog();
        } else {
            markerLog = null;
        }
        this.mEventLog = markerLog;
        new Object();
        this.mLock = obj;
        this.mShouldCache = true;
        this.mCanceled = false;
        this.mResponseDelivered = false;
        this.mShouldRetryServerErrors = false;
        this.mCacheEntry = null;
        this.mMethod = method;
        this.mUrl = url;
        this.mErrorListener = listener;
        new DefaultRetryPolicy();
        Request<?> retryPolicy2 = setRetryPolicy(retryPolicy);
        this.mDefaultTrafficStatsTag = findDefaultTrafficStatsTag(url);
    }

    public int getMethod() {
        return this.mMethod;
    }

    public Request<?> setTag(Object tag) {
        this.mTag = tag;
        return this;
    }

    public Object getTag() {
        return this.mTag;
    }

    @Nullable
    public Response.ErrorListener getErrorListener() {
        Object obj = this.mLock;
        Object obj2 = obj;
        synchronized (obj) {
            try {
                Response.ErrorListener errorListener = this.mErrorListener;
                return errorListener;
            } catch (Throwable th) {
                Throwable th2 = th;
                Object obj3 = obj2;
                throw th2;
            }
        }
    }

    public int getTrafficStatsTag() {
        return this.mDefaultTrafficStatsTag;
    }

    private static int findDefaultTrafficStatsTag(String str) {
        Uri uri;
        String host;
        String url = str;
        if (TextUtils.isEmpty(url) || (uri = Uri.parse(url)) == null || (host = uri.getHost()) == null) {
            return 0;
        }
        return host.hashCode();
    }

    public Request<?> setRetryPolicy(RetryPolicy retryPolicy) {
        this.mRetryPolicy = retryPolicy;
        return this;
    }

    public void addMarker(String str) {
        String tag = str;
        if (VolleyLog.MarkerLog.ENABLED) {
            this.mEventLog.add(tag, Thread.currentThread().getId());
        }
    }

    /* access modifiers changed from: package-private */
    public void finish(String str) {
        Handler mainThread;
        Runnable runnable;
        String tag = str;
        if (this.mRequestQueue != null) {
            this.mRequestQueue.finish(this);
        }
        if (VolleyLog.MarkerLog.ENABLED) {
            long threadId = Thread.currentThread().getId();
            if (Looper.myLooper() != Looper.getMainLooper()) {
                new Handler(Looper.getMainLooper());
                final String str2 = tag;
                final long j = threadId;
                new Runnable(this) {
                    final /* synthetic */ Request this$0;

                    {
                        this.this$0 = this$0;
                    }

                    public void run() {
                        this.this$0.mEventLog.add(str2, j);
                        this.this$0.mEventLog.finish(this.this$0.toString());
                    }
                };
                boolean post = mainThread.post(runnable);
                return;
            }
            this.mEventLog.add(tag, threadId);
            this.mEventLog.finish(toString());
        }
    }

    /* access modifiers changed from: package-private */
    public void sendEvent(int i) {
        int event = i;
        if (this.mRequestQueue != null) {
            this.mRequestQueue.sendRequestEvent(this, event);
        }
    }

    public Request<?> setRequestQueue(RequestQueue requestQueue) {
        this.mRequestQueue = requestQueue;
        return this;
    }

    public final Request<?> setSequence(int sequence) {
        this.mSequence = Integer.valueOf(sequence);
        return this;
    }

    public final int getSequence() {
        Throwable th;
        if (this.mSequence != null) {
            return this.mSequence.intValue();
        }
        Throwable th2 = th;
        new IllegalStateException("getSequence called before setSequence");
        throw th2;
    }

    public String getUrl() {
        return this.mUrl;
    }

    public String getCacheKey() {
        StringBuilder sb;
        String url = getUrl();
        int method = getMethod();
        if (method == 0 || method == -1) {
            return url;
        }
        new StringBuilder();
        return sb.append(Integer.toString(method)).append('-').append(url).toString();
    }

    public Request<?> setCacheEntry(Cache.Entry entry) {
        this.mCacheEntry = entry;
        return this;
    }

    public Cache.Entry getCacheEntry() {
        return this.mCacheEntry;
    }

    @CallSuper
    public void cancel() {
        Object obj = this.mLock;
        Object obj2 = obj;
        synchronized (obj) {
            try {
                this.mCanceled = true;
                this.mErrorListener = null;
            } catch (Throwable th) {
                Throwable th2 = th;
                Object obj3 = obj2;
                throw th2;
            }
        }
    }

    public boolean isCanceled() {
        Object obj = this.mLock;
        Object obj2 = obj;
        synchronized (obj) {
            try {
                boolean z = this.mCanceled;
                return z;
            } catch (Throwable th) {
                Throwable th2 = th;
                Object obj3 = obj2;
                throw th2;
            }
        }
    }

    public Map<String, String> getHeaders() throws AuthFailureError {
        return Collections.emptyMap();
    }

    /* access modifiers changed from: protected */
    @Deprecated
    public Map<String, String> getPostParams() throws AuthFailureError {
        return getParams();
    }

    /* access modifiers changed from: protected */
    @Deprecated
    public String getPostParamsEncoding() {
        return getParamsEncoding();
    }

    @Deprecated
    public String getPostBodyContentType() {
        return getBodyContentType();
    }

    @Deprecated
    public byte[] getPostBody() throws AuthFailureError {
        Map<String, String> postParams = getPostParams();
        if (postParams == null || postParams.size() <= 0) {
            return null;
        }
        return encodeParameters(postParams, getPostParamsEncoding());
    }

    /* access modifiers changed from: protected */
    public Map<String, String> getParams() throws AuthFailureError {
        return null;
    }

    /* access modifiers changed from: protected */
    public String getParamsEncoding() {
        return "UTF-8";
    }

    public String getBodyContentType() {
        StringBuilder sb;
        new StringBuilder();
        return sb.append("application/x-www-form-urlencoded; charset=").append(getParamsEncoding()).toString();
    }

    public byte[] getBody() throws AuthFailureError {
        Map<String, String> params = getParams();
        if (params == null || params.size() <= 0) {
            return null;
        }
        return encodeParameters(params, getParamsEncoding());
    }

    private byte[] encodeParameters(Map<String, String> params, String str) {
        StringBuilder sb;
        Throwable th;
        StringBuilder sb2;
        Throwable th2;
        String paramsEncoding = str;
        new StringBuilder();
        StringBuilder encodedParams = sb;
        try {
            for (Map.Entry<String, String> entry : params.entrySet()) {
                if (entry.getKey() == null || entry.getValue() == null) {
                    Throwable th3 = th2;
                    Object[] objArr = new Object[2];
                    objArr[0] = entry.getKey();
                    Object[] objArr2 = objArr;
                    objArr2[1] = entry.getValue();
                    new IllegalArgumentException(String.format("Request#getParams() or Request#getPostParams() returned a map containing a null key or value: (%s, %s). All keys and values must be non-null.", objArr2));
                    throw th3;
                }
                StringBuilder append = encodedParams.append(URLEncoder.encode(entry.getKey(), paramsEncoding));
                StringBuilder append2 = encodedParams.append('=');
                StringBuilder append3 = encodedParams.append(URLEncoder.encode(entry.getValue(), paramsEncoding));
                StringBuilder append4 = encodedParams.append('&');
            }
            return encodedParams.toString().getBytes(paramsEncoding);
        } catch (UnsupportedEncodingException e) {
            UnsupportedEncodingException uee = e;
            Throwable th4 = th;
            new StringBuilder();
            new RuntimeException(sb2.append("Encoding not supported: ").append(paramsEncoding).toString(), uee);
            throw th4;
        }
    }

    public final Request<?> setShouldCache(boolean shouldCache) {
        this.mShouldCache = shouldCache;
        return this;
    }

    public final boolean shouldCache() {
        return this.mShouldCache;
    }

    public final Request<?> setShouldRetryServerErrors(boolean shouldRetryServerErrors) {
        this.mShouldRetryServerErrors = shouldRetryServerErrors;
        return this;
    }

    public final boolean shouldRetryServerErrors() {
        return this.mShouldRetryServerErrors;
    }

    public Priority getPriority() {
        return Priority.NORMAL;
    }

    public final int getTimeoutMs() {
        return getRetryPolicy().getCurrentTimeout();
    }

    public RetryPolicy getRetryPolicy() {
        return this.mRetryPolicy;
    }

    public void markDelivered() {
        Object obj = this.mLock;
        Object obj2 = obj;
        synchronized (obj) {
            try {
                this.mResponseDelivered = true;
            } catch (Throwable th) {
                Throwable th2 = th;
                Object obj3 = obj2;
                throw th2;
            }
        }
    }

    public boolean hasHadResponseDelivered() {
        Object obj = this.mLock;
        Object obj2 = obj;
        synchronized (obj) {
            try {
                boolean z = this.mResponseDelivered;
                return z;
            } catch (Throwable th) {
                Throwable th2 = th;
                Object obj3 = obj2;
                throw th2;
            }
        }
    }

    /* access modifiers changed from: protected */
    public VolleyError parseNetworkError(VolleyError volleyError) {
        return volleyError;
    }

    /* JADX INFO: finally extract failed */
    public void deliverError(VolleyError volleyError) {
        VolleyError error = volleyError;
        Object obj = this.mLock;
        Object obj2 = obj;
        synchronized (obj) {
            try {
                Response.ErrorListener listener = this.mErrorListener;
                if (listener != null) {
                    listener.onErrorResponse(error);
                }
            } catch (Throwable th) {
                while (true) {
                    Throwable th2 = th;
                    Object obj3 = obj2;
                    throw th2;
                }
            }
        }
    }

    /* access modifiers changed from: package-private */
    public void setNetworkRequestCompleteListener(NetworkRequestCompleteListener networkRequestCompleteListener) {
        NetworkRequestCompleteListener requestCompleteListener = networkRequestCompleteListener;
        Object obj = this.mLock;
        Object obj2 = obj;
        synchronized (obj) {
            try {
                this.mRequestCompleteListener = requestCompleteListener;
            } catch (Throwable th) {
                Throwable th2 = th;
                Object obj3 = obj2;
                throw th2;
            }
        }
    }

    /* JADX INFO: finally extract failed */
    /* access modifiers changed from: package-private */
    public void notifyListenerResponseReceived(Response<?> response) {
        Response<?> response2 = response;
        Object obj = this.mLock;
        Object obj2 = obj;
        synchronized (obj) {
            try {
                NetworkRequestCompleteListener listener = this.mRequestCompleteListener;
                if (listener != null) {
                    listener.onResponseReceived(this, response2);
                }
            } catch (Throwable th) {
                while (true) {
                    Throwable th2 = th;
                    Object obj3 = obj2;
                    throw th2;
                }
            }
        }
    }

    /* JADX INFO: finally extract failed */
    /* access modifiers changed from: package-private */
    public void notifyListenerResponseNotUsable() {
        Object obj = this.mLock;
        Object obj2 = obj;
        synchronized (obj) {
            try {
                NetworkRequestCompleteListener listener = this.mRequestCompleteListener;
                if (listener != null) {
                    listener.onNoUsableResponseReceived(this);
                }
            } catch (Throwable th) {
                while (true) {
                    Throwable th2 = th;
                    Object obj3 = obj2;
                    throw th2;
                }
            }
        }
    }

    public int compareTo(Request<T> request) {
        Request<T> other = request;
        Priority left = getPriority();
        Priority right = other.getPriority();
        return left == right ? this.mSequence.intValue() - other.mSequence.intValue() : right.ordinal() - left.ordinal();
    }

    public String toString() {
        StringBuilder sb;
        StringBuilder sb2;
        new StringBuilder();
        String trafficStatsTag = sb.append("0x").append(Integer.toHexString(getTrafficStatsTag())).toString();
        StringBuilder sb3 = sb2;
        new StringBuilder();
        return sb3.append(isCanceled() ? "[X] " : "[ ] ").append(getUrl()).append(" ").append(trafficStatsTag).append(" ").append(getPriority()).append(" ").append(this.mSequence).toString();
    }
}
