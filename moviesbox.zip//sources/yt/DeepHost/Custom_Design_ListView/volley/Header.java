package yt.DeepHost.Custom_Design_ListView.volley;

import android.text.TextUtils;

public final class Header {
    private final String mName;
    private final String mValue;

    public Header(String name, String value) {
        this.mName = name;
        this.mValue = value;
    }

    public final String getName() {
        return this.mName;
    }

    public final String getValue() {
        return this.mValue;
    }

    public boolean equals(Object obj) {
        Object o = obj;
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Header header = (Header) o;
        return TextUtils.equals(this.mName, header.mName) && TextUtils.equals(this.mValue, header.mValue);
    }

    public int hashCode() {
        return (31 * this.mName.hashCode()) + this.mValue.hashCode();
    }

    public String toString() {
        StringBuilder sb;
        new StringBuilder();
        return sb.append("Header[name=").append(this.mName).append(",value=").append(this.mValue).append("]").toString();
    }
}
