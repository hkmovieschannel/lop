package yt.DeepHost.Custom_Design_ListView.volley;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class NetworkResponse {
    public final List<Header> allHeaders;
    public final byte[] data;
    public final Map<String, String> headers;
    public final long networkTimeMs;
    public final boolean notModified;
    public final int statusCode;

    /* JADX WARNING: Illegal instructions before constructor call */
    @java.lang.Deprecated
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public NetworkResponse(int r18, byte[] r19, java.util.Map<java.lang.String, java.lang.String> r20, boolean r21, long r22) {
        /*
            r17 = this;
            r1 = r17
            r2 = r18
            r3 = r19
            r4 = r20
            r5 = r21
            r6 = r22
            r8 = r1
            r9 = r2
            r10 = r3
            r11 = r4
            r12 = r4
            java.util.List r12 = toAllHeaderList(r12)
            r13 = r5
            r14 = r6
            r8.<init>(r9, r10, r11, r12, r13, r14)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: yt.DeepHost.Custom_Design_ListView.volley.NetworkResponse.<init>(int, byte[], java.util.Map, boolean, long):void");
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public NetworkResponse(int r17, byte[] r18, boolean r19, long r20, java.util.List<yt.DeepHost.Custom_Design_ListView.volley.Header> r22) {
        /*
            r16 = this;
            r0 = r16
            r1 = r17
            r2 = r18
            r3 = r19
            r4 = r20
            r6 = r22
            r7 = r0
            r8 = r1
            r9 = r2
            r10 = r6
            java.util.Map r10 = toHeaderMap(r10)
            r11 = r6
            r12 = r3
            r13 = r4
            r7.<init>(r8, r9, r10, r11, r12, r13)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: yt.DeepHost.Custom_Design_ListView.volley.NetworkResponse.<init>(int, byte[], boolean, long, java.util.List):void");
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    @Deprecated
    public NetworkResponse(int statusCode2, byte[] data2, Map<String, String> headers2, boolean notModified2) {
        this(statusCode2, data2, headers2, notModified2, 0);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public NetworkResponse(byte[] data2) {
        this(200, data2, false, 0, (List<Header>) Collections.emptyList());
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    @Deprecated
    public NetworkResponse(byte[] data2, Map<String, String> headers2) {
        this(200, data2, headers2, false, 0);
    }

    private NetworkResponse(int statusCode2, byte[] data2, Map<String, String> headers2, List<Header> list, boolean z, long j) {
        List<Header> allHeaders2 = list;
        boolean notModified2 = z;
        long networkTimeMs2 = j;
        this.statusCode = statusCode2;
        this.data = data2;
        this.headers = headers2;
        if (allHeaders2 == null) {
            this.allHeaders = null;
        } else {
            this.allHeaders = Collections.unmodifiableList(allHeaders2);
        }
        this.notModified = notModified2;
        this.networkTimeMs = networkTimeMs2;
    }

    private static Map<String, String> toHeaderMap(List<Header> list) {
        Map<String, String> map;
        List<Header> allHeaders2 = list;
        if (allHeaders2 == null) {
            return null;
        }
        if (allHeaders2.isEmpty()) {
            return Collections.emptyMap();
        }
        new TreeMap(String.CASE_INSENSITIVE_ORDER);
        Map<String, String> headers2 = map;
        for (Header header : allHeaders2) {
            String put = headers2.put(header.getName(), header.getValue());
        }
        return headers2;
    }

    private static List<Header> toAllHeaderList(Map<String, String> map) {
        List<Header> list;
        Object obj;
        Map<String, String> headers2 = map;
        if (headers2 == null) {
            return null;
        }
        if (headers2.isEmpty()) {
            return Collections.emptyList();
        }
        new ArrayList(headers2.size());
        List<Header> allHeaders2 = list;
        for (Map.Entry<String, String> header : headers2.entrySet()) {
            new Header(header.getKey(), header.getValue());
            boolean add = allHeaders2.add(obj);
        }
        return allHeaders2;
    }
}
