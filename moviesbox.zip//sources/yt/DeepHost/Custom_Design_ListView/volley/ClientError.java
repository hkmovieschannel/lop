package yt.DeepHost.Custom_Design_ListView.volley;

public class ClientError extends ServerError {
    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public ClientError(NetworkResponse networkResponse) {
        super(networkResponse);
    }

    public ClientError() {
    }
}
