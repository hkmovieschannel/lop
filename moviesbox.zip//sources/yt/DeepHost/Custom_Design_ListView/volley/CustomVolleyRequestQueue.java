package yt.DeepHost.Custom_Design_ListView.volley;

import android.content.Context;
import android.graphics.Bitmap;
import android.util.LruCache;
import yt.DeepHost.Custom_Design_ListView.volley.toolbox.BaseHttpStack;
import yt.DeepHost.Custom_Design_ListView.volley.toolbox.BasicNetwork;
import yt.DeepHost.Custom_Design_ListView.volley.toolbox.DiskBasedCache;
import yt.DeepHost.Custom_Design_ListView.volley.toolbox.HurlStack;
import yt.DeepHost.Custom_Design_ListView.volley.toolbox.ImageLoader;

public class CustomVolleyRequestQueue {
    private static Context mContext;
    private static CustomVolleyRequestQueue mInstance;
    private ImageLoader mImageLoader;
    private RequestQueue mRequestQuee = getRequestQuee();

    private CustomVolleyRequestQueue(Context context) {
        ImageLoader imageLoader;
        ImageLoader.ImageCache imageCache;
        mContext = context;
        new ImageLoader.ImageCache(this) {
            private final LruCache<String, Bitmap> cache;
            final /* synthetic */ CustomVolleyRequestQueue this$0;

            {
                LruCache<String, Bitmap> lruCache;
                this.this$0 = this$0;
                new LruCache<>(20);
                this.cache = lruCache;
            }

            public Bitmap getBitmap(String url) {
                return this.cache.get(url);
            }

            public void putBitmap(String url, Bitmap bitmap) {
                Bitmap put = this.cache.put(url, bitmap);
            }
        };
        new ImageLoader(this.mRequestQuee, imageCache);
        this.mImageLoader = imageLoader;
    }

    public RequestQueue getRequestQuee() {
        Cache cache;
        Network network;
        BaseHttpStack baseHttpStack;
        RequestQueue requestQueue;
        if (this.mRequestQuee == null) {
            new DiskBasedCache(mContext.getCacheDir(), 10485760);
            new HurlStack();
            new BasicNetwork(baseHttpStack);
            new RequestQueue(cache, network);
            this.mRequestQuee = requestQueue;
            this.mRequestQuee.start();
        }
        return this.mRequestQuee;
    }

    public ImageLoader getImageLoader() {
        return this.mImageLoader;
    }

    public static synchronized CustomVolleyRequestQueue getInstance(Context context) {
        CustomVolleyRequestQueue customVolleyRequestQueue;
        CustomVolleyRequestQueue customVolleyRequestQueue2;
        Context context2 = context;
        synchronized (CustomVolleyRequestQueue.class) {
            if (mInstance == null) {
                new CustomVolleyRequestQueue(context2);
                mInstance = customVolleyRequestQueue2;
            }
            customVolleyRequestQueue = mInstance;
        }
        return customVolleyRequestQueue;
    }
}
