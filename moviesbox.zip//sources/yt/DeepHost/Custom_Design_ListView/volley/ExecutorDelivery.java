package yt.DeepHost.Custom_Design_ListView.volley;

import android.os.Handler;
import java.util.concurrent.Executor;

public class ExecutorDelivery implements ResponseDelivery {
    private final Executor mResponsePoster;

    public ExecutorDelivery(Handler handler) {
        Executor executor;
        final Handler handler2 = handler;
        new Executor(this) {
            final /* synthetic */ ExecutorDelivery this$0;

            {
                this.this$0 = this$0;
            }

            public void execute(Runnable command) {
                boolean post = handler2.post(command);
            }
        };
        this.mResponsePoster = executor;
    }

    public ExecutorDelivery(Executor executor) {
        this.mResponsePoster = executor;
    }

    public void postResponse(Request<?> request, Response<?> response) {
        postResponse(request, response, (Runnable) null);
    }

    public void postResponse(Request<?> request, Response<?> response, Runnable runnable) {
        Runnable runnable2;
        Request<?> request2 = request;
        request2.markDelivered();
        request2.addMarker("post-response");
        new ResponseDeliveryRunnable(request2, response, runnable);
        this.mResponsePoster.execute(runnable2);
    }

    public void postError(Request<?> request, VolleyError error) {
        Runnable runnable;
        Request<?> request2 = request;
        request2.addMarker("post-error");
        new ResponseDeliveryRunnable(request2, Response.error(error), (Runnable) null);
        this.mResponsePoster.execute(runnable);
    }

    private static class ResponseDeliveryRunnable implements Runnable {
        private final Request mRequest;
        private final Response mResponse;
        private final Runnable mRunnable;

        public ResponseDeliveryRunnable(Request request, Response response, Runnable runnable) {
            this.mRequest = request;
            this.mResponse = response;
            this.mRunnable = runnable;
        }

        public void run() {
            if (this.mRequest.isCanceled()) {
                this.mRequest.finish("canceled-at-delivery");
                return;
            }
            if (this.mResponse.isSuccess()) {
                this.mRequest.deliverResponse(this.mResponse.result);
            } else {
                this.mRequest.deliverError(this.mResponse.error);
            }
            if (this.mResponse.intermediate) {
                this.mRequest.addMarker("intermediate-response");
            } else {
                this.mRequest.finish("done");
            }
            if (this.mRunnable != null) {
                this.mRunnable.run();
            }
        }
    }
}
