package yt.DeepHost.Custom_Design_ListView.volley;

public class NoConnectionError extends NetworkError {
    public NoConnectionError() {
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public NoConnectionError(Throwable reason) {
        super(reason);
    }
}
