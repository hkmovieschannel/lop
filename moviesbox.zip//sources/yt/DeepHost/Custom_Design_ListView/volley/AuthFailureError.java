package yt.DeepHost.Custom_Design_ListView.volley;

import android.content.Intent;

public class AuthFailureError extends VolleyError {
    private Intent mResolutionIntent;

    public AuthFailureError() {
    }

    public AuthFailureError(Intent intent) {
        this.mResolutionIntent = intent;
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public AuthFailureError(NetworkResponse response) {
        super(response);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public AuthFailureError(String message) {
        super(message);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public AuthFailureError(String message, Exception reason) {
        super(message, reason);
    }

    public Intent getResolutionIntent() {
        return this.mResolutionIntent;
    }

    public String getMessage() {
        if (this.mResolutionIntent != null) {
            return "User needs to (re)enter credentials.";
        }
        return super.getMessage();
    }
}
