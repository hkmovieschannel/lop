package yt.DeepHost.Custom_Design_ListView.volley;

import android.os.Process;
import androidx.annotation.VisibleForTesting;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import yt.DeepHost.Custom_Design_ListView.volley.Cache;
import yt.DeepHost.Custom_Design_ListView.volley.Request;

public class CacheDispatcher extends Thread {
    private static final boolean DEBUG = VolleyLog.DEBUG;
    private final Cache mCache;
    private final BlockingQueue<Request<?>> mCacheQueue;
    /* access modifiers changed from: private */
    public final ResponseDelivery mDelivery;
    /* access modifiers changed from: private */
    public final BlockingQueue<Request<?>> mNetworkQueue;
    private volatile boolean mQuit = false;
    private final WaitingRequestManager mWaitingRequestManager;

    public CacheDispatcher(BlockingQueue<Request<?>> cacheQueue, BlockingQueue<Request<?>> networkQueue, Cache cache, ResponseDelivery delivery) {
        WaitingRequestManager waitingRequestManager;
        this.mCacheQueue = cacheQueue;
        this.mNetworkQueue = networkQueue;
        this.mCache = cache;
        this.mDelivery = delivery;
        new WaitingRequestManager(this);
        this.mWaitingRequestManager = waitingRequestManager;
    }

    public void quit() {
        this.mQuit = true;
        interrupt();
    }

    public void run() {
        if (DEBUG) {
            VolleyLog.v("start new dispatcher", new Object[0]);
        }
        Process.setThreadPriority(10);
        this.mCache.initialize();
        while (true) {
            try {
                processRequest();
            } catch (InterruptedException e) {
                InterruptedException interruptedException = e;
                if (this.mQuit) {
                    Thread.currentThread().interrupt();
                    return;
                }
                VolleyLog.e("Ignoring spurious interrupt of CacheDispatcher thread; use quit() to terminate it", new Object[0]);
            }
        }
    }

    private void processRequest() throws InterruptedException {
        processRequest(this.mCacheQueue.take());
    }

    /* access modifiers changed from: package-private */
    @VisibleForTesting
    public void processRequest(Request<?> request) throws InterruptedException {
        NetworkResponse networkResponse;
        Runnable runnable;
        Request<?> request2 = request;
        request2.addMarker("cache-queue-take");
        request2.sendEvent(1);
        try {
            if (request2.isCanceled()) {
                request2.finish("cache-discard-canceled");
                request2.sendEvent(2);
                return;
            }
            Cache.Entry entry = this.mCache.get(request2.getCacheKey());
            if (entry == null) {
                request2.addMarker("cache-miss");
                if (!this.mWaitingRequestManager.maybeAddToWaitingRequests(request2)) {
                    this.mNetworkQueue.put(request2);
                }
                request2.sendEvent(2);
            } else if (entry.isExpired()) {
                request2.addMarker("cache-hit-expired");
                Request<?> cacheEntry = request2.setCacheEntry(entry);
                if (!this.mWaitingRequestManager.maybeAddToWaitingRequests(request2)) {
                    this.mNetworkQueue.put(request2);
                }
                request2.sendEvent(2);
            } else {
                request2.addMarker("cache-hit");
                new NetworkResponse(entry.data, entry.responseHeaders);
                Response<?> response = request2.parseNetworkResponse(networkResponse);
                request2.addMarker("cache-hit-parsed");
                if (!entry.refreshNeeded()) {
                    this.mDelivery.postResponse(request2, response);
                } else {
                    request2.addMarker("cache-hit-refresh-needed");
                    Request<?> cacheEntry2 = request2.setCacheEntry(entry);
                    response.intermediate = true;
                    if (!this.mWaitingRequestManager.maybeAddToWaitingRequests(request2)) {
                        final Request<?> request3 = request2;
                        new Runnable(this) {
                            final /* synthetic */ CacheDispatcher this$0;

                            {
                                this.this$0 = this$0;
                            }

                            public void run() {
                                try {
                                    this.this$0.mNetworkQueue.put(request3);
                                } catch (InterruptedException e) {
                                    InterruptedException interruptedException = e;
                                    Thread.currentThread().interrupt();
                                }
                            }
                        };
                        this.mDelivery.postResponse(request2, response, runnable);
                    } else {
                        this.mDelivery.postResponse(request2, response);
                    }
                }
                request2.sendEvent(2);
            }
        } catch (Throwable th) {
            Throwable th2 = th;
            request2.sendEvent(2);
            throw th2;
        }
    }

    private static class WaitingRequestManager implements Request.NetworkRequestCompleteListener {
        private final CacheDispatcher mCacheDispatcher;
        private final Map<String, List<Request<?>>> mWaitingRequests;

        WaitingRequestManager(CacheDispatcher cacheDispatcher) {
            Map<String, List<Request<?>>> map;
            new HashMap();
            this.mWaitingRequests = map;
            this.mCacheDispatcher = cacheDispatcher;
        }

        /* JADX INFO: finally extract failed */
        public void onResponseReceived(Request<?> request, Response<?> response) {
            Request<?> request2 = request;
            Response<?> response2 = response;
            if (response2.cacheEntry == null || response2.cacheEntry.isExpired()) {
                onNoUsableResponseReceived(request2);
                return;
            }
            String cacheKey = request2.getCacheKey();
            synchronized (this) {
                try {
                    List<Request<?>> waitingRequests = this.mWaitingRequests.remove(cacheKey);
                    if (waitingRequests != null) {
                        if (VolleyLog.DEBUG) {
                            Object[] objArr = new Object[2];
                            objArr[0] = Integer.valueOf(waitingRequests.size());
                            Object[] objArr2 = objArr;
                            objArr2[1] = cacheKey;
                            VolleyLog.v("Releasing %d waiting requests for cacheKey=%s.", objArr2);
                        }
                        for (Request postResponse : waitingRequests) {
                            this.mCacheDispatcher.mDelivery.postResponse(postResponse, response2);
                        }
                    }
                } catch (Throwable th) {
                    while (true) {
                        Throwable th2 = th;
                        throw th2;
                    }
                }
            }
        }

        public synchronized void onNoUsableResponseReceived(Request<?> request) {
            Request<?> request2 = request;
            synchronized (this) {
                String cacheKey = request2.getCacheKey();
                List<Request<?>> waitingRequests = this.mWaitingRequests.remove(cacheKey);
                if (waitingRequests != null && !waitingRequests.isEmpty()) {
                    if (VolleyLog.DEBUG) {
                        Object[] objArr = new Object[2];
                        objArr[0] = Integer.valueOf(waitingRequests.size());
                        Object[] objArr2 = objArr;
                        objArr2[1] = cacheKey;
                        VolleyLog.v("%d waiting requests for cacheKey=%s; resend to network", objArr2);
                    }
                    Request<?> nextInLine = waitingRequests.remove(0);
                    List<Request<?>> put = this.mWaitingRequests.put(cacheKey, waitingRequests);
                    nextInLine.setNetworkRequestCompleteListener(this);
                    try {
                        this.mCacheDispatcher.mNetworkQueue.put(nextInLine);
                    } catch (InterruptedException e) {
                        VolleyLog.e("Couldn't add request to queue. %s", e.toString());
                        Thread.currentThread().interrupt();
                        this.mCacheDispatcher.quit();
                    }
                }
            }
            return;
        }

        /* access modifiers changed from: private */
        public synchronized boolean maybeAddToWaitingRequests(Request<?> request) {
            boolean z;
            List list;
            Request<?> request2 = request;
            synchronized (this) {
                String cacheKey = request2.getCacheKey();
                if (this.mWaitingRequests.containsKey(cacheKey)) {
                    List list2 = this.mWaitingRequests.get(cacheKey);
                    if (list2 == null) {
                        new ArrayList();
                        list2 = list;
                    }
                    request2.addMarker("waiting-for-response");
                    boolean add = list2.add(request2);
                    List<Request<?>> put = this.mWaitingRequests.put(cacheKey, list2);
                    if (VolleyLog.DEBUG) {
                        VolleyLog.d("Request for cacheKey=%s is in flight, putting on hold.", cacheKey);
                    }
                    z = true;
                } else {
                    List<Request<?>> put2 = this.mWaitingRequests.put(cacheKey, (Object) null);
                    request2.setNetworkRequestCompleteListener(this);
                    if (VolleyLog.DEBUG) {
                        VolleyLog.d("new request, sending to network %s", cacheKey);
                    }
                    z = false;
                }
            }
            return z;
        }
    }
}
