package yt.DeepHost.Custom_Design_ListView.volley;

public class TimeoutError extends VolleyError {
    public TimeoutError() {
    }
}
