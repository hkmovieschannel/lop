package yt.DeepHost.Custom_Design_ListView.volley.toolbox;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ByteArrayPool {
    protected static final Comparator<byte[]> BUF_COMPARATOR;
    private final List<byte[]> mBuffersByLastUse;
    private final List<byte[]> mBuffersBySize;
    private int mCurrentSize = 0;
    private final int mSizeLimit;

    static {
        Comparator<byte[]> comparator;
        new Comparator<byte[]>() {
            public int compare(byte[] lhs, byte[] rhs) {
                return lhs.length - rhs.length;
            }
        };
        BUF_COMPARATOR = comparator;
    }

    public ByteArrayPool(int sizeLimit) {
        List<byte[]> list;
        List<byte[]> list2;
        new ArrayList();
        this.mBuffersByLastUse = list;
        new ArrayList(64);
        this.mBuffersBySize = list2;
        this.mSizeLimit = sizeLimit;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:17:0x0045, code lost:
        r0 = new byte[r1];
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public synchronized byte[] getBuf(int r10) {
        /*
            r9 = this;
            r0 = r9
            r1 = r10
            r7 = r9
            monitor-enter(r7)
            r4 = 0
            r2 = r4
        L_0x0006:
            r4 = r2
            r5 = r0
            java.util.List<byte[]> r5 = r5.mBuffersBySize     // Catch:{ all -> 0x0047 }
            int r5 = r5.size()     // Catch:{ all -> 0x0047 }
            if (r4 >= r5) goto L_0x0042
            r4 = r0
            java.util.List<byte[]> r4 = r4.mBuffersBySize     // Catch:{ all -> 0x0047 }
            r5 = r2
            java.lang.Object r4 = r4.get(r5)     // Catch:{ all -> 0x0047 }
            byte[] r4 = (byte[]) r4     // Catch:{ all -> 0x0047 }
            r3 = r4
            r4 = r3
            int r4 = r4.length     // Catch:{ all -> 0x0047 }
            r5 = r1
            if (r4 < r5) goto L_0x003f
            r4 = r0
            r8 = r4
            r4 = r8
            r5 = r8
            int r5 = r5.mCurrentSize     // Catch:{ all -> 0x0047 }
            r6 = r3
            int r6 = r6.length     // Catch:{ all -> 0x0047 }
            int r5 = r5 - r6
            r4.mCurrentSize = r5     // Catch:{ all -> 0x0047 }
            r4 = r0
            java.util.List<byte[]> r4 = r4.mBuffersBySize     // Catch:{ all -> 0x0047 }
            r5 = r2
            java.lang.Object r4 = r4.remove(r5)     // Catch:{ all -> 0x0047 }
            r4 = r0
            java.util.List<byte[]> r4 = r4.mBuffersByLastUse     // Catch:{ all -> 0x0047 }
            r5 = r3
            boolean r4 = r4.remove(r5)     // Catch:{ all -> 0x0047 }
            r4 = r3
            r0 = r4
        L_0x003d:
            monitor-exit(r7)
            return r0
        L_0x003f:
            int r2 = r2 + 1
            goto L_0x0006
        L_0x0042:
            r4 = r1
            byte[] r4 = new byte[r4]     // Catch:{ all -> 0x0047 }
            r0 = r4
            goto L_0x003d
        L_0x0047:
            r0 = move-exception
            monitor-exit(r7)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: yt.DeepHost.Custom_Design_ListView.volley.toolbox.ByteArrayPool.getBuf(int):byte[]");
    }

    public synchronized void returnBuf(byte[] bArr) {
        byte[] buf = bArr;
        synchronized (this) {
            if (buf != null) {
                if (buf.length <= this.mSizeLimit) {
                    boolean add = this.mBuffersByLastUse.add(buf);
                    int pos = Collections.binarySearch(this.mBuffersBySize, buf, BUF_COMPARATOR);
                    if (pos < 0) {
                        pos = (-pos) - 1;
                    }
                    this.mBuffersBySize.add(pos, buf);
                    this.mCurrentSize += buf.length;
                    trim();
                }
            }
        }
    }

    private synchronized void trim() {
        synchronized (this) {
            while (this.mCurrentSize > this.mSizeLimit) {
                byte[] buf = this.mBuffersByLastUse.remove(0);
                boolean remove = this.mBuffersBySize.remove(buf);
                this.mCurrentSize -= buf.length;
            }
        }
    }
}
