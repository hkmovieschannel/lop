package yt.DeepHost.Custom_Design_ListView.volley.toolbox;

import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpEntityEnclosingRequestBase;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import yt.DeepHost.Custom_Design_ListView.volley.AuthFailureError;
import yt.DeepHost.Custom_Design_ListView.volley.Request;

@Deprecated
public class HttpClientStack implements HttpStack {
    private static final String HEADER_CONTENT_TYPE = "Content-Type";
    protected final HttpClient mClient;

    public HttpClientStack(HttpClient client) {
        this.mClient = client;
    }

    private static void setHeaders(HttpUriRequest httpUriRequest, Map<String, String> map) {
        HttpUriRequest httpRequest = httpUriRequest;
        Map<String, String> headers = map;
        for (String key : headers.keySet()) {
            httpRequest.setHeader(key, headers.get(key));
        }
    }

    private static List<NameValuePair> getPostParameterPairs(Map<String, String> map) {
        List<NameValuePair> list;
        Object obj;
        Map<String, String> postParams = map;
        new ArrayList(postParams.size());
        List<NameValuePair> result = list;
        for (String key : postParams.keySet()) {
            new BasicNameValuePair(key, postParams.get(key));
            boolean add = result.add(obj);
        }
        return result;
    }

    public HttpResponse performRequest(Request<?> request, Map<String, String> map) throws IOException, AuthFailureError {
        Request<?> request2 = request;
        Map<String, String> additionalHeaders = map;
        HttpUriRequest httpRequest = createHttpRequest(request2, additionalHeaders);
        setHeaders(httpRequest, additionalHeaders);
        setHeaders(httpRequest, request2.getHeaders());
        onPrepareRequest(httpRequest);
        HttpParams httpParams = httpRequest.getParams();
        int timeoutMs = request2.getTimeoutMs();
        HttpConnectionParams.setConnectionTimeout(httpParams, 5000);
        HttpConnectionParams.setSoTimeout(httpParams, timeoutMs);
        return this.mClient.execute(httpRequest);
    }

    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    static org.apache.http.client.methods.HttpUriRequest createHttpRequest(yt.DeepHost.Custom_Design_ListView.volley.Request<?> r9, java.util.Map<java.lang.String, java.lang.String> r10) throws yt.DeepHost.Custom_Design_ListView.volley.AuthFailureError {
        /*
            r0 = r9
            r1 = r10
            r5 = r0
            int r5 = r5.getMethod()
            switch(r5) {
                case -1: goto L_0x0016;
                case 0: goto L_0x005a;
                case 1: goto L_0x0078;
                case 2: goto L_0x009a;
                case 3: goto L_0x0069;
                case 4: goto L_0x00bc;
                case 5: goto L_0x00cb;
                case 6: goto L_0x00db;
                case 7: goto L_0x00eb;
                default: goto L_0x000a;
            }
        L_0x000a:
            java.lang.IllegalStateException r5 = new java.lang.IllegalStateException
            r8 = r5
            r5 = r8
            r6 = r8
            java.lang.String r7 = "Unknown request method."
            r6.<init>(r7)
            throw r5
        L_0x0016:
            r5 = r0
            byte[] r5 = r5.getPostBody()
            r2 = r5
            r5 = r2
            if (r5 == 0) goto L_0x004b
            org.apache.http.client.methods.HttpPost r5 = new org.apache.http.client.methods.HttpPost
            r8 = r5
            r5 = r8
            r6 = r8
            r7 = r0
            java.lang.String r7 = r7.getUrl()
            r6.<init>(r7)
            r3 = r5
            r5 = r3
            java.lang.String r6 = "Content-Type"
            r7 = r0
            java.lang.String r7 = r7.getPostBodyContentType()
            r5.addHeader(r6, r7)
            org.apache.http.entity.ByteArrayEntity r5 = new org.apache.http.entity.ByteArrayEntity
            r8 = r5
            r5 = r8
            r6 = r8
            r7 = r2
            r6.<init>(r7)
            r4 = r5
            r5 = r3
            r6 = r4
            r5.setEntity(r6)
            r5 = r3
            r0 = r5
        L_0x004a:
            return r0
        L_0x004b:
            org.apache.http.client.methods.HttpGet r5 = new org.apache.http.client.methods.HttpGet
            r8 = r5
            r5 = r8
            r6 = r8
            r7 = r0
            java.lang.String r7 = r7.getUrl()
            r6.<init>(r7)
            r0 = r5
            goto L_0x004a
        L_0x005a:
            org.apache.http.client.methods.HttpGet r5 = new org.apache.http.client.methods.HttpGet
            r8 = r5
            r5 = r8
            r6 = r8
            r7 = r0
            java.lang.String r7 = r7.getUrl()
            r6.<init>(r7)
            r0 = r5
            goto L_0x004a
        L_0x0069:
            org.apache.http.client.methods.HttpDelete r5 = new org.apache.http.client.methods.HttpDelete
            r8 = r5
            r5 = r8
            r6 = r8
            r7 = r0
            java.lang.String r7 = r7.getUrl()
            r6.<init>(r7)
            r0 = r5
            goto L_0x004a
        L_0x0078:
            org.apache.http.client.methods.HttpPost r5 = new org.apache.http.client.methods.HttpPost
            r8 = r5
            r5 = r8
            r6 = r8
            r7 = r0
            java.lang.String r7 = r7.getUrl()
            r6.<init>(r7)
            r2 = r5
            r5 = r2
            java.lang.String r6 = "Content-Type"
            r7 = r0
            java.lang.String r7 = r7.getBodyContentType()
            r5.addHeader(r6, r7)
            r5 = r2
            r6 = r0
            setEntityIfNonEmptyBody(r5, r6)
            r5 = r2
            r0 = r5
            goto L_0x004a
        L_0x009a:
            org.apache.http.client.methods.HttpPut r5 = new org.apache.http.client.methods.HttpPut
            r8 = r5
            r5 = r8
            r6 = r8
            r7 = r0
            java.lang.String r7 = r7.getUrl()
            r6.<init>(r7)
            r2 = r5
            r5 = r2
            java.lang.String r6 = "Content-Type"
            r7 = r0
            java.lang.String r7 = r7.getBodyContentType()
            r5.addHeader(r6, r7)
            r5 = r2
            r6 = r0
            setEntityIfNonEmptyBody(r5, r6)
            r5 = r2
            r0 = r5
            goto L_0x004a
        L_0x00bc:
            org.apache.http.client.methods.HttpHead r5 = new org.apache.http.client.methods.HttpHead
            r8 = r5
            r5 = r8
            r6 = r8
            r7 = r0
            java.lang.String r7 = r7.getUrl()
            r6.<init>(r7)
            r0 = r5
            goto L_0x004a
        L_0x00cb:
            org.apache.http.client.methods.HttpOptions r5 = new org.apache.http.client.methods.HttpOptions
            r8 = r5
            r5 = r8
            r6 = r8
            r7 = r0
            java.lang.String r7 = r7.getUrl()
            r6.<init>(r7)
            r0 = r5
            goto L_0x004a
        L_0x00db:
            org.apache.http.client.methods.HttpTrace r5 = new org.apache.http.client.methods.HttpTrace
            r8 = r5
            r5 = r8
            r6 = r8
            r7 = r0
            java.lang.String r7 = r7.getUrl()
            r6.<init>(r7)
            r0 = r5
            goto L_0x004a
        L_0x00eb:
            yt.DeepHost.Custom_Design_ListView.volley.toolbox.HttpClientStack$HttpPatch r5 = new yt.DeepHost.Custom_Design_ListView.volley.toolbox.HttpClientStack$HttpPatch
            r8 = r5
            r5 = r8
            r6 = r8
            r7 = r0
            java.lang.String r7 = r7.getUrl()
            r6.<init>((java.lang.String) r7)
            r2 = r5
            r5 = r2
            java.lang.String r6 = "Content-Type"
            r7 = r0
            java.lang.String r7 = r7.getBodyContentType()
            r5.addHeader(r6, r7)
            r5 = r2
            r6 = r0
            setEntityIfNonEmptyBody(r5, r6)
            r5 = r2
            r0 = r5
            goto L_0x004a
        */
        throw new UnsupportedOperationException("Method not decompiled: yt.DeepHost.Custom_Design_ListView.volley.toolbox.HttpClientStack.createHttpRequest(yt.DeepHost.Custom_Design_ListView.volley.Request, java.util.Map):org.apache.http.client.methods.HttpUriRequest");
    }

    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private static void setEntityIfNonEmptyBody(org.apache.http.client.methods.HttpEntityEnclosingRequestBase r8, yt.DeepHost.Custom_Design_ListView.volley.Request<?> r9) throws yt.DeepHost.Custom_Design_ListView.volley.AuthFailureError {
        /*
            r0 = r8
            r1 = r9
            r4 = r1
            byte[] r4 = r4.getBody()
            r2 = r4
            r4 = r2
            if (r4 == 0) goto L_0x001a
            org.apache.http.entity.ByteArrayEntity r4 = new org.apache.http.entity.ByteArrayEntity
            r7 = r4
            r4 = r7
            r5 = r7
            r6 = r2
            r5.<init>(r6)
            r3 = r4
            r4 = r0
            r5 = r3
            r4.setEntity(r5)
        L_0x001a:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: yt.DeepHost.Custom_Design_ListView.volley.toolbox.HttpClientStack.setEntityIfNonEmptyBody(org.apache.http.client.methods.HttpEntityEnclosingRequestBase, yt.DeepHost.Custom_Design_ListView.volley.Request):void");
    }

    /* access modifiers changed from: protected */
    public void onPrepareRequest(HttpUriRequest request) throws IOException {
    }

    public static final class HttpPatch extends HttpEntityEnclosingRequestBase {
        public static final String METHOD_NAME = "PATCH";

        public HttpPatch() {
        }

        public HttpPatch(URI uri) {
            setURI(uri);
        }

        public HttpPatch(String uri) {
            setURI(URI.create(uri));
        }

        public String getMethod() {
            return METHOD_NAME;
        }
    }
}
