package yt.DeepHost.Custom_Design_ListView.volley.toolbox;

import java.io.IOException;
import java.util.Map;
import org.apache.http.HttpResponse;
import yt.DeepHost.Custom_Design_ListView.volley.AuthFailureError;
import yt.DeepHost.Custom_Design_ListView.volley.Request;

@Deprecated
public interface HttpStack {
    HttpResponse performRequest(Request<?> request, Map<String, String> map) throws IOException, AuthFailureError;
}
