package yt.DeepHost.Custom_Design_ListView.volley.toolbox;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class PoolingByteArrayOutputStream extends ByteArrayOutputStream {
    private static final int DEFAULT_SIZE = 256;
    private final ByteArrayPool mPool;

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public PoolingByteArrayOutputStream(ByteArrayPool pool) {
        this(pool, 256);
    }

    public PoolingByteArrayOutputStream(ByteArrayPool pool, int size) {
        this.mPool = pool;
        this.buf = this.mPool.getBuf(Math.max(size, 256));
    }

    public void close() throws IOException {
        this.mPool.returnBuf(this.buf);
        this.buf = null;
        super.close();
    }

    public void finalize() {
        this.mPool.returnBuf(this.buf);
    }

    private void expand(int i) {
        int i2 = i;
        if (this.count + i2 > this.buf.length) {
            byte[] newbuf = this.mPool.getBuf((this.count + i2) * 2);
            System.arraycopy(this.buf, 0, newbuf, 0, this.count);
            this.mPool.returnBuf(this.buf);
            this.buf = newbuf;
        }
    }

    public synchronized void write(byte[] bArr, int i, int i2) {
        byte[] buffer = bArr;
        int offset = i;
        int len = i2;
        synchronized (this) {
            expand(len);
            super.write(buffer, offset, len);
        }
    }

    public synchronized void write(int i) {
        int oneByte = i;
        synchronized (this) {
            expand(1);
            super.write(oneByte);
        }
    }
}
