package yt.DeepHost.Custom_Design_ListView.volley.toolbox;

import java.io.IOException;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.apache.http.HttpResponse;
import org.apache.http.conn.ConnectTimeoutException;
import yt.DeepHost.Custom_Design_ListView.volley.AuthFailureError;
import yt.DeepHost.Custom_Design_ListView.volley.Header;
import yt.DeepHost.Custom_Design_ListView.volley.Request;

class AdaptedHttpStack extends BaseHttpStack {
    private final HttpStack mHttpStack;

    AdaptedHttpStack(HttpStack httpStack) {
        this.mHttpStack = httpStack;
    }

    public HttpResponse executeRequest(Request<?> request, Map<String, String> additionalHeaders) throws IOException, AuthFailureError {
        Throwable th;
        List<Header> list;
        HttpResponse httpResponse;
        Throwable th2;
        StringBuilder sb;
        HttpResponse httpResponse2;
        Object obj;
        try {
            HttpResponse apacheResp = this.mHttpStack.performRequest(request, additionalHeaders);
            int statusCode = apacheResp.getStatusLine().getStatusCode();
            org.apache.http.Header[] headers = apacheResp.getAllHeaders();
            new ArrayList<>(headers.length);
            List<Header> headerList = list;
            org.apache.http.Header[] headerArr = headers;
            int length = headerArr.length;
            for (int i = 0; i < length; i++) {
                org.apache.http.Header header = headerArr[i];
                new Header(header.getName(), header.getValue());
                boolean add = headerList.add(obj);
            }
            if (apacheResp.getEntity() == null) {
                new HttpResponse(statusCode, headerList);
                return httpResponse2;
            }
            long contentLength = apacheResp.getEntity().getContentLength();
            if (((long) ((int) contentLength)) != contentLength) {
                Throwable th3 = th2;
                new StringBuilder();
                new IOException(sb.append("Response too large: ").append(contentLength).toString());
                throw th3;
            }
            new HttpResponse(statusCode, headerList, (int) apacheResp.getEntity().getContentLength(), apacheResp.getEntity().getContent());
            return httpResponse;
        } catch (ConnectTimeoutException e) {
            ConnectTimeoutException e2 = e;
            Throwable th4 = th;
            new SocketTimeoutException(e2.getMessage());
            throw th4;
        }
    }
}
