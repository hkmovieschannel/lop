package yt.DeepHost.Custom_Design_ListView.volley.toolbox;

import android.os.SystemClock;
import android.text.TextUtils;
import androidx.annotation.VisibleForTesting;
import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import yt.DeepHost.Custom_Design_ListView.volley.Cache;
import yt.DeepHost.Custom_Design_ListView.volley.Header;
import yt.DeepHost.Custom_Design_ListView.volley.VolleyLog;

public class DiskBasedCache implements Cache {
    private static final int CACHE_MAGIC = 538247942;
    private static final int DEFAULT_DISK_USAGE_BYTES = 5242880;
    @VisibleForTesting
    static final float HYSTERESIS_FACTOR = 0.9f;
    private final Map<String, CacheHeader> mEntries;
    private final int mMaxCacheSizeInBytes;
    private final FileSupplier mRootDirectorySupplier;
    private long mTotalSize;

    public interface FileSupplier {
        File get();
    }

    public DiskBasedCache(File rootDirectory, int maxCacheSizeInBytes) {
        Map<String, CacheHeader> map;
        FileSupplier fileSupplier;
        new LinkedHashMap(16, 0.75f, true);
        this.mEntries = map;
        this.mTotalSize = 0;
        final File file = rootDirectory;
        new FileSupplier(this) {
            final /* synthetic */ DiskBasedCache this$0;

            {
                this.this$0 = this$0;
            }

            public File get() {
                return file;
            }
        };
        this.mRootDirectorySupplier = fileSupplier;
        this.mMaxCacheSizeInBytes = maxCacheSizeInBytes;
    }

    public DiskBasedCache(FileSupplier rootDirectorySupplier, int maxCacheSizeInBytes) {
        Map<String, CacheHeader> map;
        new LinkedHashMap(16, 0.75f, true);
        this.mEntries = map;
        this.mTotalSize = 0;
        this.mRootDirectorySupplier = rootDirectorySupplier;
        this.mMaxCacheSizeInBytes = maxCacheSizeInBytes;
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public DiskBasedCache(File rootDirectory) {
        this(rootDirectory, (int) DEFAULT_DISK_USAGE_BYTES);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public DiskBasedCache(FileSupplier rootDirectorySupplier) {
        this(rootDirectorySupplier, (int) DEFAULT_DISK_USAGE_BYTES);
    }

    public synchronized void clear() {
        synchronized (this) {
            File[] files = this.mRootDirectorySupplier.get().listFiles();
            if (files != null) {
                File[] fileArr = files;
                int length = fileArr.length;
                for (int i = 0; i < length; i++) {
                    boolean delete = fileArr[i].delete();
                }
            }
            this.mEntries.clear();
            this.mTotalSize = 0;
            VolleyLog.d("Cache cleared.", new Object[0]);
        }
    }

    public synchronized Cache.Entry get(String str) {
        Cache.Entry entry;
        CountingInputStream countingInputStream;
        InputStream inputStream;
        CountingInputStream cis;
        String key = str;
        synchronized (this) {
            CacheHeader entry2 = this.mEntries.get(key);
            if (entry2 == null) {
                entry = null;
            } else {
                File file = getFileForKey(key);
                try {
                    CountingInputStream countingInputStream2 = countingInputStream;
                    new BufferedInputStream(createInputStream(file));
                    new CountingInputStream(inputStream, file.length());
                    cis = countingInputStream2;
                    CacheHeader entryOnDisk = CacheHeader.readHeader(cis);
                    if (!TextUtils.equals(key, entryOnDisk.key)) {
                        Object[] objArr = new Object[3];
                        objArr[0] = file.getAbsolutePath();
                        Object[] objArr2 = objArr;
                        objArr2[1] = key;
                        Object[] objArr3 = objArr2;
                        objArr3[2] = entryOnDisk.key;
                        VolleyLog.d("%s: key=%s, found=%s", objArr3);
                        removeEntry(key);
                        cis.close();
                        entry = null;
                    } else {
                        Cache.Entry cacheEntry = entry2.toCacheEntry(streamToBytes(cis, cis.bytesRemaining()));
                        cis.close();
                        entry = cacheEntry;
                    }
                } catch (IOException e) {
                    IOException e2 = e;
                    Object[] objArr4 = new Object[2];
                    objArr4[0] = file.getAbsolutePath();
                    Object[] objArr5 = objArr4;
                    objArr5[1] = e2.toString();
                    VolleyLog.d("%s: %s", objArr5);
                    remove(key);
                    entry = null;
                } catch (Throwable th) {
                    Throwable th2 = th;
                    cis.close();
                    throw th2;
                }
            }
        }
        return entry;
    }

    public synchronized void initialize() {
        CountingInputStream countingInputStream;
        InputStream inputStream;
        CountingInputStream cis;
        synchronized (this) {
            File rootDirectory = this.mRootDirectorySupplier.get();
            if (rootDirectory.exists()) {
                File[] files = rootDirectory.listFiles();
                if (files != null) {
                    File[] fileArr = files;
                    int length = fileArr.length;
                    for (int i = 0; i < length; i++) {
                        File file = fileArr[i];
                        try {
                            long entrySize = file.length();
                            CountingInputStream countingInputStream2 = countingInputStream;
                            new BufferedInputStream(createInputStream(file));
                            new CountingInputStream(inputStream, entrySize);
                            cis = countingInputStream2;
                            CacheHeader entry = CacheHeader.readHeader(cis);
                            entry.size = entrySize;
                            putEntry(entry.key, entry);
                            cis.close();
                        } catch (IOException e) {
                            IOException iOException = e;
                            boolean delete = file.delete();
                        } catch (Throwable th) {
                            Throwable th2 = th;
                            cis.close();
                            throw th2;
                        }
                    }
                }
            } else if (!rootDirectory.mkdirs()) {
                VolleyLog.e("Unable to create cache dir %s", rootDirectory.getAbsolutePath());
            }
        }
    }

    public synchronized void invalidate(String str, boolean z) {
        String key = str;
        boolean fullExpire = z;
        synchronized (this) {
            Cache.Entry entry = get(key);
            if (entry != null) {
                entry.softTtl = 0;
                if (fullExpire) {
                    entry.ttl = 0;
                }
                put(key, entry);
            }
        }
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v2, resolved type: java.io.OutputStream} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v18, resolved type: java.io.BufferedOutputStream} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v19, resolved type: java.io.BufferedOutputStream} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v23, resolved type: java.io.BufferedOutputStream} */
    /* JADX WARNING: Code restructure failed: missing block: B:8:0x0027, code lost:
        if (((float) r3.data.length) > (((float) r1.mMaxCacheSizeInBytes) * HYSTERESIS_FACTOR)) goto L_0x0029;
     */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public synchronized void put(java.lang.String r16, yt.DeepHost.Custom_Design_ListView.volley.Cache.Entry r17) {
        /*
            r15 = this;
            r1 = r15
            r2 = r16
            r3 = r17
            r13 = r15
            monitor-enter(r13)
            r8 = r1
            long r8 = r8.mTotalSize     // Catch:{ all -> 0x00b6 }
            r10 = r3
            byte[] r10 = r10.data     // Catch:{ all -> 0x00b6 }
            int r10 = r10.length     // Catch:{ all -> 0x00b6 }
            long r10 = (long) r10     // Catch:{ all -> 0x00b6 }
            long r8 = r8 + r10
            r10 = r1
            int r10 = r10.mMaxCacheSizeInBytes     // Catch:{ all -> 0x00b6 }
            long r10 = (long) r10     // Catch:{ all -> 0x00b6 }
            int r8 = (r8 > r10 ? 1 : (r8 == r10 ? 0 : -1))
            if (r8 <= 0) goto L_0x002b
            r8 = r3
            byte[] r8 = r8.data     // Catch:{ all -> 0x00b6 }
            int r8 = r8.length     // Catch:{ all -> 0x00b6 }
            float r8 = (float) r8     // Catch:{ all -> 0x00b6 }
            r9 = r1
            int r9 = r9.mMaxCacheSizeInBytes     // Catch:{ all -> 0x00b6 }
            float r9 = (float) r9
            r10 = 1063675494(0x3f666666, float:0.9)
            float r9 = r9 * r10
            int r8 = (r8 > r9 ? 1 : (r8 == r9 ? 0 : -1))
            if (r8 <= 0) goto L_0x002b
        L_0x0029:
            monitor-exit(r13)
            return
        L_0x002b:
            r8 = r1
            r9 = r2
            java.io.File r8 = r8.getFileForKey(r9)     // Catch:{ all -> 0x00b6 }
            r4 = r8
            java.io.BufferedOutputStream r8 = new java.io.BufferedOutputStream     // Catch:{ IOException -> 0x0077 }
            r14 = r8
            r8 = r14
            r9 = r14
            r10 = r1
            r11 = r4
            java.io.OutputStream r10 = r10.createOutputStream(r11)     // Catch:{ IOException -> 0x0077 }
            r9.<init>(r10)     // Catch:{ IOException -> 0x0077 }
            r5 = r8
            yt.DeepHost.Custom_Design_ListView.volley.toolbox.DiskBasedCache$CacheHeader r8 = new yt.DeepHost.Custom_Design_ListView.volley.toolbox.DiskBasedCache$CacheHeader     // Catch:{ IOException -> 0x0077 }
            r14 = r8
            r8 = r14
            r9 = r14
            r10 = r2
            r11 = r3
            r9.<init>(r10, r11)     // Catch:{ IOException -> 0x0077 }
            r6 = r8
            r8 = r6
            r9 = r5
            boolean r8 = r8.writeHeader(r9)     // Catch:{ IOException -> 0x0077 }
            r7 = r8
            r8 = r7
            if (r8 != 0) goto L_0x0097
            r8 = r5
            r8.close()     // Catch:{ IOException -> 0x0077 }
            java.lang.String r8 = "Failed to write header for %s"
            r9 = 1
            java.lang.Object[] r9 = new java.lang.Object[r9]     // Catch:{ IOException -> 0x0077 }
            r14 = r9
            r9 = r14
            r10 = r14
            r11 = 0
            r12 = r4
            java.lang.String r12 = r12.getAbsolutePath()     // Catch:{ IOException -> 0x0077 }
            r10[r11] = r12     // Catch:{ IOException -> 0x0077 }
            yt.DeepHost.Custom_Design_ListView.volley.VolleyLog.d(r8, r9)     // Catch:{ IOException -> 0x0077 }
            java.io.IOException r8 = new java.io.IOException     // Catch:{ IOException -> 0x0077 }
            r14 = r8
            r8 = r14
            r9 = r14
            r9.<init>()     // Catch:{ IOException -> 0x0077 }
            throw r8     // Catch:{ IOException -> 0x0077 }
        L_0x0077:
            r8 = move-exception
            r5 = r8
            r8 = r4
            boolean r8 = r8.delete()     // Catch:{ all -> 0x00b6 }
            r5 = r8
            r8 = r5
            if (r8 != 0) goto L_0x0096
            java.lang.String r8 = "Could not clean up file %s"
            r9 = 1
            java.lang.Object[] r9 = new java.lang.Object[r9]     // Catch:{ all -> 0x00b6 }
            r14 = r9
            r9 = r14
            r10 = r14
            r11 = 0
            r12 = r4
            java.lang.String r12 = r12.getAbsolutePath()     // Catch:{ all -> 0x00b6 }
            r10[r11] = r12     // Catch:{ all -> 0x00b6 }
            yt.DeepHost.Custom_Design_ListView.volley.VolleyLog.d(r8, r9)     // Catch:{ all -> 0x00b6 }
        L_0x0096:
            goto L_0x0029
        L_0x0097:
            r8 = r5
            r9 = r3
            byte[] r9 = r9.data     // Catch:{ IOException -> 0x0077 }
            r8.write(r9)     // Catch:{ IOException -> 0x0077 }
            r8 = r5
            r8.close()     // Catch:{ IOException -> 0x0077 }
            r8 = r6
            r9 = r4
            long r9 = r9.length()     // Catch:{ IOException -> 0x0077 }
            r8.size = r9     // Catch:{ IOException -> 0x0077 }
            r8 = r1
            r9 = r2
            r10 = r6
            r8.putEntry(r9, r10)     // Catch:{ IOException -> 0x0077 }
            r8 = r1
            r8.pruneIfNeeded()     // Catch:{ IOException -> 0x0077 }
            goto L_0x0029
        L_0x00b6:
            r1 = move-exception
            monitor-exit(r13)
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: yt.DeepHost.Custom_Design_ListView.volley.toolbox.DiskBasedCache.put(java.lang.String, yt.DeepHost.Custom_Design_ListView.volley.Cache$Entry):void");
    }

    public synchronized void remove(String str) {
        String key = str;
        synchronized (this) {
            boolean deleted = getFileForKey(key).delete();
            removeEntry(key);
            if (!deleted) {
                Object[] objArr = new Object[2];
                objArr[0] = key;
                Object[] objArr2 = objArr;
                objArr2[1] = getFilenameForKey(key);
                VolleyLog.d("Could not delete cache entry for key=%s, filename=%s", objArr2);
            }
        }
    }

    private String getFilenameForKey(String str) {
        StringBuilder sb;
        String key = str;
        int firstHalfLength = key.length() / 2;
        String localFilename = String.valueOf(key.substring(0, firstHalfLength).hashCode());
        new StringBuilder();
        return sb.append(localFilename).append(String.valueOf(key.substring(firstHalfLength).hashCode())).toString();
    }

    public File getFileForKey(String key) {
        File file;
        new File(this.mRootDirectorySupplier.get(), getFilenameForKey(key));
        return file;
    }

    private void pruneIfNeeded() {
        if (this.mTotalSize >= ((long) this.mMaxCacheSizeInBytes)) {
            if (VolleyLog.DEBUG) {
                VolleyLog.v("Pruning old cache entries.", new Object[0]);
            }
            long before = this.mTotalSize;
            int prunedFiles = 0;
            long startTime = SystemClock.elapsedRealtime();
            Iterator<Map.Entry<String, CacheHeader>> iterator = this.mEntries.entrySet().iterator();
            while (iterator.hasNext()) {
                CacheHeader e = (CacheHeader) iterator.next().getValue();
                if (getFileForKey(e.key).delete()) {
                    this.mTotalSize -= e.size;
                } else {
                    Object[] objArr = new Object[2];
                    objArr[0] = e.key;
                    Object[] objArr2 = objArr;
                    objArr2[1] = getFilenameForKey(e.key);
                    VolleyLog.d("Could not delete cache entry for key=%s, filename=%s", objArr2);
                }
                iterator.remove();
                prunedFiles++;
                if (((float) this.mTotalSize) < ((float) this.mMaxCacheSizeInBytes) * HYSTERESIS_FACTOR) {
                    break;
                }
            }
            if (VolleyLog.DEBUG) {
                Object[] objArr3 = new Object[3];
                objArr3[0] = Integer.valueOf(prunedFiles);
                Object[] objArr4 = objArr3;
                objArr4[1] = Long.valueOf(this.mTotalSize - before);
                Object[] objArr5 = objArr4;
                objArr5[2] = Long.valueOf(SystemClock.elapsedRealtime() - startTime);
                VolleyLog.v("pruned %d files, %d bytes, %d ms", objArr5);
            }
        }
    }

    private void putEntry(String str, CacheHeader cacheHeader) {
        String key = str;
        CacheHeader entry = cacheHeader;
        if (!this.mEntries.containsKey(key)) {
            this.mTotalSize += entry.size;
        } else {
            this.mTotalSize += entry.size - this.mEntries.get(key).size;
        }
        CacheHeader put = this.mEntries.put(key, entry);
    }

    private void removeEntry(String key) {
        CacheHeader removed = this.mEntries.remove(key);
        if (removed != null) {
            this.mTotalSize -= removed.size;
        }
    }

    @VisibleForTesting
    static byte[] streamToBytes(CountingInputStream countingInputStream, long j) throws IOException {
        Throwable th;
        StringBuilder sb;
        DataInputStream dataInputStream;
        CountingInputStream cis = countingInputStream;
        long length = j;
        long maxLength = cis.bytesRemaining();
        if (length < 0 || length > maxLength || ((long) ((int) length)) != length) {
            Throwable th2 = th;
            new StringBuilder();
            new IOException(sb.append("streamToBytes length=").append(length).append(", maxLength=").append(maxLength).toString());
            throw th2;
        }
        byte[] bytes = new byte[((int) length)];
        new DataInputStream(cis);
        dataInputStream.readFully(bytes);
        return bytes;
    }

    /* access modifiers changed from: package-private */
    @VisibleForTesting
    public InputStream createInputStream(File file) throws FileNotFoundException {
        InputStream inputStream;
        new FileInputStream(file);
        return inputStream;
    }

    /* access modifiers changed from: package-private */
    @VisibleForTesting
    public OutputStream createOutputStream(File file) throws FileNotFoundException {
        OutputStream outputStream;
        new FileOutputStream(file);
        return outputStream;
    }

    @VisibleForTesting
    static class CacheHeader {
        final List<Header> allResponseHeaders;
        final String etag;
        final String key;
        final long lastModified;
        final long serverDate;
        long size;
        final long softTtl;
        final long ttl;

        private CacheHeader(String key2, String str, long j, long j2, long j3, long j4, List<Header> list) {
            String etag2 = str;
            long serverDate2 = j;
            long lastModified2 = j2;
            long ttl2 = j3;
            long softTtl2 = j4;
            List<Header> allResponseHeaders2 = list;
            this.key = key2;
            this.etag = "".equals(etag2) ? null : etag2;
            this.serverDate = serverDate2;
            this.lastModified = lastModified2;
            this.ttl = ttl2;
            this.softTtl = softTtl2;
            this.allResponseHeaders = allResponseHeaders2;
        }

        /* JADX WARNING: Illegal instructions before constructor call */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        CacheHeader(java.lang.String r16, yt.DeepHost.Custom_Design_ListView.volley.Cache.Entry r17) {
            /*
                r15 = this;
                r0 = r15
                r1 = r16
                r2 = r17
                r3 = r0
                r4 = r1
                r5 = r2
                java.lang.String r5 = r5.etag
                r6 = r2
                long r6 = r6.serverDate
                r8 = r2
                long r8 = r8.lastModified
                r10 = r2
                long r10 = r10.ttl
                r12 = r2
                long r12 = r12.softTtl
                r14 = r2
                java.util.List r14 = getAllResponseHeaders(r14)
                r3.<init>(r4, r5, r6, r8, r10, r12, r14)
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: yt.DeepHost.Custom_Design_ListView.volley.toolbox.DiskBasedCache.CacheHeader.<init>(java.lang.String, yt.DeepHost.Custom_Design_ListView.volley.Cache$Entry):void");
        }

        private static List<Header> getAllResponseHeaders(Cache.Entry entry) {
            Cache.Entry entry2 = entry;
            if (entry2.allResponseHeaders != null) {
                return entry2.allResponseHeaders;
            }
            return HttpHeaderParser.toAllHeaderList(entry2.responseHeaders);
        }

        static CacheHeader readHeader(CountingInputStream countingInputStream) throws IOException {
            CacheHeader cacheHeader;
            Throwable th;
            CountingInputStream is = countingInputStream;
            if (DiskBasedCache.readInt(is) != DiskBasedCache.CACHE_MAGIC) {
                Throwable th2 = th;
                new IOException();
                throw th2;
            }
            new CacheHeader(DiskBasedCache.readString(is), DiskBasedCache.readString(is), DiskBasedCache.readLong(is), DiskBasedCache.readLong(is), DiskBasedCache.readLong(is), DiskBasedCache.readLong(is), DiskBasedCache.readHeaderList(is));
            return cacheHeader;
        }

        /* access modifiers changed from: package-private */
        public Cache.Entry toCacheEntry(byte[] data) {
            Cache.Entry entry;
            new Cache.Entry();
            Cache.Entry e = entry;
            e.data = data;
            e.etag = this.etag;
            e.serverDate = this.serverDate;
            e.lastModified = this.lastModified;
            e.ttl = this.ttl;
            e.softTtl = this.softTtl;
            e.responseHeaders = HttpHeaderParser.toHeaderMap(this.allResponseHeaders);
            e.allResponseHeaders = Collections.unmodifiableList(this.allResponseHeaders);
            return e;
        }

        /* access modifiers changed from: package-private */
        public boolean writeHeader(OutputStream outputStream) {
            OutputStream os = outputStream;
            try {
                DiskBasedCache.writeInt(os, DiskBasedCache.CACHE_MAGIC);
                DiskBasedCache.writeString(os, this.key);
                DiskBasedCache.writeString(os, this.etag == null ? "" : this.etag);
                DiskBasedCache.writeLong(os, this.serverDate);
                DiskBasedCache.writeLong(os, this.lastModified);
                DiskBasedCache.writeLong(os, this.ttl);
                DiskBasedCache.writeLong(os, this.softTtl);
                DiskBasedCache.writeHeaderList(this.allResponseHeaders, os);
                os.flush();
                return true;
            } catch (IOException e) {
                VolleyLog.d("%s", e.toString());
                return false;
            }
        }
    }

    @VisibleForTesting
    static class CountingInputStream extends FilterInputStream {
        private long bytesRead;
        private final long length;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        CountingInputStream(InputStream in, long length2) {
            super(in);
            this.length = length2;
        }

        public int read() throws IOException {
            int result = super.read();
            if (result != -1) {
                this.bytesRead++;
            }
            return result;
        }

        public int read(byte[] buffer, int offset, int count) throws IOException {
            int result = super.read(buffer, offset, count);
            if (result != -1) {
                this.bytesRead += (long) result;
            }
            return result;
        }

        /* access modifiers changed from: package-private */
        @VisibleForTesting
        public long bytesRead() {
            return this.bytesRead;
        }

        /* access modifiers changed from: package-private */
        public long bytesRemaining() {
            return this.length - this.bytesRead;
        }
    }

    private static int read(InputStream is) throws IOException {
        Throwable th;
        int b = is.read();
        if (b != -1) {
            return b;
        }
        Throwable th2 = th;
        new EOFException();
        throw th2;
    }

    static void writeInt(OutputStream outputStream, int i) throws IOException {
        OutputStream os = outputStream;
        int n = i;
        os.write((n >> 0) & 255);
        os.write((n >> 8) & 255);
        os.write((n >> 16) & 255);
        os.write((n >> 24) & 255);
    }

    static int readInt(InputStream inputStream) throws IOException {
        InputStream is = inputStream;
        return 0 | (read(is) << 0) | (read(is) << 8) | (read(is) << 16) | (read(is) << 24);
    }

    static void writeLong(OutputStream outputStream, long j) throws IOException {
        OutputStream os = outputStream;
        long n = j;
        os.write((byte) ((int) (n >>> 0)));
        os.write((byte) ((int) (n >>> 8)));
        os.write((byte) ((int) (n >>> 16)));
        os.write((byte) ((int) (n >>> 24)));
        os.write((byte) ((int) (n >>> 32)));
        os.write((byte) ((int) (n >>> 40)));
        os.write((byte) ((int) (n >>> 48)));
        os.write((byte) ((int) (n >>> 56)));
    }

    static long readLong(InputStream inputStream) throws IOException {
        InputStream is = inputStream;
        return 0 | ((((long) read(is)) & 255) << 0) | ((((long) read(is)) & 255) << 8) | ((((long) read(is)) & 255) << 16) | ((((long) read(is)) & 255) << 24) | ((((long) read(is)) & 255) << 32) | ((((long) read(is)) & 255) << 40) | ((((long) read(is)) & 255) << 48) | ((((long) read(is)) & 255) << 56);
    }

    static void writeString(OutputStream outputStream, String s) throws IOException {
        OutputStream os = outputStream;
        byte[] b = s.getBytes("UTF-8");
        writeLong(os, (long) b.length);
        os.write(b, 0, b.length);
    }

    static String readString(CountingInputStream countingInputStream) throws IOException {
        String str;
        CountingInputStream cis = countingInputStream;
        new String(streamToBytes(cis, readLong(cis)), "UTF-8");
        return str;
    }

    static void writeHeaderList(List<Header> list, OutputStream outputStream) throws IOException {
        List<Header> headers = list;
        OutputStream os = outputStream;
        if (headers != null) {
            writeInt(os, headers.size());
            for (Header header : headers) {
                writeString(os, header.getName());
                writeString(os, header.getValue());
            }
            return;
        }
        writeInt(os, 0);
    }

    static List<Header> readHeaderList(CountingInputStream countingInputStream) throws IOException {
        List<Header> list;
        List<Header> list2;
        Object obj;
        Throwable th;
        StringBuilder sb;
        CountingInputStream cis = countingInputStream;
        int size = readInt(cis);
        if (size < 0) {
            Throwable th2 = th;
            new StringBuilder();
            new IOException(sb.append("readHeaderList size=").append(size).toString());
            throw th2;
        }
        if (size == 0) {
            list2 = Collections.emptyList();
        } else {
            list2 = list;
            new ArrayList();
        }
        List<Header> result = list2;
        for (int i = 0; i < size; i++) {
            new Header(readString(cis).intern(), readString(cis).intern());
            boolean add = result.add(obj);
        }
        return result;
    }
}
