package yt.DeepHost.Custom_Design_ListView.volley.toolbox;

import androidx.annotation.GuardedBy;
import androidx.annotation.Nullable;
import java.io.UnsupportedEncodingException;
import yt.DeepHost.Custom_Design_ListView.volley.NetworkResponse;
import yt.DeepHost.Custom_Design_ListView.volley.Request;
import yt.DeepHost.Custom_Design_ListView.volley.Response;

public class StringRequest extends Request<String> {
    @GuardedBy("mLock")
    @Nullable
    private Response.Listener<String> mListener;
    private final Object mLock;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public StringRequest(int method, String url, Response.Listener<String> listener, @Nullable Response.ErrorListener errorListener) {
        super(method, url, errorListener);
        Object obj;
        new Object();
        this.mLock = obj;
        this.mListener = listener;
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public StringRequest(String url, Response.Listener<String> listener, @Nullable Response.ErrorListener errorListener) {
        this(0, url, listener, errorListener);
    }

    public void cancel() {
        super.cancel();
        Object obj = this.mLock;
        Object obj2 = obj;
        synchronized (obj) {
            try {
                this.mListener = null;
            } catch (Throwable th) {
                Throwable th2 = th;
                Object obj3 = obj2;
                throw th2;
            }
        }
    }

    /* JADX INFO: finally extract failed */
    /* access modifiers changed from: protected */
    public void deliverResponse(String str) {
        String response = str;
        Object obj = this.mLock;
        Object obj2 = obj;
        synchronized (obj) {
            try {
                Response.Listener<String> listener = this.mListener;
                if (listener != null) {
                    listener.onResponse(response);
                }
            } catch (Throwable th) {
                while (true) {
                    Throwable th2 = th;
                    Object obj3 = obj2;
                    throw th2;
                }
            }
        }
    }

    /* access modifiers changed from: protected */
    public Response<String> parseNetworkResponse(NetworkResponse networkResponse) {
        Object obj;
        Object obj2;
        Object obj3;
        NetworkResponse response = networkResponse;
        try {
            Object obj4 = obj3;
            new String(response.data, HttpHeaderParser.parseCharset(response.headers));
            obj2 = obj4;
        } catch (UnsupportedEncodingException e) {
            UnsupportedEncodingException unsupportedEncodingException = e;
            new String(response.data);
            obj2 = obj;
        }
        return Response.success(obj2, HttpHeaderParser.parseCacheHeaders(response));
    }
}
