package yt.DeepHost.Custom_Design_ListView.volley.toolbox;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import java.util.TreeMap;
import yt.DeepHost.Custom_Design_ListView.volley.Cache;
import yt.DeepHost.Custom_Design_ListView.volley.Header;
import yt.DeepHost.Custom_Design_ListView.volley.NetworkResponse;
import yt.DeepHost.Custom_Design_ListView.volley.VolleyLog;

public class HttpHeaderParser {
    private static final String DEFAULT_CONTENT_CHARSET = "ISO-8859-1";
    static final String HEADER_CONTENT_TYPE = "Content-Type";
    private static final String RFC1123_FORMAT = "EEE, dd MMM yyyy HH:mm:ss zzz";

    public HttpHeaderParser() {
    }

    public static Cache.Entry parseCacheHeaders(NetworkResponse networkResponse) {
        Cache.Entry entry;
        NetworkResponse response = networkResponse;
        long now = System.currentTimeMillis();
        Map<String, String> headers = response.headers;
        long serverDate = 0;
        long lastModified = 0;
        long serverExpires = 0;
        long softExpire = 0;
        long finalExpire = 0;
        long maxAge = 0;
        long staleWhileRevalidate = 0;
        boolean hasCacheControl = false;
        boolean mustRevalidate = false;
        String headerValue = headers.get("Date");
        if (headerValue != null) {
            serverDate = parseDateAsEpoch(headerValue);
        }
        String headerValue2 = headers.get("Cache-Control");
        if (headerValue2 != null) {
            hasCacheControl = true;
            String[] tokens = headerValue2.split(",", 0);
            for (int i = 0; i < tokens.length; i++) {
                String token = tokens[i].trim();
                if (token.equals("no-cache") || token.equals("no-store")) {
                    return null;
                }
                if (token.startsWith("max-age=")) {
                    try {
                        maxAge = Long.parseLong(token.substring(8));
                    } catch (Exception e) {
                        Exception exc = e;
                    }
                } else if (token.startsWith("stale-while-revalidate=")) {
                    try {
                        staleWhileRevalidate = Long.parseLong(token.substring(23));
                    } catch (Exception e2) {
                        Exception exc2 = e2;
                    }
                } else if (token.equals("must-revalidate") || token.equals("proxy-revalidate")) {
                    mustRevalidate = true;
                }
            }
        }
        String headerValue3 = headers.get("Expires");
        if (headerValue3 != null) {
            serverExpires = parseDateAsEpoch(headerValue3);
        }
        String headerValue4 = headers.get("Last-Modified");
        if (headerValue4 != null) {
            lastModified = parseDateAsEpoch(headerValue4);
        }
        String serverEtag = headers.get("ETag");
        if (hasCacheControl) {
            softExpire = now + (maxAge * 1000);
            finalExpire = mustRevalidate ? softExpire : softExpire + (staleWhileRevalidate * 1000);
        } else if (serverDate > 0 && serverExpires >= serverDate) {
            softExpire = now + (serverExpires - serverDate);
            finalExpire = softExpire;
        }
        new Cache.Entry();
        Cache.Entry entry2 = entry;
        entry2.data = response.data;
        entry2.etag = serverEtag;
        entry2.softTtl = softExpire;
        entry2.ttl = finalExpire;
        entry2.serverDate = serverDate;
        entry2.lastModified = lastModified;
        entry2.responseHeaders = headers;
        entry2.allResponseHeaders = response.allHeaders;
        return entry2;
    }

    public static long parseDateAsEpoch(String str) {
        String dateStr = str;
        try {
            return newRfc1123Formatter().parse(dateStr).getTime();
        } catch (ParseException e) {
            ParseException e2 = e;
            String message = "Unable to parse dateStr: %s, falling back to 0";
            if ("0".equals(dateStr) || "-1".equals(dateStr)) {
                VolleyLog.v(message, dateStr);
            } else {
                VolleyLog.e(e2, message, dateStr);
            }
            return 0;
        }
    }

    static String formatEpochAsRfc1123(long epoch) {
        Date date;
        new Date(epoch);
        return newRfc1123Formatter().format(date);
    }

    private static SimpleDateFormat newRfc1123Formatter() {
        SimpleDateFormat simpleDateFormat;
        new SimpleDateFormat(RFC1123_FORMAT, Locale.US);
        SimpleDateFormat formatter = simpleDateFormat;
        formatter.setTimeZone(TimeZone.getTimeZone("GMT"));
        return formatter;
    }

    public static String parseCharset(Map<String, String> headers, String str) {
        String defaultCharset = str;
        String contentType = headers.get("Content-Type");
        if (contentType != null) {
            String[] params = contentType.split(";", 0);
            for (int i = 1; i < params.length; i++) {
                String[] pair = params[i].trim().split("=", 0);
                if (pair.length == 2 && pair[0].equals("charset")) {
                    return pair[1];
                }
            }
        }
        return defaultCharset;
    }

    public static String parseCharset(Map<String, String> headers) {
        return parseCharset(headers, DEFAULT_CONTENT_CHARSET);
    }

    static Map<String, String> toHeaderMap(List<Header> allHeaders) {
        Map<String, String> map;
        new TreeMap(String.CASE_INSENSITIVE_ORDER);
        Map<String, String> headers = map;
        for (Header header : allHeaders) {
            String put = headers.put(header.getName(), header.getValue());
        }
        return headers;
    }

    static List<Header> toAllHeaderList(Map<String, String> map) {
        List<Header> list;
        Object obj;
        Map<String, String> headers = map;
        new ArrayList(headers.size());
        List<Header> allHeaders = list;
        for (Map.Entry<String, String> header : headers.entrySet()) {
            new Header(header.getKey(), header.getValue());
            boolean add = allHeaders.add(obj);
        }
        return allHeaders;
    }
}
