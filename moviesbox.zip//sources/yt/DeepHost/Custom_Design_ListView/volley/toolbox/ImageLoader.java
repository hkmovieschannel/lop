package yt.DeepHost.Custom_Design_ListView.volley.toolbox;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Looper;
import android.widget.ImageView;
import androidx.annotation.MainThread;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import yt.DeepHost.Custom_Design_ListView.isReple;
import yt.DeepHost.Custom_Design_ListView.volley.Request;
import yt.DeepHost.Custom_Design_ListView.volley.RequestQueue;
import yt.DeepHost.Custom_Design_ListView.volley.Response;
import yt.DeepHost.Custom_Design_ListView.volley.VolleyError;

public class ImageLoader {
    private int mBatchResponseDelayMs = 100;
    /* access modifiers changed from: private */
    public final HashMap<String, BatchedImageRequest> mBatchedResponses;
    private final ImageCache mCache;
    private final Handler mHandler;
    /* access modifiers changed from: private */
    public final HashMap<String, BatchedImageRequest> mInFlightRequests;
    private final RequestQueue mRequestQueue;
    private Runnable mRunnable;

    public interface ImageCache {
        Bitmap getBitmap(String str);

        void putBitmap(String str, Bitmap bitmap);
    }

    public interface ImageListener extends Response.ErrorListener {
        void onResponse(ImageContainer imageContainer, boolean z);
    }

    static /* synthetic */ Runnable access$602(ImageLoader x0, Runnable x1) {
        Runnable runnable = x1;
        Runnable runnable2 = runnable;
        x0.mRunnable = runnable2;
        return runnable;
    }

    public ImageLoader(RequestQueue queue, ImageCache imageCache) {
        HashMap<String, BatchedImageRequest> hashMap;
        HashMap<String, BatchedImageRequest> hashMap2;
        Handler handler;
        new HashMap<>();
        this.mInFlightRequests = hashMap;
        new HashMap<>();
        this.mBatchedResponses = hashMap2;
        new Handler(Looper.getMainLooper());
        this.mHandler = handler;
        this.mRequestQueue = queue;
        this.mCache = imageCache;
    }

    public static ImageListener getImageListener(Context context, ImageView view, String defaultImageResId, String errorImageResId) {
        ImageListener imageListener;
        final String str = errorImageResId;
        final ImageView imageView = view;
        final Context context2 = context;
        final String str2 = defaultImageResId;
        new ImageListener() {
            public void onErrorResponse(VolleyError volleyError) {
                VolleyError volleyError2 = volleyError;
                if (str.contains("")) {
                    imageView.setImageBitmap(isReple.mode(context2, str));
                }
            }

            public void onResponse(ImageContainer imageContainer, boolean z) {
                ImageContainer response = imageContainer;
                boolean z2 = z;
                if (response.getBitmap() != null) {
                    imageView.setImageBitmap(response.getBitmap());
                } else if (str2.contains("")) {
                    imageView.setImageBitmap(isReple.mode(context2, str2));
                }
            }
        };
        return imageListener;
    }

    public boolean isCached(String requestUrl, int maxWidth, int maxHeight) {
        return isCached(requestUrl, maxWidth, maxHeight, ImageView.ScaleType.CENTER_INSIDE);
    }

    @MainThread
    public boolean isCached(String requestUrl, int maxWidth, int maxHeight, ImageView.ScaleType scaleType) {
        Threads.throwIfNotOnMainThread();
        return this.mCache.getBitmap(getCacheKey(requestUrl, maxWidth, maxHeight, scaleType)) != null;
    }

    public ImageContainer get(String requestUrl, ImageListener listener) {
        return get(requestUrl, listener, 0, 0);
    }

    public ImageContainer get(String requestUrl, ImageListener imageListener, int maxWidth, int maxHeight) {
        return get(requestUrl, imageListener, maxWidth, maxHeight, ImageView.ScaleType.CENTER_INSIDE);
    }

    @MainThread
    public ImageContainer get(String str, ImageListener imageListener, int i, int i2, ImageView.ScaleType scaleType) {
        ImageContainer imageContainer;
        Object obj;
        ImageContainer imageContainer2;
        String requestUrl = str;
        ImageListener imageListener2 = imageListener;
        int maxWidth = i;
        int maxHeight = i2;
        ImageView.ScaleType scaleType2 = scaleType;
        Threads.throwIfNotOnMainThread();
        String cacheKey = getCacheKey(requestUrl, maxWidth, maxHeight, scaleType2);
        Bitmap cachedBitmap = this.mCache.getBitmap(cacheKey);
        if (cachedBitmap != null) {
            new ImageContainer(this, cachedBitmap, requestUrl, (String) null, (ImageListener) null);
            ImageContainer container = imageContainer2;
            imageListener2.onResponse(container, true);
            return container;
        }
        new ImageContainer(this, (Bitmap) null, requestUrl, cacheKey, imageListener2);
        ImageContainer imageContainer3 = imageContainer;
        imageListener2.onResponse(imageContainer3, true);
        BatchedImageRequest request = this.mInFlightRequests.get(cacheKey);
        if (request == null) {
            request = this.mBatchedResponses.get(cacheKey);
        }
        if (request != null) {
            request.addContainer(imageContainer3);
            return imageContainer3;
        }
        Request<Bitmap> newRequest = makeImageRequest(requestUrl, maxWidth, maxHeight, scaleType2, cacheKey);
        Request<Bitmap> add = this.mRequestQueue.add(newRequest);
        new BatchedImageRequest(newRequest, imageContainer3);
        BatchedImageRequest put = this.mInFlightRequests.put(cacheKey, obj);
        return imageContainer3;
    }

    /* access modifiers changed from: protected */
    public Request<Bitmap> makeImageRequest(String requestUrl, int maxWidth, int maxHeight, ImageView.ScaleType scaleType, String str) {
        Request<Bitmap> request;
        Response.Listener listener;
        Response.ErrorListener errorListener;
        String cacheKey = str;
        final String str2 = cacheKey;
        new Response.Listener<Bitmap>(this) {
            final /* synthetic */ ImageLoader this$0;

            {
                this.this$0 = this$0;
            }

            public void onResponse(Bitmap response) {
                this.this$0.onGetImageSuccess(str2, response);
            }
        };
        final String str3 = cacheKey;
        new Response.ErrorListener(this) {
            final /* synthetic */ ImageLoader this$0;

            {
                this.this$0 = this$0;
            }

            public void onErrorResponse(VolleyError error) {
                this.this$0.onGetImageError(str3, error);
            }
        };
        new ImageRequest(requestUrl, listener, maxWidth, maxHeight, scaleType, Bitmap.Config.RGB_565, errorListener);
        return request;
    }

    public void setBatchedResponseDelay(int newBatchedResponseDelayMs) {
        int i = newBatchedResponseDelayMs;
        this.mBatchResponseDelayMs = i;
    }

    /* access modifiers changed from: protected */
    public void onGetImageSuccess(String str, Bitmap bitmap) {
        String cacheKey = str;
        Bitmap response = bitmap;
        this.mCache.putBitmap(cacheKey, response);
        BatchedImageRequest request = this.mInFlightRequests.remove(cacheKey);
        if (request != null) {
            Bitmap access$002 = BatchedImageRequest.access$002(request, response);
            batchResponse(cacheKey, request);
        }
    }

    /* access modifiers changed from: protected */
    public void onGetImageError(String str, VolleyError volleyError) {
        String cacheKey = str;
        VolleyError error = volleyError;
        BatchedImageRequest request = this.mInFlightRequests.remove(cacheKey);
        if (request != null) {
            request.setError(error);
            batchResponse(cacheKey, request);
        }
    }

    public class ImageContainer {
        private Bitmap mBitmap;
        private final String mCacheKey;
        /* access modifiers changed from: private */
        public final ImageListener mListener;
        private final String mRequestUrl;
        final /* synthetic */ ImageLoader this$0;

        static /* synthetic */ Bitmap access$502(ImageContainer x0, Bitmap x1) {
            Bitmap bitmap = x1;
            Bitmap bitmap2 = bitmap;
            x0.mBitmap = bitmap2;
            return bitmap;
        }

        public ImageContainer(ImageLoader this$02, Bitmap bitmap, String requestUrl, String cacheKey, ImageListener listener) {
            this.this$0 = this$02;
            this.mBitmap = bitmap;
            this.mRequestUrl = requestUrl;
            this.mCacheKey = cacheKey;
            this.mListener = listener;
        }

        @MainThread
        public void cancelRequest() {
            Threads.throwIfNotOnMainThread();
            if (this.mListener != null) {
                BatchedImageRequest request = (BatchedImageRequest) this.this$0.mInFlightRequests.get(this.mCacheKey);
                if (request == null) {
                    BatchedImageRequest request2 = (BatchedImageRequest) this.this$0.mBatchedResponses.get(this.mCacheKey);
                    if (request2 != null) {
                        boolean removeContainerAndCancelIfNecessary = request2.removeContainerAndCancelIfNecessary(this);
                        if (request2.mContainers.size() == 0) {
                            Object remove = this.this$0.mBatchedResponses.remove(this.mCacheKey);
                        }
                    }
                } else if (request.removeContainerAndCancelIfNecessary(this)) {
                    Object remove2 = this.this$0.mInFlightRequests.remove(this.mCacheKey);
                }
            }
        }

        public Bitmap getBitmap() {
            return this.mBitmap;
        }

        public String getRequestUrl() {
            return this.mRequestUrl;
        }
    }

    private static class BatchedImageRequest {
        /* access modifiers changed from: private */
        public final List<ImageContainer> mContainers;
        private VolleyError mError;
        private final Request<?> mRequest;
        /* access modifiers changed from: private */
        public Bitmap mResponseBitmap;

        static /* synthetic */ Bitmap access$002(BatchedImageRequest x0, Bitmap x1) {
            Bitmap bitmap = x1;
            Bitmap bitmap2 = bitmap;
            x0.mResponseBitmap = bitmap2;
            return bitmap;
        }

        public BatchedImageRequest(Request<?> request, ImageContainer container) {
            List<ImageContainer> list;
            new ArrayList();
            this.mContainers = list;
            this.mRequest = request;
            boolean add = this.mContainers.add(container);
        }

        public void setError(VolleyError error) {
            VolleyError volleyError = error;
            this.mError = volleyError;
        }

        public VolleyError getError() {
            return this.mError;
        }

        public void addContainer(ImageContainer container) {
            boolean add = this.mContainers.add(container);
        }

        public boolean removeContainerAndCancelIfNecessary(ImageContainer container) {
            boolean remove = this.mContainers.remove(container);
            if (this.mContainers.size() != 0) {
                return false;
            }
            this.mRequest.cancel();
            return true;
        }
    }

    private void batchResponse(String cacheKey, BatchedImageRequest request) {
        Runnable runnable;
        BatchedImageRequest put = this.mBatchedResponses.put(cacheKey, request);
        if (this.mRunnable == null) {
            new Runnable(this) {
                final /* synthetic */ ImageLoader this$0;

                {
                    this.this$0 = this$0;
                }

                public void run() {
                    for (BatchedImageRequest bir : this.this$0.mBatchedResponses.values()) {
                        for (ImageContainer container : bir.mContainers) {
                            if (container.mListener != null) {
                                if (bir.getError() == null) {
                                    Bitmap access$502 = ImageContainer.access$502(container, bir.mResponseBitmap);
                                    container.mListener.onResponse(container, false);
                                } else {
                                    container.mListener.onErrorResponse(bir.getError());
                                }
                            }
                        }
                    }
                    this.this$0.mBatchedResponses.clear();
                    Runnable access$602 = ImageLoader.access$602(this.this$0, (Runnable) null);
                }
            };
            this.mRunnable = runnable;
            boolean postDelayed = this.mHandler.postDelayed(this.mRunnable, (long) this.mBatchResponseDelayMs);
        }
    }

    private static String getCacheKey(String str, int maxWidth, int maxHeight, ImageView.ScaleType scaleType) {
        StringBuilder sb;
        String url = str;
        new StringBuilder(url.length() + 12);
        return sb.append("#W").append(maxWidth).append("#H").append(maxHeight).append("#S").append(scaleType.ordinal()).append(url).toString();
    }
}
