package yt.DeepHost.Custom_Design_ListView.volley.toolbox;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.http.AndroidHttpClient;
import android.os.Build;
import java.io.File;
import net.lingala.zip4j.util.InternalZipConstants;
import yt.DeepHost.Custom_Design_ListView.volley.Cache;
import yt.DeepHost.Custom_Design_ListView.volley.Network;
import yt.DeepHost.Custom_Design_ListView.volley.RequestQueue;
import yt.DeepHost.Custom_Design_ListView.volley.toolbox.DiskBasedCache;

public class Volley {
    private static final String DEFAULT_CACHE_DIR = "volley";

    public Volley() {
    }

    public static RequestQueue newRequestQueue(Context context, BaseHttpStack baseHttpStack) {
        BasicNetwork basicNetwork;
        BasicNetwork network;
        BasicNetwork basicNetwork2;
        HttpStack httpStack;
        StringBuilder sb;
        BasicNetwork basicNetwork3;
        BaseHttpStack baseHttpStack2;
        Context context2 = context;
        BaseHttpStack stack = baseHttpStack;
        if (stack != null) {
            new BasicNetwork(stack);
            network = basicNetwork;
        } else if (Build.VERSION.SDK_INT >= 9) {
            new HurlStack();
            new BasicNetwork(baseHttpStack2);
            network = basicNetwork3;
        } else {
            String userAgent = "volley/0";
            try {
                String packageName = context2.getPackageName();
                PackageInfo info = context2.getPackageManager().getPackageInfo(packageName, 0);
                new StringBuilder();
                userAgent = sb.append(packageName).append(InternalZipConstants.ZIP_FILE_SEPARATOR).append(info.versionCode).toString();
            } catch (PackageManager.NameNotFoundException e) {
                PackageManager.NameNotFoundException nameNotFoundException = e;
            }
            new HttpClientStack(AndroidHttpClient.newInstance(userAgent));
            new BasicNetwork(httpStack);
            network = basicNetwork2;
        }
        return newRequestQueue(context2, (Network) network);
    }

    @Deprecated
    public static RequestQueue newRequestQueue(Context context, HttpStack httpStack) {
        Network network;
        Context context2 = context;
        HttpStack stack = httpStack;
        if (stack == null) {
            return newRequestQueue(context2, (BaseHttpStack) null);
        }
        new BasicNetwork(stack);
        return newRequestQueue(context2, network);
    }

    private static RequestQueue newRequestQueue(Context context, Network network) {
        DiskBasedCache.FileSupplier cacheSupplier;
        RequestQueue requestQueue;
        Cache cache;
        final Context applicationContext = context.getApplicationContext();
        new DiskBasedCache.FileSupplier() {
            private File cacheDir = null;

            public File get() {
                File file;
                if (this.cacheDir == null) {
                    new File(applicationContext.getCacheDir(), Volley.DEFAULT_CACHE_DIR);
                    this.cacheDir = file;
                }
                return this.cacheDir;
            }
        };
        new DiskBasedCache(cacheSupplier);
        new RequestQueue(cache, network);
        RequestQueue queue = requestQueue;
        queue.start();
        return queue;
    }

    public static RequestQueue newRequestQueue(Context context) {
        return newRequestQueue(context, (BaseHttpStack) null);
    }
}
