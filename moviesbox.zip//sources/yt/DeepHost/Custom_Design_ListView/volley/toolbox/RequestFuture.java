package yt.DeepHost.Custom_Design_ListView.volley.toolbox;

import android.os.SystemClock;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import yt.DeepHost.Custom_Design_ListView.volley.Request;
import yt.DeepHost.Custom_Design_ListView.volley.Response;
import yt.DeepHost.Custom_Design_ListView.volley.VolleyError;

public class RequestFuture<T> implements Future<T>, Response.Listener<T>, Response.ErrorListener {
    private VolleyError mException;
    private Request<?> mRequest;
    private T mResult;
    private boolean mResultReceived = false;

    public static <E> RequestFuture<E> newFuture() {
        RequestFuture<E> requestFuture;
        RequestFuture<E> requestFuture2 = requestFuture;
        new RequestFuture<>();
        return requestFuture2;
    }

    private RequestFuture() {
    }

    public void setRequest(Request<?> request) {
        Request<?> request2 = request;
        this.mRequest = request2;
    }

    public synchronized boolean cancel(boolean z) {
        boolean z2;
        boolean z3 = z;
        synchronized (this) {
            if (this.mRequest == null) {
                z2 = false;
            } else if (!isDone()) {
                this.mRequest.cancel();
                z2 = true;
            } else {
                z2 = false;
            }
        }
        return z2;
    }

    public T get() throws InterruptedException, ExecutionException {
        Throwable th;
        try {
            return doGet((Long) null);
        } catch (TimeoutException e) {
            TimeoutException e2 = e;
            Throwable th2 = th;
            new AssertionError(e2);
            throw th2;
        }
    }

    public T get(long timeout, TimeUnit unit) throws InterruptedException, ExecutionException, TimeoutException {
        return doGet(Long.valueOf(TimeUnit.MILLISECONDS.convert(timeout, unit)));
    }

    private synchronized T doGet(Long l) throws InterruptedException, ExecutionException, TimeoutException {
        RequestFuture<T> requestFuture;
        Throwable th;
        Throwable th2;
        Throwable th3;
        Long timeoutMs = l;
        synchronized (this) {
            if (this.mException != null) {
                Throwable th4 = th3;
                new ExecutionException(this.mException);
                throw th4;
            } else if (this.mResultReceived) {
                requestFuture = this.mResult;
            } else {
                if (timeoutMs == null) {
                    while (!isDone()) {
                        wait(0);
                    }
                } else if (timeoutMs.longValue() > 0) {
                    long nowMs = SystemClock.uptimeMillis();
                    long deadlineMs = nowMs + timeoutMs.longValue();
                    while (!isDone() && nowMs < deadlineMs) {
                        wait(deadlineMs - nowMs);
                        nowMs = SystemClock.uptimeMillis();
                    }
                }
                if (this.mException != null) {
                    Throwable th5 = th2;
                    new ExecutionException(this.mException);
                    throw th5;
                } else if (!this.mResultReceived) {
                    Throwable th6 = th;
                    new TimeoutException();
                    throw th6;
                } else {
                    requestFuture = this.mResult;
                }
            }
        }
        return requestFuture;
    }

    public boolean isCancelled() {
        if (this.mRequest == null) {
            return false;
        }
        return this.mRequest.isCanceled();
    }

    public synchronized boolean isDone() {
        boolean z;
        synchronized (this) {
            z = this.mResultReceived || this.mException != null || isCancelled();
        }
        return z;
    }

    public synchronized void onResponse(T t) {
        T response = t;
        synchronized (this) {
            this.mResultReceived = true;
            this.mResult = response;
            notifyAll();
        }
    }

    public synchronized void onErrorResponse(VolleyError volleyError) {
        VolleyError error = volleyError;
        synchronized (this) {
            this.mException = error;
            notifyAll();
        }
    }
}
