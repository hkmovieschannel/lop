package yt.DeepHost.Custom_Design_ListView.volley.toolbox;

import androidx.annotation.GuardedBy;
import androidx.annotation.Nullable;
import java.io.UnsupportedEncodingException;
import yt.DeepHost.Custom_Design_ListView.volley.NetworkResponse;
import yt.DeepHost.Custom_Design_ListView.volley.Request;
import yt.DeepHost.Custom_Design_ListView.volley.Response;
import yt.DeepHost.Custom_Design_ListView.volley.VolleyLog;

public abstract class JsonRequest<T> extends Request<T> {
    protected static final String PROTOCOL_CHARSET = "utf-8";
    private static final String PROTOCOL_CONTENT_TYPE = String.format("application/json; charset=%s", new Object[]{PROTOCOL_CHARSET});
    @GuardedBy("mLock")
    @Nullable
    private Response.Listener<T> mListener;
    private final Object mLock;
    @Nullable
    private final String mRequestBody;

    /* access modifiers changed from: protected */
    public abstract Response<T> parseNetworkResponse(NetworkResponse networkResponse);

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    @Deprecated
    public JsonRequest(String url, String requestBody, Response.Listener<T> listener, Response.ErrorListener errorListener) {
        this(-1, url, requestBody, listener, errorListener);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public JsonRequest(int method, String url, @Nullable String requestBody, Response.Listener<T> listener, @Nullable Response.ErrorListener errorListener) {
        super(method, url, errorListener);
        Object obj;
        new Object();
        this.mLock = obj;
        this.mListener = listener;
        this.mRequestBody = requestBody;
    }

    public void cancel() {
        super.cancel();
        Object obj = this.mLock;
        Object obj2 = obj;
        synchronized (obj) {
            try {
                this.mListener = null;
            } catch (Throwable th) {
                Throwable th2 = th;
                Object obj3 = obj2;
                throw th2;
            }
        }
    }

    /* JADX INFO: finally extract failed */
    /* access modifiers changed from: protected */
    public void deliverResponse(T t) {
        T response = t;
        Object obj = this.mLock;
        Object obj2 = obj;
        synchronized (obj) {
            try {
                Response.Listener<T> listener = this.mListener;
                if (listener != null) {
                    listener.onResponse(response);
                }
            } catch (Throwable th) {
                while (true) {
                    Throwable th2 = th;
                    Object obj3 = obj2;
                    throw th2;
                }
            }
        }
    }

    @Deprecated
    public String getPostBodyContentType() {
        return getBodyContentType();
    }

    @Deprecated
    public byte[] getPostBody() {
        return getBody();
    }

    public String getBodyContentType() {
        return PROTOCOL_CONTENT_TYPE;
    }

    public byte[] getBody() {
        try {
            return this.mRequestBody == null ? null : this.mRequestBody.getBytes(PROTOCOL_CHARSET);
        } catch (UnsupportedEncodingException e) {
            UnsupportedEncodingException unsupportedEncodingException = e;
            Object[] objArr = new Object[2];
            objArr[0] = this.mRequestBody;
            Object[] objArr2 = objArr;
            objArr2[1] = PROTOCOL_CHARSET;
            VolleyLog.wtf("Unsupported Encoding while trying to get the bytes of %s using %s", objArr2);
            return null;
        }
    }
}
