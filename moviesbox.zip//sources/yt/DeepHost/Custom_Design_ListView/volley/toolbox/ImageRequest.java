package yt.DeepHost.Custom_Design_ListView.volley.toolbox;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.widget.ImageView;
import androidx.annotation.GuardedBy;
import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;
import yt.DeepHost.Custom_Design_ListView.volley.DefaultRetryPolicy;
import yt.DeepHost.Custom_Design_ListView.volley.NetworkResponse;
import yt.DeepHost.Custom_Design_ListView.volley.ParseError;
import yt.DeepHost.Custom_Design_ListView.volley.Request;
import yt.DeepHost.Custom_Design_ListView.volley.Response;
import yt.DeepHost.Custom_Design_ListView.volley.RetryPolicy;
import yt.DeepHost.Custom_Design_ListView.volley.VolleyError;

public class ImageRequest extends Request<Bitmap> {
    public static final float DEFAULT_IMAGE_BACKOFF_MULT = 2.0f;
    public static final int DEFAULT_IMAGE_MAX_RETRIES = 2;
    public static final int DEFAULT_IMAGE_TIMEOUT_MS = 1000;
    private static final Object sDecodeLock;
    private final Bitmap.Config mDecodeConfig;
    @GuardedBy("mLock")
    @Nullable
    private Response.Listener<Bitmap> mListener;
    private final Object mLock;
    private final int mMaxHeight;
    private final int mMaxWidth;
    private final ImageView.ScaleType mScaleType;

    static {
        Object obj;
        new Object();
        sDecodeLock = obj;
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public ImageRequest(String url, Response.Listener<Bitmap> listener, int maxWidth, int maxHeight, ImageView.ScaleType scaleType, Bitmap.Config decodeConfig, @Nullable Response.ErrorListener errorListener) {
        super(0, url, errorListener);
        Object obj;
        RetryPolicy retryPolicy;
        new Object();
        this.mLock = obj;
        new DefaultRetryPolicy(1000, 2, 2.0f);
        Request<?> retryPolicy2 = setRetryPolicy(retryPolicy);
        this.mListener = listener;
        this.mDecodeConfig = decodeConfig;
        this.mMaxWidth = maxWidth;
        this.mMaxHeight = maxHeight;
        this.mScaleType = scaleType;
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    @Deprecated
    public ImageRequest(String url, Response.Listener<Bitmap> listener, int maxWidth, int maxHeight, Bitmap.Config decodeConfig, Response.ErrorListener errorListener) {
        this(url, listener, maxWidth, maxHeight, ImageView.ScaleType.CENTER_INSIDE, decodeConfig, errorListener);
    }

    public Request.Priority getPriority() {
        return Request.Priority.LOW;
    }

    private static int getResizedDimension(int i, int i2, int i3, int i4, ImageView.ScaleType scaleType) {
        int maxPrimary = i;
        int maxSecondary = i2;
        int actualPrimary = i3;
        int actualSecondary = i4;
        ImageView.ScaleType scaleType2 = scaleType;
        if (maxPrimary == 0 && maxSecondary == 0) {
            return actualPrimary;
        }
        if (scaleType2 == ImageView.ScaleType.FIT_XY) {
            if (maxPrimary == 0) {
                return actualPrimary;
            }
            return maxPrimary;
        } else if (maxPrimary == 0) {
            return (int) (((double) actualPrimary) * (((double) maxSecondary) / ((double) actualSecondary)));
        } else if (maxSecondary == 0) {
            return maxPrimary;
        } else {
            double ratio = ((double) actualSecondary) / ((double) actualPrimary);
            int resized = maxPrimary;
            if (scaleType2 == ImageView.ScaleType.CENTER_CROP) {
                if (((double) resized) * ratio < ((double) maxSecondary)) {
                    resized = (int) (((double) maxSecondary) / ratio);
                }
                return resized;
            }
            if (((double) resized) * ratio > ((double) maxSecondary)) {
                resized = (int) (((double) maxSecondary) / ratio);
            }
            return resized;
        }
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: No exception handlers in catch block: Catch:{  } */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public yt.DeepHost.Custom_Design_ListView.volley.Response<android.graphics.Bitmap> parseNetworkResponse(yt.DeepHost.Custom_Design_ListView.volley.NetworkResponse r12) {
        /*
            r11 = this;
            r0 = r11
            r1 = r12
            java.lang.Object r5 = sDecodeLock
            r10 = r5
            r5 = r10
            r6 = r10
            r2 = r6
            monitor-enter(r5)
            r5 = r0
            r6 = r1
            yt.DeepHost.Custom_Design_ListView.volley.Response r5 = r5.doParse(r6)     // Catch:{ OutOfMemoryError -> 0x0013 }
            r6 = r2
            monitor-exit(r6)     // Catch:{ all -> 0x0048 }
            r0 = r5
        L_0x0012:
            return r0
        L_0x0013:
            r5 = move-exception
            r3 = r5
            java.lang.String r5 = "Caught OOM for %d byte image, url=%s"
            r6 = 2
            java.lang.Object[] r6 = new java.lang.Object[r6]     // Catch:{ all -> 0x0048 }
            r10 = r6
            r6 = r10
            r7 = r10
            r8 = 0
            r9 = r1
            byte[] r9 = r9.data     // Catch:{ all -> 0x0048 }
            int r9 = r9.length     // Catch:{ all -> 0x0048 }
            java.lang.Integer r9 = java.lang.Integer.valueOf(r9)     // Catch:{ all -> 0x0048 }
            r7[r8] = r9     // Catch:{ all -> 0x0048 }
            r10 = r6
            r6 = r10
            r7 = r10
            r8 = 1
            r9 = r0
            java.lang.String r9 = r9.getUrl()     // Catch:{ all -> 0x0048 }
            r7[r8] = r9     // Catch:{ all -> 0x0048 }
            yt.DeepHost.Custom_Design_ListView.volley.VolleyLog.e(r5, r6)     // Catch:{ all -> 0x0048 }
            yt.DeepHost.Custom_Design_ListView.volley.ParseError r5 = new yt.DeepHost.Custom_Design_ListView.volley.ParseError     // Catch:{ all -> 0x0048 }
            r10 = r5
            r5 = r10
            r6 = r10
            r7 = r3
            r6.<init>((java.lang.Throwable) r7)     // Catch:{ all -> 0x0048 }
            yt.DeepHost.Custom_Design_ListView.volley.Response r5 = yt.DeepHost.Custom_Design_ListView.volley.Response.error(r5)     // Catch:{ all -> 0x0048 }
            r6 = r2
            monitor-exit(r6)     // Catch:{ all -> 0x0048 }
            r0 = r5
            goto L_0x0012
        L_0x0048:
            r5 = move-exception
            r4 = r5
            r5 = r2
            monitor-exit(r5)     // Catch:{ all -> 0x0048 }
            r5 = r4
            throw r5
        */
        throw new UnsupportedOperationException("Method not decompiled: yt.DeepHost.Custom_Design_ListView.volley.toolbox.ImageRequest.parseNetworkResponse(yt.DeepHost.Custom_Design_ListView.volley.NetworkResponse):yt.DeepHost.Custom_Design_ListView.volley.Response");
    }

    private Response<Bitmap> doParse(NetworkResponse networkResponse) {
        BitmapFactory.Options options;
        Bitmap bitmap;
        VolleyError volleyError;
        NetworkResponse response = networkResponse;
        byte[] data = response.data;
        new BitmapFactory.Options();
        BitmapFactory.Options decodeOptions = options;
        if (this.mMaxWidth == 0 && this.mMaxHeight == 0) {
            decodeOptions.inPreferredConfig = this.mDecodeConfig;
            bitmap = BitmapFactory.decodeByteArray(data, 0, data.length, decodeOptions);
        } else {
            decodeOptions.inJustDecodeBounds = true;
            Bitmap decodeByteArray = BitmapFactory.decodeByteArray(data, 0, data.length, decodeOptions);
            int actualWidth = decodeOptions.outWidth;
            int actualHeight = decodeOptions.outHeight;
            int desiredWidth = getResizedDimension(this.mMaxWidth, this.mMaxHeight, actualWidth, actualHeight, this.mScaleType);
            int desiredHeight = getResizedDimension(this.mMaxHeight, this.mMaxWidth, actualHeight, actualWidth, this.mScaleType);
            decodeOptions.inJustDecodeBounds = false;
            decodeOptions.inSampleSize = findBestSampleSize(actualWidth, actualHeight, desiredWidth, desiredHeight);
            Bitmap tempBitmap = BitmapFactory.decodeByteArray(data, 0, data.length, decodeOptions);
            if (tempBitmap == null || (tempBitmap.getWidth() <= desiredWidth && tempBitmap.getHeight() <= desiredHeight)) {
                bitmap = tempBitmap;
            } else {
                bitmap = Bitmap.createScaledBitmap(tempBitmap, desiredWidth, desiredHeight, true);
                tempBitmap.recycle();
            }
        }
        if (bitmap != null) {
            return Response.success(bitmap, HttpHeaderParser.parseCacheHeaders(response));
        }
        new ParseError(response);
        return Response.error(volleyError);
    }

    public void cancel() {
        super.cancel();
        Object obj = this.mLock;
        Object obj2 = obj;
        synchronized (obj) {
            try {
                this.mListener = null;
            } catch (Throwable th) {
                Throwable th2 = th;
                Object obj3 = obj2;
                throw th2;
            }
        }
    }

    /* JADX INFO: finally extract failed */
    /* access modifiers changed from: protected */
    public void deliverResponse(Bitmap bitmap) {
        Bitmap response = bitmap;
        Object obj = this.mLock;
        Object obj2 = obj;
        synchronized (obj) {
            try {
                Response.Listener<Bitmap> listener = this.mListener;
                if (listener != null) {
                    listener.onResponse(response);
                }
            } catch (Throwable th) {
                while (true) {
                    Throwable th2 = th;
                    Object obj3 = obj2;
                    throw th2;
                }
            }
        }
    }

    @VisibleForTesting
    static int findBestSampleSize(int actualWidth, int actualHeight, int desiredWidth, int desiredHeight) {
        float f = 1.0f;
        while (true) {
            float n = f;
            if (((double) (n * 2.0f)) > Math.min(((double) actualWidth) / ((double) desiredWidth), ((double) actualHeight) / ((double) desiredHeight))) {
                return (int) n;
            }
            f = n * 2.0f;
        }
    }
}
