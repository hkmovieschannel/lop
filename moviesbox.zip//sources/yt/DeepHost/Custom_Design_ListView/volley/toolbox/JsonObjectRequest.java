package yt.DeepHost.Custom_Design_ListView.volley.toolbox;

import java.io.UnsupportedEncodingException;
import org.json.JSONException;
import org.json.JSONObject;
import yt.DeepHost.Custom_Design_ListView.volley.NetworkResponse;
import yt.DeepHost.Custom_Design_ListView.volley.ParseError;
import yt.DeepHost.Custom_Design_ListView.volley.Response;
import yt.DeepHost.Custom_Design_ListView.volley.VolleyError;

public class JsonObjectRequest extends JsonRequest<JSONObject> {
    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public JsonObjectRequest(int r13, java.lang.String r14, @androidx.annotation.Nullable org.json.JSONObject r15, yt.DeepHost.Custom_Design_ListView.volley.Response.Listener<org.json.JSONObject> r16, @androidx.annotation.Nullable yt.DeepHost.Custom_Design_ListView.volley.Response.ErrorListener r17) {
        /*
            r12 = this;
            r0 = r12
            r1 = r13
            r2 = r14
            r3 = r15
            r4 = r16
            r5 = r17
            r6 = r0
            r7 = r1
            r8 = r2
            r9 = r3
            if (r9 != 0) goto L_0x0015
            r9 = 0
        L_0x000f:
            r10 = r4
            r11 = r5
            r6.<init>(r7, r8, r9, r10, r11)
            return
        L_0x0015:
            r9 = r3
            java.lang.String r9 = r9.toString()
            goto L_0x000f
        */
        throw new UnsupportedOperationException("Method not decompiled: yt.DeepHost.Custom_Design_ListView.volley.toolbox.JsonObjectRequest.<init>(int, java.lang.String, org.json.JSONObject, yt.DeepHost.Custom_Design_ListView.volley.Response$Listener, yt.DeepHost.Custom_Design_ListView.volley.Response$ErrorListener):void");
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public JsonObjectRequest(java.lang.String r12, @androidx.annotation.Nullable org.json.JSONObject r13, yt.DeepHost.Custom_Design_ListView.volley.Response.Listener<org.json.JSONObject> r14, @androidx.annotation.Nullable yt.DeepHost.Custom_Design_ListView.volley.Response.ErrorListener r15) {
        /*
            r11 = this;
            r0 = r11
            r1 = r12
            r2 = r13
            r3 = r14
            r4 = r15
            r5 = r0
            r6 = r2
            if (r6 != 0) goto L_0x0012
            r6 = 0
        L_0x000a:
            r7 = r1
            r8 = r2
            r9 = r3
            r10 = r4
            r5.<init>(r6, r7, r8, r9, r10)
            return
        L_0x0012:
            r6 = 1
            goto L_0x000a
        */
        throw new UnsupportedOperationException("Method not decompiled: yt.DeepHost.Custom_Design_ListView.volley.toolbox.JsonObjectRequest.<init>(java.lang.String, org.json.JSONObject, yt.DeepHost.Custom_Design_ListView.volley.Response$Listener, yt.DeepHost.Custom_Design_ListView.volley.Response$ErrorListener):void");
    }

    /* access modifiers changed from: protected */
    public Response<JSONObject> parseNetworkResponse(NetworkResponse networkResponse) {
        VolleyError volleyError;
        VolleyError volleyError2;
        String jsonString;
        Object obj;
        NetworkResponse response = networkResponse;
        try {
            new String(response.data, HttpHeaderParser.parseCharset(response.headers, "utf-8"));
            new JSONObject(jsonString);
            return Response.success(obj, HttpHeaderParser.parseCacheHeaders(response));
        } catch (UnsupportedEncodingException e) {
            new ParseError((Throwable) e);
            return Response.error(volleyError2);
        } catch (JSONException e2) {
            new ParseError((Throwable) e2);
            return Response.error(volleyError);
        }
    }
}
