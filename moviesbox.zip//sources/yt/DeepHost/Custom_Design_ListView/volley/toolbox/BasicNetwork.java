package yt.DeepHost.Custom_Design_ListView.volley.toolbox;

import android.os.SystemClock;
import com.google.appinventor.components.runtime.util.ErrorMessages;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import yt.DeepHost.Custom_Design_ListView.volley.AuthFailureError;
import yt.DeepHost.Custom_Design_ListView.volley.Cache;
import yt.DeepHost.Custom_Design_ListView.volley.ClientError;
import yt.DeepHost.Custom_Design_ListView.volley.Header;
import yt.DeepHost.Custom_Design_ListView.volley.Network;
import yt.DeepHost.Custom_Design_ListView.volley.NetworkError;
import yt.DeepHost.Custom_Design_ListView.volley.NetworkResponse;
import yt.DeepHost.Custom_Design_ListView.volley.NoConnectionError;
import yt.DeepHost.Custom_Design_ListView.volley.Request;
import yt.DeepHost.Custom_Design_ListView.volley.RetryPolicy;
import yt.DeepHost.Custom_Design_ListView.volley.ServerError;
import yt.DeepHost.Custom_Design_ListView.volley.TimeoutError;
import yt.DeepHost.Custom_Design_ListView.volley.VolleyError;
import yt.DeepHost.Custom_Design_ListView.volley.VolleyLog;

public class BasicNetwork implements Network {
    protected static final boolean DEBUG = VolleyLog.DEBUG;
    private static final int DEFAULT_POOL_SIZE = 4096;
    private static final int SLOW_REQUEST_THRESHOLD_MS = 3000;
    private final BaseHttpStack mBaseHttpStack;
    @Deprecated
    protected final HttpStack mHttpStack;
    protected final ByteArrayPool mPool;

    /* JADX WARNING: Illegal instructions before constructor call */
    @java.lang.Deprecated
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public BasicNetwork(yt.DeepHost.Custom_Design_ListView.volley.toolbox.HttpStack r9) {
        /*
            r8 = this;
            r0 = r8
            r1 = r9
            r2 = r0
            r3 = r1
            yt.DeepHost.Custom_Design_ListView.volley.toolbox.ByteArrayPool r4 = new yt.DeepHost.Custom_Design_ListView.volley.toolbox.ByteArrayPool
            r7 = r4
            r4 = r7
            r5 = r7
            r6 = 4096(0x1000, float:5.74E-42)
            r5.<init>(r6)
            r2.<init>((yt.DeepHost.Custom_Design_ListView.volley.toolbox.HttpStack) r3, (yt.DeepHost.Custom_Design_ListView.volley.toolbox.ByteArrayPool) r4)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: yt.DeepHost.Custom_Design_ListView.volley.toolbox.BasicNetwork.<init>(yt.DeepHost.Custom_Design_ListView.volley.toolbox.HttpStack):void");
    }

    @Deprecated
    public BasicNetwork(HttpStack httpStack, ByteArrayPool pool) {
        BaseHttpStack baseHttpStack;
        HttpStack httpStack2 = httpStack;
        this.mHttpStack = httpStack2;
        new AdaptedHttpStack(httpStack2);
        this.mBaseHttpStack = baseHttpStack;
        this.mPool = pool;
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public BasicNetwork(yt.DeepHost.Custom_Design_ListView.volley.toolbox.BaseHttpStack r9) {
        /*
            r8 = this;
            r0 = r8
            r1 = r9
            r2 = r0
            r3 = r1
            yt.DeepHost.Custom_Design_ListView.volley.toolbox.ByteArrayPool r4 = new yt.DeepHost.Custom_Design_ListView.volley.toolbox.ByteArrayPool
            r7 = r4
            r4 = r7
            r5 = r7
            r6 = 4096(0x1000, float:5.74E-42)
            r5.<init>(r6)
            r2.<init>((yt.DeepHost.Custom_Design_ListView.volley.toolbox.BaseHttpStack) r3, (yt.DeepHost.Custom_Design_ListView.volley.toolbox.ByteArrayPool) r4)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: yt.DeepHost.Custom_Design_ListView.volley.toolbox.BasicNetwork.<init>(yt.DeepHost.Custom_Design_ListView.volley.toolbox.BaseHttpStack):void");
    }

    public BasicNetwork(BaseHttpStack baseHttpStack, ByteArrayPool pool) {
        BaseHttpStack httpStack = baseHttpStack;
        this.mBaseHttpStack = httpStack;
        this.mHttpStack = httpStack;
        this.mPool = pool;
    }

    public NetworkResponse performRequest(Request<?> request) throws VolleyError {
        List<Header> responseHeaders;
        Throwable th;
        VolleyError volleyError;
        NetworkResponse networkResponse;
        VolleyError volleyError2;
        Throwable th2;
        Throwable th3;
        VolleyError volleyError3;
        Throwable th4;
        Throwable th5;
        StringBuilder sb;
        VolleyError volleyError4;
        int statusCode;
        NetworkResponse networkResponse2;
        NetworkResponse networkResponse3;
        byte[] responseContents;
        Throwable th6;
        NetworkResponse networkResponse4;
        Request<?> request2 = request;
        long requestStart = SystemClock.elapsedRealtime();
        while (true) {
            HttpResponse httpResponse = null;
            responseHeaders = Collections.emptyList();
            try {
                httpResponse = this.mBaseHttpStack.executeRequest(request2, getCacheHeaders(request2.getCacheEntry()));
                statusCode = httpResponse.getStatusCode();
                responseHeaders = httpResponse.getHeaders();
                if (statusCode != 304) {
                    InputStream inputStream = httpResponse.getContent();
                    if (inputStream == null) {
                        responseContents = new byte[0];
                        break;
                    }
                    responseContents = inputStreamToBytes(inputStream, httpResponse.getContentLength());
                    break;
                }
                Cache.Entry entry = request2.getCacheEntry();
                if (entry == null) {
                    new NetworkResponse((int) ErrorMessages.ERROR_TWITTER_UNABLE_TO_GET_ACCESS_TOKEN, (byte[]) null, true, SystemClock.elapsedRealtime() - requestStart, responseHeaders);
                    return networkResponse3;
                }
                new NetworkResponse((int) ErrorMessages.ERROR_TWITTER_UNABLE_TO_GET_ACCESS_TOKEN, entry.data, true, SystemClock.elapsedRealtime() - requestStart, combineHeaders(responseHeaders, entry));
                return networkResponse2;
            } catch (SocketTimeoutException e) {
                SocketTimeoutException socketTimeoutException = e;
                new TimeoutError();
                attemptRetryOnException("socket", request2, volleyError4);
            } catch (MalformedURLException e2) {
                MalformedURLException e3 = e2;
                Throwable th7 = th5;
                new StringBuilder();
                new RuntimeException(sb.append("Bad URL ").append(request2.getUrl()).toString(), e3);
                throw th7;
            } catch (IOException e4) {
                IOException e5 = e4;
                if (httpResponse != null) {
                    int statusCode2 = httpResponse.getStatusCode();
                    Object[] objArr = new Object[2];
                    objArr[0] = Integer.valueOf(statusCode2);
                    Object[] objArr2 = objArr;
                    objArr2[1] = request2.getUrl();
                    VolleyLog.e("Unexpected response code %d for %s", objArr2);
                    if (0 != 0) {
                        new NetworkResponse(statusCode2, (byte[]) null, false, SystemClock.elapsedRealtime() - requestStart, responseHeaders);
                        NetworkResponse networkResponse5 = networkResponse;
                        if (statusCode2 == 401 || statusCode2 == 403) {
                            new AuthFailureError(networkResponse5);
                            attemptRetryOnException("auth", request2, volleyError2);
                        } else if (statusCode2 >= 400 && statusCode2 <= 499) {
                            Throwable th8 = th4;
                            new ClientError(networkResponse5);
                            throw th8;
                        } else if (statusCode2 < 500 || statusCode2 > 599) {
                            Throwable th9 = th2;
                            new ServerError(networkResponse5);
                            throw th9;
                        } else if (request2.shouldRetryServerErrors()) {
                            new ServerError(networkResponse5);
                            attemptRetryOnException("server", request2, volleyError3);
                        } else {
                            Throwable th10 = th3;
                            new ServerError(networkResponse5);
                            throw th10;
                        }
                    } else {
                        new NetworkError();
                        attemptRetryOnException("network", request2, volleyError);
                    }
                } else {
                    Throwable th11 = th;
                    new NoConnectionError(e5);
                    throw th11;
                }
            }
        }
        logSlowRequests(SystemClock.elapsedRealtime() - requestStart, request2, responseContents, statusCode);
        if (statusCode < 200 || statusCode > 299) {
            Throwable th12 = th6;
            new IOException();
            throw th12;
        }
        NetworkResponse networkResponse6 = networkResponse4;
        new NetworkResponse(statusCode, responseContents, false, SystemClock.elapsedRealtime() - requestStart, responseHeaders);
        return networkResponse6;
    }

    private void logSlowRequests(long j, Request<?> request, byte[] bArr, int i) {
        long requestLifetime = j;
        Request<?> request2 = request;
        byte[] responseContents = bArr;
        int statusCode = i;
        if (DEBUG || requestLifetime > 3000) {
            Object[] objArr = new Object[5];
            objArr[0] = request2;
            Object[] objArr2 = objArr;
            objArr2[1] = Long.valueOf(requestLifetime);
            Object[] objArr3 = objArr2;
            Object[] objArr4 = objArr3;
            objArr3[2] = responseContents != null ? Integer.valueOf(responseContents.length) : "null";
            Object[] objArr5 = objArr4;
            objArr5[3] = Integer.valueOf(statusCode);
            Object[] objArr6 = objArr5;
            objArr6[4] = Integer.valueOf(request2.getRetryPolicy().getCurrentRetryCount());
            VolleyLog.d("HTTP response for request=<%s> [lifetime=%d], [size=%s], [rc=%d], [retryCount=%s]", objArr6);
        }
    }

    private static void attemptRetryOnException(String str, Request<?> request, VolleyError exception) throws VolleyError {
        String logPrefix = str;
        Request<?> request2 = request;
        RetryPolicy retryPolicy = request2.getRetryPolicy();
        int oldTimeout = request2.getTimeoutMs();
        try {
            retryPolicy.retry(exception);
            Object[] objArr = new Object[2];
            objArr[0] = logPrefix;
            Object[] objArr2 = objArr;
            objArr2[1] = Integer.valueOf(oldTimeout);
            request2.addMarker(String.format("%s-retry [timeout=%s]", objArr2));
        } catch (VolleyError e) {
            VolleyError e2 = e;
            Object[] objArr3 = new Object[2];
            objArr3[0] = logPrefix;
            Object[] objArr4 = objArr3;
            objArr4[1] = Integer.valueOf(oldTimeout);
            request2.addMarker(String.format("%s-timeout-giveup [timeout=%s]", objArr4));
            throw e2;
        }
    }

    private Map<String, String> getCacheHeaders(Cache.Entry entry) {
        Map<String, String> map;
        Cache.Entry entry2 = entry;
        if (entry2 == null) {
            return Collections.emptyMap();
        }
        new HashMap();
        Map<String, String> headers = map;
        if (entry2.etag != null) {
            String put = headers.put("If-None-Match", entry2.etag);
        }
        if (entry2.lastModified > 0) {
            String put2 = headers.put("If-Modified-Since", HttpHeaderParser.formatEpochAsRfc1123(entry2.lastModified));
        }
        return headers;
    }

    /* access modifiers changed from: protected */
    public void logError(String what, String url, long start) {
        Object[] objArr = new Object[3];
        objArr[0] = what;
        Object[] objArr2 = objArr;
        objArr2[1] = Long.valueOf(SystemClock.elapsedRealtime() - start);
        Object[] objArr3 = objArr2;
        objArr3[2] = url;
        VolleyLog.v("HTTP ERROR(%s) %d ms to fetch %s", objArr3);
    }

    private byte[] inputStreamToBytes(InputStream inputStream, int contentLength) throws IOException, ServerError {
        PoolingByteArrayOutputStream poolingByteArrayOutputStream;
        Throwable th;
        InputStream in = inputStream;
        new PoolingByteArrayOutputStream(this.mPool, contentLength);
        PoolingByteArrayOutputStream bytes = poolingByteArrayOutputStream;
        if (in == null) {
            try {
                Throwable th2 = th;
                new ServerError();
                throw th2;
            } catch (Throwable th3) {
                Throwable th4 = th3;
                if (in != null) {
                    try {
                        in.close();
                    } catch (IOException e) {
                        IOException iOException = e;
                        VolleyLog.v("Error occurred when closing InputStream", new Object[0]);
                    }
                }
                this.mPool.returnBuf((byte[]) null);
                bytes.close();
                throw th4;
            }
        } else {
            byte[] buffer = this.mPool.getBuf(1024);
            while (true) {
                int read = in.read(buffer);
                int count = read;
                if (read == -1) {
                    break;
                }
                bytes.write(buffer, 0, count);
            }
            byte[] byteArray = bytes.toByteArray();
            if (in != null) {
                try {
                    in.close();
                } catch (IOException e2) {
                    IOException iOException2 = e2;
                    VolleyLog.v("Error occurred when closing InputStream", new Object[0]);
                }
            }
            this.mPool.returnBuf(buffer);
            bytes.close();
            return byteArray;
        }
    }

    @Deprecated
    protected static Map<String, String> convertHeaders(Header[] headerArr) {
        Map<String, String> map;
        Header[] headers = headerArr;
        new TreeMap(String.CASE_INSENSITIVE_ORDER);
        Map<String, String> result = map;
        for (int i = 0; i < headers.length; i++) {
            String put = result.put(headers[i].getName(), headers[i].getValue());
        }
        return result;
    }

    private static List<Header> combineHeaders(List<Header> list, Cache.Entry entry) {
        Set<String> set;
        List<Header> list2;
        Object obj;
        List<Header> responseHeaders = list;
        Cache.Entry entry2 = entry;
        new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
        Set<String> headerNamesFromNetworkResponse = set;
        if (!responseHeaders.isEmpty()) {
            for (Header header : responseHeaders) {
                boolean add = headerNamesFromNetworkResponse.add(header.getName());
            }
        }
        new ArrayList(responseHeaders);
        List<Header> combinedHeaders = list2;
        if (entry2.allResponseHeaders != null) {
            if (!entry2.allResponseHeaders.isEmpty()) {
                for (Header header2 : entry2.allResponseHeaders) {
                    if (!headerNamesFromNetworkResponse.contains(header2.getName())) {
                        boolean add2 = combinedHeaders.add(header2);
                    }
                }
            }
        } else if (!entry2.responseHeaders.isEmpty()) {
            for (Map.Entry<String, String> header3 : entry2.responseHeaders.entrySet()) {
                if (!headerNamesFromNetworkResponse.contains(header3.getKey())) {
                    new Header(header3.getKey(), header3.getValue());
                    boolean add3 = combinedHeaders.add(obj);
                }
            }
        }
        return combinedHeaders;
    }
}
