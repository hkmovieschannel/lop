package yt.DeepHost.Custom_Design_ListView.volley.toolbox;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.widget.ImageView;
import androidx.annotation.ColorInt;
import androidx.annotation.ColorRes;
import androidx.annotation.DrawableRes;
import androidx.annotation.RequiresApi;

public class CircleImageView extends NetworkImageView {
    private static final Bitmap.Config BITMAP_CONFIG = Bitmap.Config.ARGB_8888;
    private static final int COLORDRAWABLE_DIMENSION = 2;
    private static final int DEFAULT_BORDER_COLOR = -16777216;
    private static final boolean DEFAULT_BORDER_OVERLAY = false;
    private static final int DEFAULT_BORDER_WIDTH = 0;
    private static final int DEFAULT_CIRCLE_BACKGROUND_COLOR = 0;
    private static final ImageView.ScaleType SCALE_TYPE = ImageView.ScaleType.CENTER_CROP;
    private Bitmap mBitmap;
    private int mBitmapHeight;
    private final Paint mBitmapPaint;
    private BitmapShader mBitmapShader;
    private int mBitmapWidth;
    private int mBorderColor;
    private boolean mBorderOverlay;
    private final Paint mBorderPaint;
    private float mBorderRadius;
    /* access modifiers changed from: private */
    public final RectF mBorderRect;
    private int mBorderWidth;
    private int mCircleBackgroundColor;
    private final Paint mCircleBackgroundPaint;
    private ColorFilter mColorFilter;
    /* access modifiers changed from: private */
    public boolean mDisableCircularTransformation;
    private float mDrawableRadius;
    private final RectF mDrawableRect;
    private boolean mReady;
    private boolean mSetupPending;
    private final Matrix mShaderMatrix;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public CircleImageView(Context context) {
        super(context);
        RectF rectF;
        RectF rectF2;
        Matrix matrix;
        Paint paint;
        Paint paint2;
        Paint paint3;
        new RectF();
        this.mDrawableRect = rectF;
        new RectF();
        this.mBorderRect = rectF2;
        new Matrix();
        this.mShaderMatrix = matrix;
        new Paint();
        this.mBitmapPaint = paint;
        new Paint();
        this.mBorderPaint = paint2;
        new Paint();
        this.mCircleBackgroundPaint = paint3;
        this.mBorderColor = -16777216;
        this.mBorderWidth = 0;
        this.mCircleBackgroundColor = 0;
        init();
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public CircleImageView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public CircleImageView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        RectF rectF;
        RectF rectF2;
        Matrix matrix;
        Paint paint;
        Paint paint2;
        Paint paint3;
        new RectF();
        this.mDrawableRect = rectF;
        new RectF();
        this.mBorderRect = rectF2;
        new Matrix();
        this.mShaderMatrix = matrix;
        new Paint();
        this.mBitmapPaint = paint;
        new Paint();
        this.mBorderPaint = paint2;
        new Paint();
        this.mCircleBackgroundPaint = paint3;
        this.mBorderColor = -16777216;
        this.mBorderWidth = 0;
        this.mCircleBackgroundColor = 0;
        this.mBorderWidth = 0;
        this.mBorderColor = -16777216;
        this.mBorderOverlay = false;
        this.mCircleBackgroundColor = 0;
        init();
    }

    private void init() {
        ViewOutlineProvider viewOutlineProvider;
        super.setScaleType(SCALE_TYPE);
        this.mReady = true;
        if (Build.VERSION.SDK_INT >= 21) {
            new OutlineProvider(this, (AnonymousClass1) null);
            setOutlineProvider(viewOutlineProvider);
        }
        if (this.mSetupPending) {
            setup();
            this.mSetupPending = false;
        }
    }

    public ImageView.ScaleType getScaleType() {
        return SCALE_TYPE;
    }

    public void setScaleType(ImageView.ScaleType scaleType) {
        Throwable th;
        ImageView.ScaleType scaleType2 = scaleType;
        if (scaleType2 != SCALE_TYPE) {
            Throwable th2 = th;
            new IllegalArgumentException(String.format("ScaleType %s not supported.", new Object[]{scaleType2}));
            throw th2;
        }
    }

    public void setAdjustViewBounds(boolean adjustViewBounds) {
        Throwable th;
        if (adjustViewBounds) {
            Throwable th2 = th;
            new IllegalArgumentException("adjustViewBounds not supported.");
            throw th2;
        }
    }

    /* access modifiers changed from: protected */
    public void onDraw(Canvas canvas) {
        Canvas canvas2 = canvas;
        if (this.mDisableCircularTransformation) {
            super.onDraw(canvas2);
        } else if (this.mBitmap != null) {
            if (this.mCircleBackgroundColor != 0) {
                canvas2.drawCircle(this.mDrawableRect.centerX(), this.mDrawableRect.centerY(), this.mDrawableRadius, this.mCircleBackgroundPaint);
            }
            canvas2.drawCircle(this.mDrawableRect.centerX(), this.mDrawableRect.centerY(), this.mDrawableRadius, this.mBitmapPaint);
            if (this.mBorderWidth > 0) {
                canvas2.drawCircle(this.mBorderRect.centerX(), this.mBorderRect.centerY(), this.mBorderRadius, this.mBorderPaint);
            }
        }
    }

    /* access modifiers changed from: protected */
    public void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        setup();
    }

    public void setPadding(int left, int top, int right, int bottom) {
        super.setPadding(left, top, right, bottom);
        setup();
    }

    public void setPaddingRelative(int start, int top, int end, int bottom) {
        super.setPaddingRelative(start, top, end, bottom);
        setup();
    }

    public int getBorderColor() {
        return this.mBorderColor;
    }

    public void setBorderColor(@ColorInt int i) {
        int borderColor = i;
        if (borderColor != this.mBorderColor) {
            this.mBorderColor = borderColor;
            this.mBorderPaint.setColor(this.mBorderColor);
            invalidate();
        }
    }

    public int getCircleBackgroundColor() {
        return this.mCircleBackgroundColor;
    }

    public void setCircleBackgroundColor(@ColorInt int i) {
        int circleBackgroundColor = i;
        if (circleBackgroundColor != this.mCircleBackgroundColor) {
            this.mCircleBackgroundColor = circleBackgroundColor;
            this.mCircleBackgroundPaint.setColor(circleBackgroundColor);
            invalidate();
        }
    }

    public void setCircleBackgroundColorResource(@ColorRes int circleBackgroundRes) {
        setCircleBackgroundColor(getContext().getResources().getColor(circleBackgroundRes));
    }

    public int getBorderWidth() {
        return this.mBorderWidth;
    }

    public void setBorderWidth(int i) {
        int borderWidth = i;
        if (borderWidth != this.mBorderWidth) {
            this.mBorderWidth = borderWidth;
            setup();
        }
    }

    public boolean isBorderOverlay() {
        return this.mBorderOverlay;
    }

    public void setBorderOverlay(boolean z) {
        boolean borderOverlay = z;
        if (borderOverlay != this.mBorderOverlay) {
            this.mBorderOverlay = borderOverlay;
            setup();
        }
    }

    public boolean isDisableCircularTransformation() {
        return this.mDisableCircularTransformation;
    }

    public void setDisableCircularTransformation(boolean z) {
        boolean disableCircularTransformation = z;
        if (this.mDisableCircularTransformation != disableCircularTransformation) {
            this.mDisableCircularTransformation = disableCircularTransformation;
            initializeBitmap();
        }
    }

    public void setImageBitmap(Bitmap bm) {
        super.setImageBitmap(bm);
        initializeBitmap();
    }

    public void setImageDrawable(Drawable drawable) {
        super.setImageDrawable(drawable);
        initializeBitmap();
    }

    public void setImageResource(@DrawableRes int resId) {
        super.setImageResource(resId);
        initializeBitmap();
    }

    public void setImageURI(Uri uri) {
        super.setImageURI(uri);
        initializeBitmap();
    }

    public void setColorFilter(ColorFilter colorFilter) {
        ColorFilter cf = colorFilter;
        if (cf != this.mColorFilter) {
            this.mColorFilter = cf;
            applyColorFilter();
            invalidate();
        }
    }

    public ColorFilter getColorFilter() {
        return this.mColorFilter;
    }

    private void applyColorFilter() {
        if (this.mBitmapPaint != null) {
            ColorFilter colorFilter = this.mBitmapPaint.setColorFilter(this.mColorFilter);
        }
    }

    private Bitmap getBitmapFromDrawable(Drawable drawable) {
        Bitmap bitmap;
        Canvas canvas;
        Drawable drawable2 = drawable;
        if (drawable2 == null) {
            return null;
        }
        if (drawable2 instanceof BitmapDrawable) {
            return ((BitmapDrawable) drawable2).getBitmap();
        }
        try {
            if (drawable2 instanceof ColorDrawable) {
                bitmap = Bitmap.createBitmap(2, 2, BITMAP_CONFIG);
            } else {
                bitmap = Bitmap.createBitmap(drawable2.getIntrinsicWidth(), drawable2.getIntrinsicHeight(), BITMAP_CONFIG);
            }
            new Canvas(bitmap);
            Canvas canvas2 = canvas;
            drawable2.setBounds(0, 0, canvas2.getWidth(), canvas2.getHeight());
            drawable2.draw(canvas2);
            return bitmap;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private void initializeBitmap() {
        if (this.mDisableCircularTransformation) {
            this.mBitmap = null;
        } else {
            this.mBitmap = getBitmapFromDrawable(getDrawable());
        }
        setup();
    }

    private void setup() {
        BitmapShader bitmapShader;
        if (!this.mReady) {
            this.mSetupPending = true;
        } else if (getWidth() != 0 || getHeight() != 0) {
            if (this.mBitmap == null) {
                invalidate();
                return;
            }
            new BitmapShader(this.mBitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
            this.mBitmapShader = bitmapShader;
            this.mBitmapPaint.setAntiAlias(true);
            this.mBitmapPaint.setDither(true);
            this.mBitmapPaint.setFilterBitmap(true);
            Shader shader = this.mBitmapPaint.setShader(this.mBitmapShader);
            this.mBorderPaint.setStyle(Paint.Style.STROKE);
            this.mBorderPaint.setAntiAlias(true);
            this.mBorderPaint.setColor(this.mBorderColor);
            this.mBorderPaint.setStrokeWidth((float) this.mBorderWidth);
            this.mCircleBackgroundPaint.setStyle(Paint.Style.FILL);
            this.mCircleBackgroundPaint.setAntiAlias(true);
            this.mCircleBackgroundPaint.setColor(this.mCircleBackgroundColor);
            this.mBitmapHeight = this.mBitmap.getHeight();
            this.mBitmapWidth = this.mBitmap.getWidth();
            this.mBorderRect.set(calculateBounds());
            this.mBorderRadius = Math.min((this.mBorderRect.height() - ((float) this.mBorderWidth)) / 2.0f, (this.mBorderRect.width() - ((float) this.mBorderWidth)) / 2.0f);
            this.mDrawableRect.set(this.mBorderRect);
            if (!this.mBorderOverlay && this.mBorderWidth > 0) {
                this.mDrawableRect.inset(((float) this.mBorderWidth) - 1.0f, ((float) this.mBorderWidth) - 1.0f);
            }
            this.mDrawableRadius = Math.min(this.mDrawableRect.height() / 2.0f, this.mDrawableRect.width() / 2.0f);
            applyColorFilter();
            updateShaderMatrix();
            invalidate();
        }
    }

    private RectF calculateBounds() {
        RectF rectF;
        int availableWidth = (getWidth() - getPaddingLeft()) - getPaddingRight();
        int availableHeight = (getHeight() - getPaddingTop()) - getPaddingBottom();
        int sideLength = Math.min(availableWidth, availableHeight);
        float left = ((float) getPaddingLeft()) + (((float) (availableWidth - sideLength)) / 2.0f);
        float top = ((float) getPaddingTop()) + (((float) (availableHeight - sideLength)) / 2.0f);
        new RectF(left, top, left + ((float) sideLength), top + ((float) sideLength));
        return rectF;
    }

    private void updateShaderMatrix() {
        float scale;
        float dx = 0.0f;
        float dy = 0.0f;
        this.mShaderMatrix.set((Matrix) null);
        if (((float) this.mBitmapWidth) * this.mDrawableRect.height() > this.mDrawableRect.width() * ((float) this.mBitmapHeight)) {
            scale = this.mDrawableRect.height() / ((float) this.mBitmapHeight);
            dx = (this.mDrawableRect.width() - (((float) this.mBitmapWidth) * scale)) * 0.5f;
        } else {
            scale = this.mDrawableRect.width() / ((float) this.mBitmapWidth);
            dy = (this.mDrawableRect.height() - (((float) this.mBitmapHeight) * scale)) * 0.5f;
        }
        this.mShaderMatrix.setScale(scale, scale);
        boolean postTranslate = this.mShaderMatrix.postTranslate(((float) ((int) (dx + 0.5f))) + this.mDrawableRect.left, ((float) ((int) (dy + 0.5f))) + this.mDrawableRect.top);
        this.mBitmapShader.setLocalMatrix(this.mShaderMatrix);
    }

    @SuppressLint({"ClickableViewAccessibility"})
    public boolean onTouchEvent(MotionEvent motionEvent) {
        MotionEvent event = motionEvent;
        if (this.mDisableCircularTransformation) {
            return super.onTouchEvent(event);
        }
        return inTouchableArea(event.getX(), event.getY()) && super.onTouchEvent(event);
    }

    private boolean inTouchableArea(float f, float f2) {
        float x = f;
        float y = f2;
        if (this.mBorderRect.isEmpty()) {
            return true;
        }
        return Math.pow((double) (x - this.mBorderRect.centerX()), 2.0d) + Math.pow((double) (y - this.mBorderRect.centerY()), 2.0d) <= Math.pow((double) this.mBorderRadius, 2.0d);
    }

    @RequiresApi(api = 21)
    private class OutlineProvider extends ViewOutlineProvider {
        final /* synthetic */ CircleImageView this$0;

        private OutlineProvider(CircleImageView circleImageView) {
            this.this$0 = circleImageView;
        }

        /* JADX INFO: this call moved to the top of the method (can break code semantics) */
        /* synthetic */ OutlineProvider(CircleImageView x0, AnonymousClass1 r7) {
            this(x0);
            AnonymousClass1 r2 = r7;
        }

        public void getOutline(View view, Outline outline) {
            Rect rect;
            View view2 = view;
            Outline outline2 = outline;
            if (this.this$0.mDisableCircularTransformation) {
                ViewOutlineProvider.BACKGROUND.getOutline(view2, outline2);
                return;
            }
            new Rect();
            Rect bounds = rect;
            this.this$0.mBorderRect.roundOut(bounds);
            outline2.setRoundRect(bounds, ((float) bounds.width()) / 2.0f);
        }
    }
}
