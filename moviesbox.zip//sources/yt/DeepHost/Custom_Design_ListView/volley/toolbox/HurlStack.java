package yt.DeepHost.Custom_Design_ListView.volley.toolbox;

import androidx.annotation.VisibleForTesting;
import com.microsoft.appcenter.http.DefaultHttpClient;
import java.io.DataOutputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSocketFactory;
import yt.DeepHost.Custom_Design_ListView.volley.AuthFailureError;
import yt.DeepHost.Custom_Design_ListView.volley.Header;
import yt.DeepHost.Custom_Design_ListView.volley.Request;
import yt.DeepHost.Custom_Design_ListView.volley.toolbox.HttpClientStack;

public class HurlStack extends BaseHttpStack {
    private static final int HTTP_CONTINUE = 100;
    private final SSLSocketFactory mSslSocketFactory;
    private final UrlRewriter mUrlRewriter;

    public interface UrlRewriter {
        String rewriteUrl(String str);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public HurlStack() {
        this((UrlRewriter) null);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public HurlStack(UrlRewriter urlRewriter) {
        this(urlRewriter, (SSLSocketFactory) null);
    }

    public HurlStack(UrlRewriter urlRewriter, SSLSocketFactory sslSocketFactory) {
        this.mUrlRewriter = urlRewriter;
        this.mSslSocketFactory = sslSocketFactory;
    }

    /* JADX INFO: finally extract failed */
    public HttpResponse executeRequest(Request<?> request, Map<String, String> additionalHeaders) throws IOException, AuthFailureError {
        HashMap hashMap;
        URL parsedUrl;
        HttpResponse httpResponse;
        InputStream inputStream;
        HttpResponse httpResponse2;
        Throwable th;
        Throwable th2;
        StringBuilder sb;
        Request<?> request2 = request;
        String url = request2.getUrl();
        new HashMap();
        HashMap hashMap2 = hashMap;
        hashMap2.putAll(additionalHeaders);
        hashMap2.putAll(request2.getHeaders());
        if (this.mUrlRewriter != null) {
            String rewritten = this.mUrlRewriter.rewriteUrl(url);
            if (rewritten == null) {
                Throwable th3 = th2;
                new StringBuilder();
                new IOException(sb.append("URL blocked by rewriter: ").append(url).toString());
                throw th3;
            }
            url = rewritten;
        }
        new URL(url);
        HttpURLConnection connection = openConnection(parsedUrl, request2);
        boolean keepConnectionOpen = false;
        try {
            for (String headerName : hashMap2.keySet()) {
                connection.setRequestProperty(headerName, (String) hashMap2.get(headerName));
            }
            setConnectionParametersForRequest(connection, request2);
            int responseCode = connection.getResponseCode();
            if (responseCode == -1) {
                Throwable th4 = th;
                new IOException("Could not retrieve response code from HttpUrlConnection.");
                throw th4;
            } else if (!hasResponseBody(request2.getMethod(), responseCode)) {
                HttpResponse httpResponse3 = httpResponse2;
                new HttpResponse(responseCode, convertHeaders(connection.getHeaderFields()));
                HttpResponse httpResponse4 = httpResponse3;
                if (0 == 0) {
                    connection.disconnect();
                }
                return httpResponse4;
            } else {
                keepConnectionOpen = true;
                HttpResponse httpResponse5 = httpResponse;
                new UrlConnectionInputStream(connection);
                new HttpResponse(responseCode, convertHeaders(connection.getHeaderFields()), connection.getContentLength(), inputStream);
                HttpResponse httpResponse6 = httpResponse5;
                if (1 == 0) {
                    connection.disconnect();
                }
                return httpResponse6;
            }
        } catch (Throwable th5) {
            Throwable th6 = th5;
            if (!keepConnectionOpen) {
                connection.disconnect();
            }
            throw th6;
        }
    }

    @VisibleForTesting
    static List<Header> convertHeaders(Map<String, List<String>> map) {
        List<Header> list;
        Object obj;
        Map<String, List<String>> responseHeaders = map;
        new ArrayList(responseHeaders.size());
        List<Header> headerList = list;
        for (Map.Entry<String, List<String>> entry : responseHeaders.entrySet()) {
            if (entry.getKey() != null) {
                for (String value : entry.getValue()) {
                    new Header(entry.getKey(), value);
                    boolean add = headerList.add(obj);
                }
            }
        }
        return headerList;
    }

    private static boolean hasResponseBody(int requestMethod, int i) {
        int responseCode = i;
        return (requestMethod == 4 || (100 <= responseCode && responseCode < 200) || responseCode == 204 || responseCode == 304) ? false : true;
    }

    static class UrlConnectionInputStream extends FilterInputStream {
        private final HttpURLConnection mConnection;

        /* JADX WARNING: Illegal instructions before constructor call */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        UrlConnectionInputStream(java.net.HttpURLConnection r5) {
            /*
                r4 = this;
                r0 = r4
                r1 = r5
                r2 = r0
                r3 = r1
                java.io.InputStream r3 = yt.DeepHost.Custom_Design_ListView.volley.toolbox.HurlStack.inputStreamFromConnection(r3)
                r2.<init>(r3)
                r2 = r0
                r3 = r1
                r2.mConnection = r3
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: yt.DeepHost.Custom_Design_ListView.volley.toolbox.HurlStack.UrlConnectionInputStream.<init>(java.net.HttpURLConnection):void");
        }

        public void close() throws IOException {
            super.close();
            this.mConnection.disconnect();
        }
    }

    /* access modifiers changed from: private */
    public static InputStream inputStreamFromConnection(HttpURLConnection httpURLConnection) {
        InputStream inputStream;
        HttpURLConnection connection = httpURLConnection;
        try {
            inputStream = connection.getInputStream();
        } catch (IOException e) {
            IOException iOException = e;
            inputStream = connection.getErrorStream();
        }
        return inputStream;
    }

    /* access modifiers changed from: protected */
    public HttpURLConnection createConnection(URL url) throws IOException {
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setInstanceFollowRedirects(HttpURLConnection.getFollowRedirects());
        return connection;
    }

    private HttpURLConnection openConnection(URL url, Request<?> request) throws IOException {
        URL url2 = url;
        HttpURLConnection connection = createConnection(url2);
        int timeoutMs = request.getTimeoutMs();
        connection.setConnectTimeout(timeoutMs);
        connection.setReadTimeout(timeoutMs);
        connection.setUseCaches(false);
        connection.setDoInput(true);
        if ("https".equals(url2.getProtocol()) && this.mSslSocketFactory != null) {
            ((HttpsURLConnection) connection).setSSLSocketFactory(this.mSslSocketFactory);
        }
        return connection;
    }

    static void setConnectionParametersForRequest(HttpURLConnection httpURLConnection, Request<?> request) throws IOException, AuthFailureError {
        Throwable th;
        HttpURLConnection connection = httpURLConnection;
        Request<?> request2 = request;
        switch (request2.getMethod()) {
            case -1:
                byte[] postBody = request2.getPostBody();
                if (postBody != null) {
                    connection.setRequestMethod(DefaultHttpClient.METHOD_POST);
                    addBody(connection, request2, postBody);
                    return;
                }
                return;
            case 0:
                connection.setRequestMethod(DefaultHttpClient.METHOD_GET);
                return;
            case 1:
                connection.setRequestMethod(DefaultHttpClient.METHOD_POST);
                addBodyIfExists(connection, request2);
                return;
            case 2:
                connection.setRequestMethod("PUT");
                addBodyIfExists(connection, request2);
                return;
            case 3:
                connection.setRequestMethod(DefaultHttpClient.METHOD_DELETE);
                return;
            case 4:
                connection.setRequestMethod("HEAD");
                return;
            case 5:
                connection.setRequestMethod("OPTIONS");
                return;
            case 6:
                connection.setRequestMethod("TRACE");
                return;
            case 7:
                connection.setRequestMethod(HttpClientStack.HttpPatch.METHOD_NAME);
                addBodyIfExists(connection, request2);
                return;
            default:
                Throwable th2 = th;
                new IllegalStateException("Unknown method type.");
                throw th2;
        }
    }

    private static void addBodyIfExists(HttpURLConnection httpURLConnection, Request<?> request) throws IOException, AuthFailureError {
        HttpURLConnection connection = httpURLConnection;
        Request<?> request2 = request;
        byte[] body = request2.getBody();
        if (body != null) {
            addBody(connection, request2, body);
        }
    }

    private static void addBody(HttpURLConnection httpURLConnection, Request<?> request, byte[] bArr) throws IOException {
        DataOutputStream dataOutputStream;
        HttpURLConnection connection = httpURLConnection;
        Request<?> request2 = request;
        byte[] body = bArr;
        connection.setDoOutput(true);
        if (!connection.getRequestProperties().containsKey(DefaultHttpClient.CONTENT_TYPE_KEY)) {
            connection.setRequestProperty(DefaultHttpClient.CONTENT_TYPE_KEY, request2.getBodyContentType());
        }
        new DataOutputStream(connection.getOutputStream());
        DataOutputStream out = dataOutputStream;
        out.write(body);
        out.close();
    }
}
