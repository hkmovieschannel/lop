package yt.DeepHost.Custom_Design_ListView.volley.toolbox;

import android.os.Handler;
import android.os.Looper;
import yt.DeepHost.Custom_Design_ListView.volley.Cache;
import yt.DeepHost.Custom_Design_ListView.volley.NetworkResponse;
import yt.DeepHost.Custom_Design_ListView.volley.Request;
import yt.DeepHost.Custom_Design_ListView.volley.Response;

public class ClearCacheRequest extends Request<Object> {
    private final Cache mCache;
    private final Runnable mCallback;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public ClearCacheRequest(Cache cache, Runnable callback) {
        super(0, (String) null, (Response.ErrorListener) null);
        this.mCache = cache;
        this.mCallback = callback;
    }

    public boolean isCanceled() {
        Handler handler;
        this.mCache.clear();
        if (this.mCallback != null) {
            new Handler(Looper.getMainLooper());
            boolean postAtFrontOfQueue = handler.postAtFrontOfQueue(this.mCallback);
        }
        return true;
    }

    public Request.Priority getPriority() {
        return Request.Priority.IMMEDIATE;
    }

    /* access modifiers changed from: protected */
    public Response<Object> parseNetworkResponse(NetworkResponse networkResponse) {
        NetworkResponse networkResponse2 = networkResponse;
        return null;
    }

    /* access modifiers changed from: protected */
    public void deliverResponse(Object response) {
    }
}
