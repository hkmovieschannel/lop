package yt.DeepHost.Custom_Design_ListView.volley.toolbox;

import android.os.Looper;

final class Threads {
    private Threads() {
    }

    static void throwIfNotOnMainThread() {
        Throwable th;
        if (Looper.myLooper() != Looper.getMainLooper()) {
            Throwable th2 = th;
            new IllegalStateException("Must be invoked from the main thread.");
            throw th2;
        }
    }
}
