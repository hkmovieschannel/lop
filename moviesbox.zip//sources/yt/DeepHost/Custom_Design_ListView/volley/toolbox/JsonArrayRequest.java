package yt.DeepHost.Custom_Design_ListView.volley.toolbox;

import androidx.annotation.Nullable;
import java.io.UnsupportedEncodingException;
import org.json.JSONArray;
import org.json.JSONException;
import yt.DeepHost.Custom_Design_ListView.volley.NetworkResponse;
import yt.DeepHost.Custom_Design_ListView.volley.ParseError;
import yt.DeepHost.Custom_Design_ListView.volley.Response;
import yt.DeepHost.Custom_Design_ListView.volley.VolleyError;

public class JsonArrayRequest extends JsonRequest<JSONArray> {
    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public JsonArrayRequest(String url, Response.Listener<JSONArray> listener, @Nullable Response.ErrorListener errorListener) {
        super(0, url, (String) null, listener, errorListener);
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public JsonArrayRequest(int r13, java.lang.String r14, @androidx.annotation.Nullable org.json.JSONArray r15, yt.DeepHost.Custom_Design_ListView.volley.Response.Listener<org.json.JSONArray> r16, @androidx.annotation.Nullable yt.DeepHost.Custom_Design_ListView.volley.Response.ErrorListener r17) {
        /*
            r12 = this;
            r0 = r12
            r1 = r13
            r2 = r14
            r3 = r15
            r4 = r16
            r5 = r17
            r6 = r0
            r7 = r1
            r8 = r2
            r9 = r3
            if (r9 != 0) goto L_0x0015
            r9 = 0
        L_0x000f:
            r10 = r4
            r11 = r5
            r6.<init>(r7, r8, r9, r10, r11)
            return
        L_0x0015:
            r9 = r3
            java.lang.String r9 = r9.toString()
            goto L_0x000f
        */
        throw new UnsupportedOperationException("Method not decompiled: yt.DeepHost.Custom_Design_ListView.volley.toolbox.JsonArrayRequest.<init>(int, java.lang.String, org.json.JSONArray, yt.DeepHost.Custom_Design_ListView.volley.Response$Listener, yt.DeepHost.Custom_Design_ListView.volley.Response$ErrorListener):void");
    }

    /* access modifiers changed from: protected */
    public Response<JSONArray> parseNetworkResponse(NetworkResponse networkResponse) {
        VolleyError volleyError;
        VolleyError volleyError2;
        String jsonString;
        Object obj;
        NetworkResponse response = networkResponse;
        try {
            new String(response.data, HttpHeaderParser.parseCharset(response.headers, "utf-8"));
            new JSONArray(jsonString);
            return Response.success(obj, HttpHeaderParser.parseCacheHeaders(response));
        } catch (UnsupportedEncodingException e) {
            new ParseError((Throwable) e);
            return Response.error(volleyError2);
        } catch (JSONException e2) {
            new ParseError((Throwable) e2);
            return Response.error(volleyError);
        }
    }
}
