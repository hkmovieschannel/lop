package yt.DeepHost.Custom_Design_ListView.volley.toolbox;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.widget.ImageView;
import androidx.annotation.MainThread;
import androidx.annotation.Nullable;
import yt.DeepHost.Custom_Design_ListView.volley.VolleyError;
import yt.DeepHost.Custom_Design_ListView.volley.toolbox.ImageLoader;

public class NetworkImageView extends ImageView {
    /* access modifiers changed from: private */
    @Nullable
    public Bitmap mDefaultImageBitmap;
    /* access modifiers changed from: private */
    @Nullable
    public Drawable mDefaultImageDrawable;
    /* access modifiers changed from: private */
    public int mDefaultImageId;
    /* access modifiers changed from: private */
    @Nullable
    public Bitmap mErrorImageBitmap;
    /* access modifiers changed from: private */
    @Nullable
    public Drawable mErrorImageDrawable;
    /* access modifiers changed from: private */
    public int mErrorImageId;
    private ImageLoader.ImageContainer mImageContainer;
    private ImageLoader mImageLoader;
    private String mUrl;

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public NetworkImageView(Context context) {
        this(context, (AttributeSet) null);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public NetworkImageView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public NetworkImageView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    @MainThread
    public void setImageUrl(String url, ImageLoader imageLoader) {
        Threads.throwIfNotOnMainThread();
        this.mUrl = url;
        this.mImageLoader = imageLoader;
        loadImageIfNecessary(false);
    }

    public void setDefaultImageResId(int defaultImage) {
        this.mDefaultImageBitmap = null;
        this.mDefaultImageDrawable = null;
        this.mDefaultImageId = defaultImage;
    }

    public void setDefaultImageDrawable(@Nullable Drawable defaultImageDrawable) {
        this.mDefaultImageId = 0;
        this.mDefaultImageBitmap = null;
        this.mDefaultImageDrawable = defaultImageDrawable;
    }

    public void setDefaultImageBitmap(Bitmap defaultImage) {
        this.mDefaultImageId = 0;
        this.mDefaultImageDrawable = null;
        this.mDefaultImageBitmap = defaultImage;
    }

    public void setErrorImageResId(int errorImage) {
        this.mErrorImageBitmap = null;
        this.mErrorImageDrawable = null;
        this.mErrorImageId = errorImage;
    }

    public void setErrorImageDrawable(@Nullable Drawable errorImageDrawable) {
        this.mErrorImageId = 0;
        this.mErrorImageBitmap = null;
        this.mErrorImageDrawable = errorImageDrawable;
    }

    public void setErrorImageBitmap(Bitmap errorImage) {
        this.mErrorImageId = 0;
        this.mErrorImageDrawable = null;
        this.mErrorImageBitmap = errorImage;
    }

    /* access modifiers changed from: package-private */
    public void loadImageIfNecessary(boolean z) {
        ImageLoader.ImageListener imageListener;
        boolean isInLayoutPass = z;
        int width = getWidth();
        int height = getHeight();
        ImageView.ScaleType scaleType = getScaleType();
        boolean wrapWidth = false;
        boolean wrapHeight = false;
        if (getLayoutParams() != null) {
            wrapWidth = getLayoutParams().width == -2;
            wrapHeight = getLayoutParams().height == -2;
        }
        boolean isFullyWrapContent = wrapWidth && wrapHeight;
        if (width != 0 || height != 0 || isFullyWrapContent) {
            if (TextUtils.isEmpty(this.mUrl)) {
                if (this.mImageContainer != null) {
                    this.mImageContainer.cancelRequest();
                    this.mImageContainer = null;
                }
                setDefaultImageOrNull();
                return;
            }
            if (!(this.mImageContainer == null || this.mImageContainer.getRequestUrl() == null)) {
                if (!this.mImageContainer.getRequestUrl().equals(this.mUrl)) {
                    this.mImageContainer.cancelRequest();
                    setDefaultImageOrNull();
                } else {
                    return;
                }
            }
            int maxWidth = wrapWidth ? 0 : width;
            int maxHeight = wrapHeight ? 0 : height;
            final boolean z2 = isInLayoutPass;
            new ImageLoader.ImageListener(this) {
                final /* synthetic */ NetworkImageView this$0;

                {
                    this.this$0 = this$0;
                }

                public void onErrorResponse(VolleyError volleyError) {
                    VolleyError volleyError2 = volleyError;
                    if (this.this$0.mErrorImageId != 0) {
                        this.this$0.setImageResource(this.this$0.mErrorImageId);
                    } else if (this.this$0.mErrorImageDrawable != null) {
                        this.this$0.setImageDrawable(this.this$0.mErrorImageDrawable);
                    } else if (this.this$0.mErrorImageBitmap != null) {
                        this.this$0.setImageBitmap(this.this$0.mErrorImageBitmap);
                    }
                }

                public void onResponse(ImageLoader.ImageContainer imageContainer, boolean isImmediate) {
                    Runnable runnable;
                    ImageLoader.ImageContainer response = imageContainer;
                    if (isImmediate && z2) {
                        final ImageLoader.ImageContainer imageContainer2 = response;
                        new Runnable(this) {
                            final /* synthetic */ AnonymousClass1 this$1;

                            {
                                this.this$1 = this$1;
                            }

                            public void run() {
                                this.this$1.onResponse(imageContainer2, false);
                            }
                        };
                        boolean post = this.this$0.post(runnable);
                    } else if (response.getBitmap() != null) {
                        this.this$0.setImageBitmap(response.getBitmap());
                    } else if (this.this$0.mDefaultImageId != 0) {
                        this.this$0.setImageResource(this.this$0.mDefaultImageId);
                    } else if (this.this$0.mDefaultImageDrawable != null) {
                        this.this$0.setImageDrawable(this.this$0.mDefaultImageDrawable);
                    } else if (this.this$0.mDefaultImageBitmap != null) {
                        this.this$0.setImageBitmap(this.this$0.mDefaultImageBitmap);
                    }
                }
            };
            this.mImageContainer = this.mImageLoader.get(this.mUrl, imageListener, maxWidth, maxHeight, scaleType);
        }
    }

    private void setDefaultImageOrNull() {
        if (this.mDefaultImageId != 0) {
            setImageResource(this.mDefaultImageId);
        } else if (this.mDefaultImageDrawable != null) {
            setImageDrawable(this.mDefaultImageDrawable);
        } else if (this.mDefaultImageBitmap != null) {
            setImageBitmap(this.mDefaultImageBitmap);
        } else {
            setImageBitmap((Bitmap) null);
        }
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);
        loadImageIfNecessary(true);
    }

    /* access modifiers changed from: protected */
    public void onDetachedFromWindow() {
        if (this.mImageContainer != null) {
            this.mImageContainer.cancelRequest();
            setImageBitmap((Bitmap) null);
            this.mImageContainer = null;
        }
        super.onDetachedFromWindow();
    }

    /* access modifiers changed from: protected */
    public void drawableStateChanged() {
        super.drawableStateChanged();
        invalidate();
    }
}
