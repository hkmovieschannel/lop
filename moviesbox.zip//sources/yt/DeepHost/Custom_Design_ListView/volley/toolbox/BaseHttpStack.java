package yt.DeepHost.Custom_Design_ListView.volley.toolbox;

import java.io.IOException;
import java.util.Map;
import yt.DeepHost.Custom_Design_ListView.volley.AuthFailureError;
import yt.DeepHost.Custom_Design_ListView.volley.Request;

public abstract class BaseHttpStack implements HttpStack {
    public abstract HttpResponse executeRequest(Request<?> request, Map<String, String> map) throws IOException, AuthFailureError;

    public BaseHttpStack() {
    }

    /* JADX WARNING: Multi-variable type inference failed */
    @java.lang.Deprecated
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final org.apache.http.HttpResponse performRequest(yt.DeepHost.Custom_Design_ListView.volley.Request<?> r18, java.util.Map<java.lang.String, java.lang.String> r19) throws java.io.IOException, yt.DeepHost.Custom_Design_ListView.volley.AuthFailureError {
        /*
            r17 = this;
            r1 = r17
            r2 = r18
            r3 = r19
            r11 = r1
            r12 = r2
            r13 = r3
            yt.DeepHost.Custom_Design_ListView.volley.toolbox.HttpResponse r11 = r11.executeRequest(r12, r13)
            r4 = r11
            org.apache.http.ProtocolVersion r11 = new org.apache.http.ProtocolVersion
            r16 = r11
            r11 = r16
            r12 = r16
            java.lang.String r13 = "HTTP"
            r14 = 1
            r15 = 1
            r12.<init>(r13, r14, r15)
            r5 = r11
            org.apache.http.message.BasicStatusLine r11 = new org.apache.http.message.BasicStatusLine
            r16 = r11
            r11 = r16
            r12 = r16
            r13 = r5
            r14 = r4
            int r14 = r14.getStatusCode()
            java.lang.String r15 = ""
            r12.<init>(r13, r14, r15)
            r6 = r11
            org.apache.http.message.BasicHttpResponse r11 = new org.apache.http.message.BasicHttpResponse
            r16 = r11
            r11 = r16
            r12 = r16
            r13 = r6
            r12.<init>(r13)
            r7 = r11
            java.util.ArrayList r11 = new java.util.ArrayList
            r16 = r11
            r11 = r16
            r12 = r16
            r12.<init>()
            r8 = r11
            r11 = r4
            java.util.List r11 = r11.getHeaders()
            java.util.Iterator r11 = r11.iterator()
            r9 = r11
        L_0x0057:
            r11 = r9
            boolean r11 = r11.hasNext()
            if (r11 == 0) goto L_0x0081
            r11 = r9
            java.lang.Object r11 = r11.next()
            yt.DeepHost.Custom_Design_ListView.volley.Header r11 = (yt.DeepHost.Custom_Design_ListView.volley.Header) r11
            r10 = r11
            r11 = r8
            org.apache.http.message.BasicHeader r12 = new org.apache.http.message.BasicHeader
            r16 = r12
            r12 = r16
            r13 = r16
            r14 = r10
            java.lang.String r14 = r14.getName()
            r15 = r10
            java.lang.String r15 = r15.getValue()
            r13.<init>(r14, r15)
            boolean r11 = r11.add(r12)
            goto L_0x0057
        L_0x0081:
            r11 = r7
            r12 = r8
            r13 = 0
            org.apache.http.Header[] r13 = new org.apache.http.Header[r13]
            java.lang.Object[] r12 = r12.toArray(r13)
            org.apache.http.Header[] r12 = (org.apache.http.Header[]) r12
            r11.setHeaders(r12)
            r11 = r4
            java.io.InputStream r11 = r11.getContent()
            r9 = r11
            r11 = r9
            if (r11 == 0) goto L_0x00b8
            org.apache.http.entity.BasicHttpEntity r11 = new org.apache.http.entity.BasicHttpEntity
            r16 = r11
            r11 = r16
            r12 = r16
            r12.<init>()
            r10 = r11
            r11 = r10
            r12 = r9
            r11.setContent(r12)
            r11 = r10
            r12 = r4
            int r12 = r12.getContentLength()
            long r12 = (long) r12
            r11.setContentLength(r12)
            r11 = r7
            r12 = r10
            r11.setEntity(r12)
        L_0x00b8:
            r11 = r7
            r1 = r11
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: yt.DeepHost.Custom_Design_ListView.volley.toolbox.BaseHttpStack.performRequest(yt.DeepHost.Custom_Design_ListView.volley.Request, java.util.Map):org.apache.http.HttpResponse");
    }
}
