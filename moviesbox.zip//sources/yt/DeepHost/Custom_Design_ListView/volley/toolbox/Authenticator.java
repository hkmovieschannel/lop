package yt.DeepHost.Custom_Design_ListView.volley.toolbox;

import yt.DeepHost.Custom_Design_ListView.volley.AuthFailureError;

public interface Authenticator {
    String getAuthToken() throws AuthFailureError;

    void invalidateAuthToken(String str);
}
