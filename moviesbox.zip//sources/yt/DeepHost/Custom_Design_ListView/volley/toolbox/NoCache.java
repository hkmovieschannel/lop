package yt.DeepHost.Custom_Design_ListView.volley.toolbox;

import yt.DeepHost.Custom_Design_ListView.volley.Cache;

public class NoCache implements Cache {
    public NoCache() {
    }

    public void clear() {
    }

    public Cache.Entry get(String str) {
        String str2 = str;
        return null;
    }

    public void put(String key, Cache.Entry entry) {
    }

    public void invalidate(String key, boolean fullExpire) {
    }

    public void remove(String key) {
    }

    public void initialize() {
    }
}
