package yt.DeepHost.Custom_Design_ListView.volley;

import android.annotation.TargetApi;
import android.net.TrafficStats;
import android.os.Build;
import android.os.Process;
import android.os.SystemClock;
import androidx.annotation.VisibleForTesting;
import java.util.concurrent.BlockingQueue;

public class NetworkDispatcher extends Thread {
    private final Cache mCache;
    private final ResponseDelivery mDelivery;
    private final Network mNetwork;
    private final BlockingQueue<Request<?>> mQueue;
    private volatile boolean mQuit = false;

    public NetworkDispatcher(BlockingQueue<Request<?>> queue, Network network, Cache cache, ResponseDelivery delivery) {
        this.mQueue = queue;
        this.mNetwork = network;
        this.mCache = cache;
        this.mDelivery = delivery;
    }

    public void quit() {
        this.mQuit = true;
        interrupt();
    }

    @TargetApi(14)
    private void addTrafficStatsTag(Request<?> request) {
        Request<?> request2 = request;
        if (Build.VERSION.SDK_INT >= 14) {
            TrafficStats.setThreadStatsTag(request2.getTrafficStatsTag());
        }
    }

    public void run() {
        Process.setThreadPriority(10);
        while (true) {
            try {
                processRequest();
            } catch (InterruptedException e) {
                InterruptedException interruptedException = e;
                if (this.mQuit) {
                    Thread.currentThread().interrupt();
                    return;
                }
                VolleyLog.e("Ignoring spurious interrupt of NetworkDispatcher thread; use quit() to terminate it", new Object[0]);
            }
        }
    }

    private void processRequest() throws InterruptedException {
        processRequest(this.mQueue.take());
    }

    /* access modifiers changed from: package-private */
    @VisibleForTesting
    public void processRequest(Request<?> request) {
        VolleyError volleyError;
        Request<?> request2 = request;
        long startTimeMs = SystemClock.elapsedRealtime();
        request2.sendEvent(3);
        try {
            request2.addMarker("network-queue-take");
            if (request2.isCanceled()) {
                request2.finish("network-discard-cancelled");
                request2.notifyListenerResponseNotUsable();
                request2.sendEvent(4);
                return;
            }
            addTrafficStatsTag(request2);
            NetworkResponse networkResponse = this.mNetwork.performRequest(request2);
            request2.addMarker("network-http-complete");
            if (!networkResponse.notModified || !request2.hasHadResponseDelivered()) {
                Response<?> response = request2.parseNetworkResponse(networkResponse);
                request2.addMarker("network-parse-complete");
                if (request2.shouldCache() && response.cacheEntry != null) {
                    this.mCache.put(request2.getCacheKey(), response.cacheEntry);
                    request2.addMarker("network-cache-written");
                }
                request2.markDelivered();
                this.mDelivery.postResponse(request2, response);
                request2.notifyListenerResponseReceived(response);
                request2.sendEvent(4);
                return;
            }
            request2.finish("not-modified");
            request2.notifyListenerResponseNotUsable();
            request2.sendEvent(4);
        } catch (VolleyError e) {
            VolleyError volleyError2 = e;
            volleyError2.setNetworkTimeMs(SystemClock.elapsedRealtime() - startTimeMs);
            parseAndDeliverNetworkError(request2, volleyError2);
            request2.notifyListenerResponseNotUsable();
            request2.sendEvent(4);
        } catch (Exception e2) {
            Exception e3 = e2;
            Exception exc = e3;
            VolleyLog.e(exc, "Unhandled exception %s", e3.toString());
            new VolleyError((Throwable) e3);
            VolleyError volleyError3 = volleyError;
            volleyError3.setNetworkTimeMs(SystemClock.elapsedRealtime() - startTimeMs);
            this.mDelivery.postError(request2, volleyError3);
            request2.notifyListenerResponseNotUsable();
            request2.sendEvent(4);
        } catch (Throwable th) {
            Throwable th2 = th;
            request2.sendEvent(4);
            throw th2;
        }
    }

    private void parseAndDeliverNetworkError(Request<?> request, VolleyError error) {
        Request<?> request2 = request;
        VolleyError error2 = request2.parseNetworkError(error);
        this.mDelivery.postError(request2, error2);
    }
}
