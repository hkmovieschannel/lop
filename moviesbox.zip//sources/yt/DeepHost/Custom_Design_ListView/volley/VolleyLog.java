package yt.DeepHost.Custom_Design_ListView.volley;

import android.os.SystemClock;
import android.util.Log;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class VolleyLog {
    private static final String CLASS_NAME = VolleyLog.class.getName();
    public static boolean DEBUG = Log.isLoggable(TAG, 2);
    public static String TAG = "Volley";

    public VolleyLog() {
    }

    public static void setTag(String str) {
        String tag = str;
        d("Changing log tag to %s", tag);
        TAG = tag;
        DEBUG = Log.isLoggable(TAG, 2);
    }

    public static void v(String str, Object... objArr) {
        String format = str;
        Object[] args = objArr;
        if (DEBUG) {
            int v = Log.v(TAG, buildMessage(format, args));
        }
    }

    public static void d(String format, Object... args) {
        int d = Log.d(TAG, buildMessage(format, args));
    }

    public static void e(String format, Object... args) {
        int e = Log.e(TAG, buildMessage(format, args));
    }

    public static void e(Throwable tr, String format, Object... args) {
        int e = Log.e(TAG, buildMessage(format, args), tr);
    }

    public static void wtf(String format, Object... args) {
        int wtf = Log.wtf(TAG, buildMessage(format, args));
    }

    public static void wtf(Throwable tr, String format, Object... args) {
        int wtf = Log.wtf(TAG, buildMessage(format, args), tr);
    }

    private static String buildMessage(String str, Object... objArr) {
        Throwable th;
        StringBuilder sb;
        String format = str;
        Object[] args = objArr;
        String msg = args == null ? format : String.format(Locale.US, format, args);
        new Throwable();
        StackTraceElement[] trace = th.fillInStackTrace().getStackTrace();
        String caller = "<unknown>";
        int i = 2;
        while (true) {
            if (i >= trace.length) {
                break;
            } else if (!trace[i].getClassName().equals(CLASS_NAME)) {
                String callingClass = trace[i].getClassName();
                String callingClass2 = callingClass.substring(callingClass.lastIndexOf(46) + 1);
                String callingClass3 = callingClass2.substring(callingClass2.lastIndexOf(36) + 1);
                new StringBuilder();
                caller = sb.append(callingClass3).append(".").append(trace[i].getMethodName()).toString();
                break;
            } else {
                i++;
            }
        }
        Locale locale = Locale.US;
        Object[] objArr2 = new Object[3];
        objArr2[0] = Long.valueOf(Thread.currentThread().getId());
        Object[] objArr3 = objArr2;
        objArr3[1] = caller;
        Object[] objArr4 = objArr3;
        objArr4[2] = msg;
        return String.format(locale, "[%d] %s: %s", objArr4);
    }

    static class MarkerLog {
        public static final boolean ENABLED = VolleyLog.DEBUG;
        private static final long MIN_DURATION_FOR_LOGGING_MS = 0;
        private boolean mFinished = false;
        private final List<Marker> mMarkers;

        MarkerLog() {
            List<Marker> list;
            new ArrayList();
            this.mMarkers = list;
        }

        private static class Marker {
            public final String name;
            public final long thread;
            public final long time;

            public Marker(String name2, long thread2, long time2) {
                this.name = name2;
                this.thread = thread2;
                this.time = time2;
            }
        }

        public synchronized void add(String str, long j) {
            Object obj;
            Throwable th;
            String name = str;
            long threadId = j;
            synchronized (this) {
                if (this.mFinished) {
                    Throwable th2 = th;
                    new IllegalStateException("Marker added to finished log");
                    throw th2;
                }
                new Marker(name, threadId, SystemClock.elapsedRealtime());
                boolean add = this.mMarkers.add(obj);
            }
        }

        public synchronized void finish(String str) {
            String header = str;
            synchronized (this) {
                this.mFinished = true;
                long duration = getTotalDuration();
                if (duration > 0) {
                    long prevTime = this.mMarkers.get(0).time;
                    Object[] objArr = new Object[2];
                    objArr[0] = Long.valueOf(duration);
                    Object[] objArr2 = objArr;
                    objArr2[1] = header;
                    VolleyLog.d("(%-4d ms) %s", objArr2);
                    for (Marker marker : this.mMarkers) {
                        long thisTime = marker.time;
                        Object[] objArr3 = new Object[3];
                        objArr3[0] = Long.valueOf(thisTime - prevTime);
                        Object[] objArr4 = objArr3;
                        objArr4[1] = Long.valueOf(marker.thread);
                        Object[] objArr5 = objArr4;
                        objArr5[2] = marker.name;
                        VolleyLog.d("(+%-4d) [%2d] %s", objArr5);
                        prevTime = thisTime;
                    }
                }
            }
        }

        /* access modifiers changed from: protected */
        public void finalize() throws Throwable {
            if (!this.mFinished) {
                finish("Request on the loose");
                VolleyLog.e("Marker log finalized without finish() - uncaught exit point for request", new Object[0]);
            }
        }

        private long getTotalDuration() {
            if (this.mMarkers.size() == 0) {
                return 0;
            }
            return this.mMarkers.get(this.mMarkers.size() - 1).time - this.mMarkers.get(0).time;
        }
    }
}
