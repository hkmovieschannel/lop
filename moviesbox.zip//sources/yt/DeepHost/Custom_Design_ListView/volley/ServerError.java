package yt.DeepHost.Custom_Design_ListView.volley;

public class ServerError extends VolleyError {
    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public ServerError(NetworkResponse networkResponse) {
        super(networkResponse);
    }

    public ServerError() {
    }
}
