package yt.DeepHost.Custom_Design_ListView;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import java.io.File;
import java.io.IOException;

public class isReple {
    public static boolean appInventor = true;
    public static boolean isRepl = false;
    public static Bitmap mybitmap;
    public static String parth_appInventor = "/mnt/sdcard/AppInventor/assets/";
    public static String parth_makeroid = "/mnt/sdcard/Kodular/assets/";

    public isReple() {
    }

    public static Bitmap mode(Context context, String str) {
        File file;
        StringBuilder sb;
        Uri uri;
        File file2;
        StringBuilder sb2;
        Context context2 = context;
        String name = str;
        if (isRepl) {
            if (appInventor) {
                new StringBuilder();
                new File(sb2.append(parth_appInventor).append(name).toString());
                uri = Uri.fromFile(file2);
            } else {
                new StringBuilder();
                new File(sb.append(parth_makeroid).append(name).toString());
                uri = Uri.fromFile(file);
            }
            try {
                mybitmap = BitmapFactory.decodeStream(context2.getContentResolver().openInputStream(uri));
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            try {
                mybitmap = BitmapFactory.decodeStream(context2.getAssets().open(name));
            } catch (IOException e2) {
                e2.printStackTrace();
            }
        }
        return mybitmap;
    }
}
